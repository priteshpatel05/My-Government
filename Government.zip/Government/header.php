
<div class="header">


<!-- ===================== start =============================  !-->
	<div class="title">
        <img src="img/logo1.png" class="symbol_t" />
        <img src="img/title_name.png"  class="t"/>
    </div>


         <div class="login">
				
              <div class="text">
                        Good Governance With Your Partnership
              </div>
			
           <div class="login-div">  

<?php

	if (isset($_SESSION['u_id']))
	{
		
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);	
						
			$qry="select * from user_reg where u_id='".$_SESSION['u_id']."'";
								
			$resultUser=mysql_query($qry,$con);			
			$r=mysql_fetch_assoc($resultUser);
			
			$n=mysql_num_rows($resultUser);
			
			if($n==1)
			{
			//echo "".$_SESSION['u_id'];
?>
		
        <div class="flip">      	
                
                <div class="user_name">
					<a href="user_profile.php" class="logout-a">
						<?php
                            $name=$r['u_id'];
                            echo "Welcome, ".ucfirst($r['fname']."&nbsp;".$r['lname']);
                        ?>
                    </a>
                </div>
                
                <img src="<?php echo $r['pro_pic']; ?>" class="user_pro" />
                
				<div class="logout-div">
                	<span class="fa  fa-power-off">
                    	<a href="session.php" class="logout-a" >Logout</a>
                    </span>
                </div>
 	    </div>
		
	<?php
	
			}
			else
			{
	?>
    			<span class="fa  fa-sign-in">
                 	<a href="reg.php" class="login-a"> Login/SignUp </a>
                </span>
	<?php
			}
	
        }
        else
        {
    ?>		
    		
    			<span class="fa  fa-sign-in">
                 	<a href="reg.php" class="login-a"> Login/SignUp </a>
                </span>
            
    <?php
        }
    ?>
		</div>
	</div>

<!-- ===================== end =============================  !-->


    
    <div class="menu-div">
    	
        <ul>
    	<?php
			$menu_qry="select * from menu";
			$menu_result=mysql_query($menu_qry);

			while($menu_row=mysql_fetch_assoc($menu_result))
			{
			
		?>
        	<a href="<?php  echo $menu_row['link_name']; ?> " class="menu-a" >
                <li class="non-active">
                        <?php  echo ucfirst($menu_row['m_name']); ?> 
                </li>
            </a> 
        <?php		
			}
		?>
    	
    </ul>        
        
     
    
    </div>

</div>

