<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);
	
	$r_qry="select * from rules_tbl order by no desc";
	$r_result=mysql_query($r_qry,$con);		
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_new_rules_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
</head>

<body>
	

<div class="content">
<?php
	include('header.php');
?>
<?php
include('service_script.php');
?>


<div class="help-note" >
    	Helping You And Find Government Information & Servies.
    </div>

<div class="service_main_div">

	<div class="service_menu">
    	
        <div class="li_menu">
        	<?php
			include('service_menu_li.php');
			?>
        </div>
    
    </div>
    
    <div class="service_show">
    	<span class="fa fa-angle-double-left" id="click"></span>





          <div class="margin-set">   
<!-- = = = = = = = = = = = = = = = =  Margin-set = = = = = = = = = = = = = = = = = !-->       



   <div class="service">
		<div class="service_data">    
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->    		
       			
                
                <div class="name">
                	Indian Government's   Acts / Rules 
                </div>
                
                <div class="rules-div">
                	<div class="rules-show">
                    
						<?php
                        while($r_row=mysql_fetch_assoc($r_result))
                        {
                        ?>
                        
                        	<p class="float"><span class="fa  fa-circle-o"></span></p>
                            <p class="rules_sub_show"><?php echo ucfirst($r_row['sub']); ?></p>
                         	<p class="rules_details_show"><?php echo ucfirst($r_row['rules']); ?></p>
                        
                        <?php
                        }
                        ?>
                   
                    
                    </div>
                </div>
                
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->    		
				</div>
             </div>               
            
            
<!-- = = = = = = = = = = = = = = = =  End Margin-set = = = = = = = = = = = = = = = = = !-->       
          </div>






    </div>

</div>


<?php
	include('footer.php');
?>
</div>

</body>
</html>
