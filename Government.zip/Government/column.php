<div class="user_cloumn">
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->            
     <div class="user_detail">
              
              
         <div class="show_img">
             <img src="<?php echo $user_row['pro_pic'];?>" class="pro_pic"/>
             <div class="btn">
             <a href="user_account.php">Change Profile</a>
             </div>
         </div>  
              
                    <ul class="setting">
                    	
                        <a href="user_profile.php">
                            <li>
                             <span class="font_class">
                                 <?php echo ucfirst($user_row['fname'])."&nbsp;".$user_row['lname'];?>
                             </span>    
                            </li>
                        </a>
                        
                        <a href="user_edit_profile.php">
                            <li>
                                 Edit Profile
                                 <span class="fa  fa-angle-double-right"></span>
                            </li>
                    	</a>

						<a href="user_account.php">
                            <li>
                                 Account Setting  
                                 <span class="fa  fa-angle-double-right"></span>
                            </li>
 						</a>                   
                    </ul>
                    
    </div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->            
</div> 
