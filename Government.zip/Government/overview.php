<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	
	
	$qry="select * from upload order by no desc limit 4";
	$result=mysql_query($qry);

	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/footer_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />

<script src="jq/jquery.min.1.11.0.js"></script>

</head>

<body>

<div class="content">
<?php
	include('header.php');
?>


<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->
    <div class="overview">
		<div class="overview_data">
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        
  
  
  			<p class="heading_overview">OverView</p>
			<hr />
			
            <p class="overview_text">
            The citizen-centric platform empowers people to connect with the Government & contribute towards good governance.
            </p>
      
        
        <div class="video_div">
  
    <video src="video/My Gov - Great Governance With Your Partnership (English).mp4" preload="none" class="video_size" controls="controls" poster="img/viral_video.png"><!-- autoplay>!-->
    
    </video>            
            </div>
        
        
        
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        
        </div>    
    </div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->
			<!--<div class="video_div">
            	
 <video id="my-video" controls="controls" preload="none" class="video_size"  poster="img/humayuntomb.jpg">
 
 <source src="video/My Gov - Great Governance With Your Partnership (English).mp4" type="video/mp4">
 
 </video>
                
            </div>!-->
	

<?php
	include('footer.php');
?>
</div>

</body>
</html>
