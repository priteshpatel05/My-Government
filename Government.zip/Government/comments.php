<?php
session_start();

if(isset($_REQUEST['task']))
{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);	
			
		$i="cmt".rand(1,999);	

		$c_qry="insert into cmt(no,u_id,comment,id_up,cmt_id) values('',
										  '".$_REQUEST['user_id']."',
										  '".$_REQUEST['cmt']."',
										  '".$_REQUEST['upload_id']."',
										  '".$i."')";
		mysql_query($c_qry,$con);
		
		$c="select * from cmt";
		$c_result=mysql_query($c,$con);
		$c_row=mysql_fetch_assoc($c_result);
				
		$_SESSION['task']=$c_row['id_up'];
		header('Location: view_blog.php');
}


?>