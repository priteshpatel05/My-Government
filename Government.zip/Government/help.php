<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/home_css.css" type="text/css" />
<link rel="stylesheet" href="css/footer_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>

</head>

<body>
	

<div class="content">
<?php
	include('header.php');
?>

<!-- - - - - - - - - - - - - - - - About page - - - - - - - - - - - - - - - - - !-->
    <div class="help">
		<div class="help_data">    
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        

			<p class="help_heading"> Help</p>
			<hr />
            
            
            
            <div class="text1">
            
            <h3>How can I join My Gov</h3><br />
            
            Register on mygov.in to participate. You will be asked for personal details such as name, email id etc. You will also be required to mention the kind of skills you have & the issues on which you may like to provide inputs.<br /><br>
Please note that MyGov do not share any personally identifiable information volunteered on this site with any third party (public/private). Any information provided to this website will be protected from loss, misuse, unauthorized access, disclosure, alteration, or destruction.
            
            </div>
            
            
            <div class="text1">
            
            <h3>For Public</h3><br />
            For the larger public, registration and sign up on MyGov can be done through your valid email ID and your 10-digit Mobile number. While logging in, either the registered mobile number or email id can be used. Every time you  enter your Email ID. You do need to remember password for logging in.  Alternatively, you can Sign-in by using your email id and password as you maintain with MyGov. 
            </div>
            
            
            <div class="text1">
            
            <h3>Groups:  Collaborate with Government!</h3><br />
 Explore & choose from an array of topics on public and national importance on which Government and its respective agency would like to hear from you. Make yourself part of these groups and express your valued views and proposal on these issues. The Government would seek your active engagement and participation in addressing issues mentioned as group topics in the portal. A citizen can only be part of 4 groups at one particular time.
           </div>
            
            
            <div class="text1">
            
            <h3>Discuss: Express Yourself</h3><br />
 Express your valued insight and views on theme based discussions on the MyGov. It values your views and the Government is keen to hear from you to improve on its policy initiatives. Therefore, involve yourself in the discussions and contribute actively to the process of policy formulation.
           </div>
            
           
           <div class="text1">
            
            <h3>How can I Send Feedbacks</h3><br />
Any query, of generic nature, related to content, design, service or technological issues with respect to MyGov platform can be sent to through this customized Feedback interface.
          </div>
            
            
            
            <div class="text1">
            
	        <h3>General Guidelines : Entry, Submission, Evaluation</h3>
            <br />
            
             <span class="fa  fa-circle-o"> </span>
            <p>
            Since every task will come from different Ministries, the specific requirements will naturally wary. However, there are some general guidelines that would have to be adhered to.</p>
   
            <br /><h3>General Guidelines:</h3>
            
             <br /> 
             
             <span class="fa  fa-circle-o"> </span>
             <p>Each task will have a particular deadline that would have to be adhered to. Unless communicated by the Ministry concerned or the MyGov admin, the deadline cannot be changed. Any entry submitted post the deadline would not be accepted. </p>
             
             
             <span class="fa  fa-circle-o"> </span> 
<p>The work submitted by the participants must be original and must not infringe the intellectual property rights of any third party.</p>


			<span class="fa  fa-circle-o"> </span>
<p>The final symbol/design/concept/caption adjudged as the winning entry shall become the intellectual property of the Government of India. The Government shall have the right to use, print or reproduce the prize-winning logo in any form it deems appropriate.</p>


			<span class="fa  fa-circle-o"> </span>
<p>The responsibility to comply with the guidelines and other conditions fully lies with the participant/participant and the Government of India shall not be liable for any dispute raised by a third party.</p>


			<span class="fa  fa-circle-o"> </span>
<p>The Competition is subject to Indian law and is governed by the exclusive jurisdiction of the Indian courts.</li>
               
            </div>
            
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        
        </div>
    </div>
<!-- - - - - - - - - - - - - - - - End About page - - - - - - - - - - - - - - - - - !-->

<?php
	include('footer.php');
?>
</div>

</body>
</html>
