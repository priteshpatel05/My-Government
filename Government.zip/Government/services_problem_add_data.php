<?php
session_start();

/*= = = = = = = = = = = = = = = = = user Problem = = = = = = = = = = = = = */
if(isset($_REQUEST['problem_btn']))
{
	problem_add();
}
else if(isset($_REQUEST['dis']))
	{
		display();
	}
/*= = = = = = = = = = = = = = = = = End User Problem = = = = = = = = = = = = = */

/*= = = = = = = = = = = = = = = = = Comments open page = = = = = = = = = = = = = */	
if(isset($_REQUEST['cmt_btn']))
{
	cmt_add();
}
else if(isset($_REQUEST['cmt_dis']))
	{
		cmt_display($_REQUEST['cmt_dis']);
	}
	else if(isset($_REQUEST['count']))
		{
			cmt_count($_REQUEST['count']);	
		}
/*= = = = = = = = = = = = = = = = = End Comments open page = = = = = = = = = = = = = */


/*= = = = = = = = = = = = = = = = = Comments open page = = = = = = = = = = = = = */
	function cmt_count( $i )
	{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
		
				$c_qry="select count(no) from s_problem_cmt_tbl where pbm_id='".$i."'";
				$c_result=mysql_query($c_qry,$con);	
				$c_row=mysql_fetch_array($c_result);
				$a=$c_row[0];
					echo $a;
	}
	
	function cmt_add()
	{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
			
			$d=date('d-M-y');		
			$c_qry="insert into s_problem_cmt_tbl values('',
													   '".$_REQUEST['user_id']."',
													   '".$_REQUEST['cmt']."',
													   '".$_REQUEST['pbm_id']."',
													   '".$d."')";
			$c_result=mysql_query($c_qry,$con);
			cmt_display($_REQUEST['pbm_id']);			
	}
	
	function cmt_display( $id )
	{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
			$pbm_qry="select * from s_problem_cmt_tbl where pbm_id='".$id."' order by no desc";
			$pbm_result=mysql_query($pbm_qry,$con);		
			
			    while($pbm_row=mysql_fetch_assoc($pbm_result))
                {
                    if($pbm_row['pbm_id']==$id)
                    {
							$user_info_qry="select * from user_reg where u_id='".$pbm_row['u_id']."'";
                            $user_info_result=mysql_query($user_info_qry,$con);
                            $user_info_row=mysql_fetch_assoc($user_info_result);	
        ?>
                  <div class="comments">
                            <img src="<?php echo $user_info_row['pro_pic'];?>" class="cmt-u-img" />
                            <div class="cmt-name">      
                                <?php echo ucfirst($user_info_row['fname'])."&nbsp;".$user_info_row['lname'];?>
                            </div>
                            
                            <div class="cmt-date">
                                <?php echo $pbm_row['date'];?>
                            </div>
                            
                            <div class="cmt-text">
                                <?php echo $pbm_row['cmt'];?>
                            </div>
                  </div>
                        
        <?php
						
                    }
                }
		
	}

/*= = = = = = = = = = = = = = = = = Comments open page = = = = = = = = = = = = = */



/*= = = = = = = = = = = = = = = = = user problem insert  and Display = = = = = = = = = = = = = */
	function problem_add()
	{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
			
			$pbm_id=rand(4,420);
			$d=date('d-M-Y');
			
			$pbm_qry="insert into s_problem_tbl values('',
													   '".$_REQUEST['user_id']."',
													   '".$_REQUEST['user_problem']."',
													   '".$pbm_id."',
													   '".$d."',
													   '1')";
			mysql_query($pbm_qry,$con);
			//header('Location: services_problem.php');
			display();
	}
	
	function display()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$pbm_qry="select * from s_problem_tbl order by no desc";
		$pbm_result=mysql_query($pbm_qry,$con);
	
                        while($pbm_row=mysql_fetch_assoc($pbm_result))
                        {
                            $user_info_qry="select * from user_reg where u_id='".$pbm_row['u_id']."'";
                            $user_info_result=mysql_query($user_info_qry,$con);
                            $user_info_row=mysql_fetch_assoc($user_info_result);						
                        ?>
                   <div class="outer">
                        <div class="set">
                            <img src="<?php echo $user_info_row['pro_pic']?>"  class="pro-user-img" />
                        
                            <div class="name-user">
                                <?php echo ucfirst($user_info_row['fname'])."&nbsp;".$user_info_row['lname'];?>
                            </div>
                            
                            <div class="date-user">
                            	<?php   echo $pbm_row['date']; ?>
                            </div>
							
                            <div class="txt-user" >
                         		<?php   echo $pbm_row['problem_text']; ?>
                        	</div>
                            
                    <div class="cmt-count-div">
                    <?php
									
					$c_qry="select count(no) from s_problem_cmt_tbl where pbm_id='".$pbm_row['pbm_id']."'";
					$c_result=mysql_query($c_qry,$con);	
					$c_row=mysql_fetch_array($c_result);
					$a=$c_row[0];
					?>
                    	<div class="cmt-count-show">
							<a href="service_problem_open_cmt.php?no=<?php echo $pbm_row['pbm_id'];?>" class="cmt-a">
								<?php echo $a;?>&nbsp;
                                <span class="fa fa-comments"></span>&nbsp;Comments
                            </a>
                    	</div>
                    </div>
                    
                    
                    
                       </div>
                  </div>
                        <?php
                        }         
	}
/*= = = = = = = = = = = = = = = = = End user problem insert = = = = = = = = = = = = = */
?>
