<?php
	$s_qry="select * from service_menu";
	$s_result=mysql_query($s_qry,$con);
?>
<div class="background">

<div class="head_srvices_menu">
	Our Services
</div>


		<ul class="menu_ul">
			<?php
				while($s_row=mysql_fetch_assoc($s_result))
				{
			?>
            	<a href="<?php echo $s_row['s_link'];?>">
                	<li class="li" ><?php echo ucfirst($s_row['s_name']);?></li>
                </a>
            <?php					
				}
			?>
		</ul>
        	<!--<ul class="menu_ul">
            	<a href="services_problem.php">
                	<li class="li" >Problems</li>
                </a>
                
                <a href="services_new_ideas.php">
 	               <li class="li" >New Idea's</li>
                </a>
                
                <a href="services_new_rules.php">
    	            <li class="li" >Governments Rules</li>
                </a>
                
               <a href="services_gov_jobs.php"> 
	                <li class="li" >Job's Vacancies</li>
    			</a>
                
               <a href="services_honours_award.php">            
               	 <li class="li" >Honours & Awards</li>
          	   </a>
               <a href="services_scholarship.php">            
               	 <li class="li" >Students Schollarship </li>
          	   </a>
          
           
            </ul>!-->
            
</div>