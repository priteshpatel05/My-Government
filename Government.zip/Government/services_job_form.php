<?php
session_start();	

if(  isset($_REQUEST['a']) )
{
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);		
	
	$g="select * from job_vacancies_tbl where v_id='".$_REQUEST['a']."'";
	$re=mysql_query($g,$con);
	$n=mysql_num_rows($re);
	
	if($n==1)
	{ 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_jobs_form_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<script src="jq/diaplay-image.js"></script>
<?php
include('service_script.php');
include('services_jobs_script.php');
?>


<script>
	details();
	function details()
	{
		var a=<?php echo $_REQUEST['a'];?>;
		$.post('services_gov_jobs_data.php',{details:a},
									function(e){ $('.show_job_vac_details').html(e)});
	}
	
</script>

</head>

<body>
<!----------------------------------------------------------------------------------------------------------!-->
 			<?php
		if(isset($_SESSION['msg']))
		{
			if($_SESSION['msg']=='a')
			{
	?>
   			<div class="error">
                
                <script>
					$(document).ready(function(e) {
                        $('.c').click(function(e){
							 $('.error').fadeOut('slow')
							 });
                    });
				</script>
                
                	
                	<div class="error_table">
                    	<p class="pwd_error_head">
                        	Message
                        </p>
                        <p class="padding">
        				<?php 
								echo " Apply Form Successfully Complete.....";
						?>
                 		</p>
                        <p class="c">	
                        	Done
                        </p>
                    </div>                
          </div>
                
    <?php			
				$_SESSION['msg']='';
			}
		}
	?>  
					
                        
        <!----------------------------------------------------------------------------------------------------------!-->
                         
	

<div class="content">








<?php
	include('header.php');
?>


<div class="help-note" >
    	Helping You And Find Government Information & Servies.
    </div>

<div class="service_main_div">

	<div class="service_menu">
    	
        <div class="li_menu">
        	<?php
			include('service_menu_li.php');
			?>
        </div>
    
    </div>
    
    <div class="service_show">
    	<span class="fa fa-angle-double-left" id="click"></span>
 
          <div class="margin-set">   
<!-- = = = = = = = = = = = = = = = =  Margin-set = = = = = = = = = = = = = = = = = !-->       
           
             
            <div class="job">
                
            <div class="show_border">    
  
  <!-- / / / / / / / / / / / /  Show vacancie details  / / / / / / / / / / / / / !--> 	

                    <span class="detail_head_show">Vacancie Details</span>
                	<div class="show_job_vac_details">
                    </div>
                    
  <!-- / / / / / / / / / / / /  Show vacancie details  / / / / / / / / / / / / / !--> 	

            </div>    
            
            
            
            
            
            
    
<!-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Apply Notes  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ !-->    
    <div class="apply_note">
    	If you are able for this job than <span class="apply_click">apply</span>
    </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ End Apply Notes  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ !-->                
            
            
<script>
$(document).ready(function(e) {
	$('.apply_click').click( 
	function (e){ $('.job_apply_table').slideToggle('slow')	})
					});

</script>           
            
                	

<div class="error_msg">                    
	<?php
		if(isset($_SESSION['error_msg']))
		{
			if($_SESSION['error_msg']=="error")
			{
				echo "Please Enter the all details.";
				$_SESSION['error_msg']='';
			}
		}
	?>  
</div>         
               
               
  <!-- = = = == = = = = = = = = = = = Job Apply table  = = = = = = = = = = = = = = = !-->             
               <div class="job_apply_table">
					
                    <h3 class="apply-job-h3">Apply For Job's</h3>
                    
                    
                 <form action="services_gov_jobs_data.php?apply_job=<?php echo $_REQUEST['a'];?>" method="post" enctype="multipart/form-data">

                    <table class="apply_table">
                    <tr>
                        <td>
                            <input type="text" required="required" placeholder=" Enter Full Name" class="full_name_input" name="fname" onblur="check_fname()"/>
                            <div id="fname_error">
                            </div>
                        </td>
                    </tr>
                      
                    <tr>
                    	<td>
                        	<input type="text" required="required" placeholder=" Age " class="age_input"  maxlength="2" name="age" onblur="check_age()"/>
                            <div id="age_error">
                            </div>
                      	</td>
                    </tr>
                      
                    <tr>
                    	<td class="radio-td">
                      	<input type="radio" name="gender" class="job_radio" value="male" required="required"/> Male
                        <input type="radio" name="gender" class="job_radio" value="female" required="required"/> Female
                        
                        </td>
                    </tr> 
                    
                    <tr>
                     	<td>
	                        <input type="text" placeholder=" Email_id" class="email_input" name="email" required="required" onblur="check_email()"/>
                            <div id="email_error">
                            </div>
                        </td>
                     </tr>   
                      
                    <tr>
                     	<td>
	                        <input type="text" placeholder=" Mobile Number" class="mobile_input" maxlength="10" required="required" name="mobile" onblur="check_mob();"/>
                            <div id="mobile_error">
                            </div>
                        </td>
                     </tr>
                    
                    <tr>
                    	<td>  
                        
                        	<textarea placeholder=" Full Address" class="address_input" name="address"  required="required"
                     onblur="check_add();"></textarea>  
                        	<div id="address_error">
                            </div>
                      	</td>
                    </tr>
                        
<script>
	$(document).ready(function(e) {
        $('.year-select').click( function(e){
			$('.hide').remove();
			})
    });
	
</script>
					 <tr>
                        <td class="ex_set_td">
                              Experience : 
                                <select class="year-select" name="ex_year" required="required" onblur="call();">
                                 
                                    <option class="hide">Select</option>
                                    <?php
                                    $a=0;
                                    while($a<40)
                                    {
                                    ?>	
                                    <option value="<?php echo $a;?>"><?php echo $a;?></option>	
                                    <?php
                                        $a++;
                                    }
                                    ?>
                                </select>
                                Year
                        </td>
					  </tr>	                        
                      
                      
                       <tr>
                       	 <td>
                         <input type="text" required="required" placeholder=" Your Skill" name="skill" class="skill_input" onblur="check_skill();"/>
                         <div id="skill_error">
                            </div>
                         </td>
                       </tr>
                      
                      
                      <tr>
                        <tr>
                        	<td class="certi_td">
                            	<p class="certi_td_data">
                            		<span class="certi_head" >Add Certificates : </span>
                            	<input type="file" required="required" name="file[]" class="file_input"  multiple="multiple"/>
                             	</p>
                                <p class="certi_notes">Note : Each Document Size Maximum 1 MB.</p>

                             </td>
                        </tr>
                        
                        
                        <tr>
                        	<td>    
                            <input type="submit" Value="Submit" class="submit-btn" />
                            </td>
                        </tr>
         
                       </table>
                 </form>
                      
                    </div>
  <!-- = = = = = = = = = = = = = = = = End Job Apply table  = = = = = = = = = = = = = = = !-->                             
                </div>
             
          </div>
<!-- = = = = = = = = = = = = = = = =  End Margin-set = = = = = = = = = = = = = = = = = !-->       

    </div>

</div>


<?php
	include('footer.php');
?>
</div>

</body>
</html>
<?php
	
	
	}
	else
	{
		header('Location:services_gov_jobs.php');
	}
	
}
else
{
	header('Location:services_gov_jobs.php');
}
?>