<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/user_profile_css.css" type="text/css" />
<link rel="stylesheet" href="css/user_edit_profile_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<script src="jq/diaplay-image.js" ></script>

<script>
	function chara()
	{
			var n=$('.fname').val();
	
			if(n == "" || n == " ")
			{ 
//				document.getElementById("fname").innerHTML="<p class='clr'> First Name Cannot Leave Blank ..!! </p>";
				$('.fname').focus();
			}
			else
			{
	//			document.getElementById("fname").innerHTML="<font></font>";
				if(/^[aA-zZ]*$/.test(n))
				{}
				else
				{		
		//			document.getElementById("fname").innerHTML="<p class='clr'> Character Only ..!! </p>";
					$('.fname').focus();
				}
			}

	}
</script>

</head>

<body>
	

<div class="content">
<?php
	include('header.php');
	
	$user_qry="select * from user_reg where u_id='".$r['u_id']."'";
	$user_result=mysql_query($user_qry,$con);
	$user_row=mysql_fetch_assoc($user_result);	

	$acc_qry="select * from user_acc where u_id='".$r['u_id']."'";
	$acc_result=mysql_query($acc_qry,$con);
	$acc_row=mysql_fetch_assoc($acc_result);	
	
	include('user_profile_script.php');	
?>

<!-- - - - - - - - - - - - - - - - work page - - - - - - - - - - - - - - - - - !-->

	 <div class="user_profile">
		<div class="user_profile_data">  
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->

<!-- - - - - - - - - - - - - - - column - - - - - - - - - - - - - - - - - - !-->            
<?php
	include('column.php');
?>            
<!-- - - - - - - - - - - - - - - end column - - - - - - - - - - - - - - - - - - !-->            
            
          

<!-- - - - - - - - - - - - - - - row - - - - - - - - - - - - - - - - - - !-->            
<?php
	include('row.php');
?>            
<!-- - - - - - - - - - - - - - - end row- - - - - - - - - - - - - - - - - - !-->            
            
            


         
         
         
         
<!-- - - - - - - - - - - - - - - show - - - - - - - - - - - - - - - - - - !-->

	<div class="show" >
    
   
    
    <div class="table_show">


<!----------------------------------------------------------------------------------------!-->    
    	<div class="table_1">
        
    	<table class="table">
           
           <form action="user_profile_data.php?check=profile" method="post" name="f1">
           <?php $_SESSION['u_id']=$name;?>
           <tr><th colspan="2"> Edit Your Profile </th></tr>
           
           <tr><td class="td-spce"> </td></tr>
           
        	<tr>
            	<td> First Name : </td>
            	<td><input type="text" value="<?php echo ucfirst($user_row['fname']) ;?>" name="fname" class="fname" onblur="chara();"/></td>
            </tr>
            
            <tr>
            	<td> Last Name : </td>
            	<td><input type="text" value="<?php echo ucfirst($user_row['lname']) ;?>" name="lname"/></td>
            </tr>
            
            
            <tr>
            	<td> Gender :</td>
                <td><input type="text" value="<?php echo ucfirst($user_row['gender']) ;?>" name="gender" /></td>
            </tr>
            
            <tr>
            	<td> Mobile :</td>
                <td><input type="text" value="<?php echo $user_row['phone_no'] ;?>" name="mobile" maxlength="10" /></td>
            </tr>
            
            
            <tr>
            	<td colspan="2"><input type="submit" name="Update"  value="Save" class="update_btn"/></td>
            </tr>
           </form> 
            
        </table>

    </div>
    
    
    
    
    
    <div class="table_2">
    
    <table class="table">
    
    <form action="user_profile_data.php?check=acc" method="post">
    <?php $_SESSION['u_id']=$name;?>
    		<tr><th colspan="2"> Add Other Details </th></tr>
        	
            <tr><td class="td-spce"> </td></tr>
        	
            <tr>
            	<td> Country :</td>
            	<td><input type="text" value="<?php echo ucfirst($acc_row['country']) ;?>" name="country"/>
                </td>
            </tr>
            
            <tr>
            	<td> State :</td>
                <td><input type="text" value="<?php echo ucfirst($acc_row['state']) ;?>" name="state" /></td>
            </tr>
            
            
            <tr>
            	<td> District :</td>
                <td><input type="text" value="<?php echo ucfirst($acc_row['distric']);?>" name="dis"/></td>
            </tr>
            
            <tr>
            	<td> Address :</td>
                <td><input type="text" value="<?php echo ucfirst($acc_row['address']);?>" name="address"/></td>
            </tr>
            
            <tr>
            	<td colspan="2"><input type="submit" name="submit"  value="Save" class="update_btn"/></td>
            </tr>
            
       </form>     
            
        </table>

	</div>
<!----------------------------------------------------------------------------------------!-->    
    	
        
        <div>
    
    </div>
         
<!-- - - - - - - - - - - - - - - End show - - - - - - - - - - - - - - - - - - !-->         
         
         
            
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->            
        </div>
     </div>
    
<!-- - - - - - - - - - - - - - - - End work page - - - - - - - - - - - - - - - - - !-->

<?php
	include('footer.php');
?>
</div>

</body>
</html>
