<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/user_css.css" type="text/css" />
<script src="jq/jquery.min.1.11.0.js"></script>

            <script>
				$(document).ready(function(e) {
                    $(".flip").click(function(e) {
                        $(".panel").slideToggle("slow");
                    });
                });
			</script>
</head>

<body>
	
        

<?php
	include('header.php');
?>

<div class="content">
	
    <p>
    	sdfljsfsdfds
    </p>
    <?php
    if (!isset($_SESSION['u_id']))
	{
		echo "Please Login for Comments  ";
		echo "<a href=reg.php> Login </a>";
	}
	else
	{
    ?>
	<div>
    	<input />
        <input type="button" value="comment" />
    </div>
	<?php
	}
	?>
</div>

<?php
	include('footer.php');
?>


</div>

</body>
</html>