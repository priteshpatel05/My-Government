
<div class="user_head_row">
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->
          <script>
		 $(document).ready(function(e) {
                    $(".click").click(function(e) {
                        $(".profile_img").show("slow");
                    });
                });
		  </script>
          
            	
               
    
                
                <div class="user_task">
                
                	<div class="cmt_post">
                    	
                        <span class="post cmt_count"></span>
                    	<span class="fa  fa-comments"></span>
                    	<a href="user_cmt_post.php">
                        <span class="post_h3">Comment Post</span>
                    	</a>
                        
                    </div>
                    
                    <div class="cmt_post">
                    
                    	<span class="post problem_count"></span>
                    	<span class="fa  fa-exclamation-circle"></span>
                        <a href="user_problem_post.php">
                    	<span class="post_h3">Problem Post</span>
                    	</a>
                    </div>
                    
                    <div class="cmt_post">
                    
                    	<span class="post idea_count"></span>
                    	<span class="fa  fa-lightbulb-o"></span>
                    	<a href="user_idea_post.php">
                        <span class="post_h3">Idea's Post</span>
                    	</a>
                    </div>
                
                	<div class="cmt_post">
                    	<span class="post mail_count"></span>
                    	<span class="fa  fa-envelope-o"></span>
                    	<a href="user_inbox.php" >
                        <span class="post_h3">Inbox</span>
                   		</a>
                    </div>
                    
              </div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->
</div>
