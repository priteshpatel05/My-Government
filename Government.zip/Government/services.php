<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<?php
include('service_script.php');
?>
</head>

<body>
	

<div class="content">
<?php
	include('header.php');
?>


<div class="help-note" >
    	Helping You And Find Government Information & Servies.
    </div>

<div class="service_main_div">

	<div class="service_menu">
    	<?php
			include('service_menu_li.php');
		?>
    </div>
    
    <div class="service_show">
        <span class="fa fa-angle-double-left" id="click"></span>
        
        
        
          <div class="margin-set">   
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->    
    
    
    
    <div class="service">
		<div class="service_data">    
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->    		
        
         		<!--<img src="img/board.jpg"  class="service_img"/>!-->
   			<p class="feedback_heading">Services</p>
			<hr />
    
        	<div>
            		<img src="img/servivce img/our-services-banner.jpg" class="s_img"/>
                    
				
            <table class="s_table">
            
            <tr>	
            	<td class="s_td1">
                    <span class="fa fa-chevron-right s_span "> </span>
                	Problem :-
                </td>
                <td class="s_td2">
                  You can share your Problem OR Discuss on your problem with other user.
                </td>
            </tr>                  
            
            
            <tr>	
            	<td class="s_td1">
                    <span class="fa fa-chevron-right s_span "> </span>
                   	New Ideas :-
                </td>
                <td class="s_td2">
					You can give your New ideas Which is may be very Important OR Usefull.
                </td>
            </tr>                  
                  
            <tr>	
            	<td class="s_td1">
                    <span class="fa fa-chevron-right s_span "> </span>
                    	Governments Rules :-
                </td>
                <td class="s_td2">
                        You can see all governments related Rules.
                </td>
            </tr> 
            
            
             <tr>	
            	<td class="s_td1">
                    <span class="fa fa-chevron-right s_span "> </span>
                    	Job Vacancies :-
                </td>
                <td class="s_td2">
                        In this provide many government related Job's vacancies. You can see Detail of vacancie and if you are intrested or able for this job than you can apply. Also provid Job apply Form. 
                </td>
            </tr>                  


             <tr>	
            	<td class="s_td1">
                    <span class="fa fa-chevron-right s_span "> </span>
                    	Honours & Awards :-
                </td>
                <td class="s_td2">
                        You can see all indian government Honours and Awards.
                </td>
            </tr>                  


             <tr>	
            	<td class="s_td1">
                    <span class="fa fa-chevron-right s_span "> </span>
                    Student Scholarship :-
                </td>
                <td class="s_td2">
                        You can see Scholarship of student which is provided by many organization.
                </td>
            </tr>                  

		</table>
          </div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->     
        </div>
	</div>
    
    
    
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->    
          </div>
    </div>

</div>


<?php
	include('footer.php');
?>
</div>

</body>
</html>
