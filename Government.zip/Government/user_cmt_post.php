<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/user_profile_css.css" type="text/css" />
<link rel="stylesheet" href="css/user_post_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<script src="jq/diaplay-image.js" ></script>



</head>

<body>
	

<div class="content">
<?php
	include('header.php');
	
	$user_qry="select * from user_reg where u_id='".$r['u_id']."'";
	$user_result=mysql_query($user_qry,$con);
	$user_row=mysql_fetch_assoc($user_result);	

	$acc_qry="select * from user_acc where u_id='".$r['u_id']."'";
	$acc_result=mysql_query($acc_qry,$con);
	$acc_row=mysql_fetch_assoc($acc_result);	
	
	include('user_profile_script.php');
	
?>

<!-- - - - - - - - - - - - - - - - work page - - - - - - - - - - - - - - - - - !-->

	 <div class="user_profile">
		<div class="user_profile_data">  
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->
          



<!-- - - - - - - - - - - - - - - column - - - - - - - - - - - - - - - - - - !-->            
<?php
	include('column.php');
?>            
<!-- - - - - - - - - - - - - - - end column - - - - - - - - - - - - - - - - - - !-->            

<!-- - - - - - - - - - - - - - - row - - - - - - - - - - - - - - - - - - !-->            
<?php
	include('row.php');
?>            
<!-- - - - - - - - - - - - - - - end row- - - - - - - - - - - - - - - - - - !-->            
            
            
         
         
	<div class="show" >
<!-- - - - - - - - - - - - - - - show - - - - - - - - - - - - - - - - - - !-->

	<div class="cmt_div">
    
		<div class="cmt_show_table">
        
        	<p class="cmt_head">  Comments  </p>
        
        
        
        
       		<div class="display" ></div>
        
        
        
                    
        </div>    
    
     </div>    
<!-- - - - - - - - - - - - - - - End show - - - - - - - - - - - - - - - - - - !-->         
    </div>
            


<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->            
        </div>
     </div>
    
<!-- - - - - - - - - - - - - - - - End work page - - - - - - - - - - - - - - - - - !-->

<?php
	include('footer.php');
?>
</div>

</body>
</html>
