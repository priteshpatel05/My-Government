<?php
session_start();
if(isset($_REQUEST['task']))
{
	$con=mysql_connect("Localhost","root","");
	mysql_select_db("mygov",$con);	
	
	$open_qry="select * from upload where id_up='".$_REQUEST['task']."'";
	$open_result=mysql_query($open_qry);
	$open_row=mysql_fetch_assoc($open_result);
	$n=mysql_num_rows($open_result);
	
	$no_like_sql =  "SELECT count(id_up) from likers where id_up = '".$open_row['id_up']."' ";
	$res = mysql_query($no_like_sql);
	
	if($n==1)
	{
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>open blog</title>

<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/open_blog_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />

<script src="jq/jquery.min.1.11.0.js"></script>

<!--================= likes & comments script ==================!-->

<?php
	include('open_blog_script.php');
?>

<!--================= End likes & comments script ==================!-->


<!-- - - - - - - - - - - - - Login divion - - - - - - - - - - -!-->
<script>
		 $(document).ready(function(e) {
                    $(".click").click(function(e) {
                        $(".new_div").fadeIn(500);
                    });
                });
		
		 $(document).ready(function(e) {
                    $(".close").click(function(e) {
                        $(".new_div").hide();
                    });
                });

</script>
<!-- - - - - - - - - - - - - Login divion - - - - - - - - - - -!-->

</head>

<body>

<div class="content">

<!-- ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,Login divion,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,!-->
<div class="new_div">
		
    <?php
		$id="discuss";
		$_SESSION['id_up']=$open_row['id_up'];
		include('login.php');
	?>
</div>
<!-- ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,end Login divion ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,!-->


<?php
	include('header.php');
?>




<div class="work">

	<div class="open-img-div">
        <img src="<?php echo 'upload/'.$open_row['img']; ?>" class="open-image" />
	</div>
            <div class="blog_detail">
            
                <h2> <?php	echo $open_row['sub']."<br>";  ?></h2>
                
                <span class="fa fa-calendar"></span>
                <h5> <?php echo $open_row['date']."<br>"; ?></h5>
                    
                <h4> <?php	echo $open_row['tex']."<br>"; ?></h4>
            
            </div>
            
            
            
<!-- ********************************* check User Login or Not ********************************* !-->            
		<?php 
			if(!isset($name))
			{
				
/* ********************************* check User Login or Not ********************************* */            				
	?>
            <div class="discuss-login-div">
            		<span class="discuss-login">
                   
                    If you want Discuss About this topic than First <a href="#" class="d-l-a click"> Login or Registration</a>
                    <span class="tooltip"> Click </span>
            		
                    </span>
            </div>
    	<?php

/* ****************************************************************** */

			}
		?>
        
<!-- ********************************* check blog or Discuss ********************************* !-->        
            
</div>

<!-- ********************************* check blog or Discuss ********************************* !-->    

<?php 
if(isset($_SESSION['page']))	
{
	if($_SESSION['page']=="blog")
	{
	}
	else if($_SESSION['page']=="discuss")
	{
?>
		

<!-- ********************************* User Area ********************************* !-->    
	<?php  
        if(!isset($name))
        {
			include('open_blog_0_like_cmt.php');
		}	
        else if(isset($name))
        {
	?>
        <div class="user_area">
    
    <?php		
			
			if($open_row['status']=='0')
			{
				include('open_blog_0_like_cmt.php');				
			}
			else if($open_row['status']=='1')
			{
				include('open_blog_1_like_cmt.php');				
			}
    ?>
    
    
        
                    
                    
                    
                    
                    
                    <div class="cmt-div">
                        
                      
                            
                             <?php
				  		$status_q="select * from upload where id_up='".$open_row['id_up']."'";
						$status_result=mysql_query($status_q,$con);
						$status_row=mysql_fetch_assoc($status_result);
						if($status_row['status']=='1')
						{
					?>
                      <div class="cmt">
                    		 <input type="text" class="cmt-input" placeholder="Comments" name="cmt"/>
                            <input type="button" class="submit_cmt" value="Submit" onclick="comment('<?php echo $name; ?>','<?php echo $open_row['id_up'];?>')"/>
                    <?php
						}
						else if ($status_row['status']=='0')
							 {
					?>
                    			
                    <?php
							 }
				  ?>
                                       <div id="complete">
                                       </div>
                                        
                                        <div id="cmt-show"> 
                                        </div>
                        </div>   
                        
                                     	
                    </div>
               
        
      
    <?php			
		}	
    ?>
						      

<!-- ********************************* End User Area ********************************* !-->    

<?php
	}
}
?>

<!-- ********************************* End check blog or Discuss ********************************* !-->    

	<?php
        include('footer.php');
    ?>
    
    
</div>


</body>
</html>


<?php

	}
	else
	{
		header('Location:blog.php');	
	}



}
else
{
	header('Location:blog.php');	
}
?>