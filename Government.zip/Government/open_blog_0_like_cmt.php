        <div class="user_area">
        
                    <div class="show-result">
                
                        <div class="show-like">
                        	<span id="count_like" class="fa fa-thumbs-up like" ></span> 
                        </div>            
    					<div  class="show-unlike">
                        	<span id="count_unlike" class="fa fa-thumbs-down like" ></span> 
						</div>
    					
                        <div class="cmt_count">
                        </div>
                        
                    </div>
                    
                    <div class="cmt-div">
                                        <div id="cmt-show"> 
                                        </div>
                    </div>
               
        </div>  
