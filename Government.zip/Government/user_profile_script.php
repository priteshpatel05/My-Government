<script>

/*-------------------------------- count -----------------------------------------*/
	cmt_count();
	function cmt_count()
	{
		var view=1;
		var id='<?php echo $name;?>';
		$.post('user_profile_data.php',{cmt_count:view,id:id},function(t){
				$('.cmt_count').html(t);
		});
	}
	
	problem_count();
	function problem_count()
	{
		var view=1;
		var id='<?php echo $name;?>';
		$.post('user_profile_data.php',{problem_count:view,id:id},function(t){
				$('.problem_count').html(t);
		});
	}

	idea_count();
	function idea_count()
	{
		var view=1;
		var id='<?php echo $name;?>';
		$.post('user_profile_data.php',{idea_count:view,id:id},function(t){
				$('.idea_count').html(t);
		});
	}
	
	mail_count();
	function mail_count()
	{
		var view=1;
		var id='<?php echo $r['email_id'];?>';
		$.post('user_profile_data.php',{mail_count:view,id:id},function(t){
				$('.mail_count').html(t);
		});
	}



/*-------------------------------- count -----------------------------------------*/
	
	
	
/*-------------------------------- comment -----------------------------------------*/
	
	viewall();
	function viewall()
	{
		var view=1;
		var id='<?php echo $name;?>';
		//alert(id);
		$.post('user_profile_data.php',{cmt_view:view,id:id},function(t){
				$('.display').html(t);
		});
	}
	
	function cmt_del(no)
	{
		//alert(no);
		var id='<?php echo $name;?>';
		$.post('user_profile_data.php',{cmt_no:no,id:id},function(t){
				$('.display').html(t);
		});
		cmt_count();
	}
/*-------------------------------- comment -----------------------------------------*/



/*-------------------------------- problem -----------------------------------------*/
	problem_viewall();
	function problem_viewall()
	{
		var view=1;
		var id='<?php echo $name;?>';
		//alert(id);
		$.post('user_profile_data.php',{problem_view:view,id:id},function(t){
				$('.problem_display').html(t);
		});
		problem_count();

	}
	
	function problem_del(no)
	{
		//alert(no);
		var id='<?php echo $name;?>';
		$.post('user_profile_data.php',{problem_no:no,id:id},function(t){
				$('.problem_display').html(t);
		});
		problem_count();
	}

/*-------------------------------- problem -----------------------------------------*/






/*-------------------------------- idea -----------------------------------------*/
	idea_viewall();
	function idea_viewall()
	{
		var view=1;
		var id='<?php echo $name;?>';
		//alert(id);
		$.post('user_profile_data.php',{idea_view:view,id:id},function(t){
				$('.idea_display').html(t);
		});
		idea_count();

	}
	
	function idea_del(no)
	{
		//alert(no);
		var id='<?php echo $name;?>';
		$.post('user_profile_data.php',{idea_no:no,id:id},function(t){
				$('.idea_display').html(t);
		});
		idea_count();
	}

/*-------------------------------- problem -----------------------------------------*/



/*-------------------------------- inbox -----------------------------------------*/
	inbox_viewall();
	function inbox_viewall()
	{
		var view=1;
		var id='<?php echo $r['email_id'];?>';
		//alert(id);
		$.post('user_inbox_data.php',{inbox_view:view,id:id},function(t){
				$('.inbox_display').html(t);
		});
		

	}
	
	function inbox_del(no)
	{
		//alert(no);
		var id='<?php echo $r['email_id'];?>';
		$.post('user_inbox_data.php',{inbox_delete_no:no,id:id},function(t){
				$('.inbox_display').html(t);
		});
		inbox_count();
	}

/*-------------------------------- inbox -----------------------------------------*/
	

</script>