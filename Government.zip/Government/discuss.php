<?php
	session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);
	
	$g_qry="select * from grp_tbl";
	$g_result=mysql_query($g_qry,$con);		
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/blog_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>


<!------------------------------- Blog Script ---------------------------------!-->

<?php
	include('discuss_script.php');	
?>

<!------------------------------- End Blog Script ---------------------------------!-->

</head>

<body>
	

<div class="content">
<?php
	include('header.php');
?>

<div class="blog_view">
    
    
	<?php
		include('group_text.php');
	?>

<!--========================= Blog show =======================================!-->
        <div class="show">
             
               
        </div>

<!--========================= End Blog show =======================================!-->
            
</div>
<?php
	include('footer.php');
?>
</div>


</body>
</html>
