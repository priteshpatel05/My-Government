<?php
session_start();

if(isset($_REQUEST['cmt_count']))
{
	cmt_count();
}

if(isset($_REQUEST['like']))
{
	likes();
}

else if(isset($_REQUEST['view_like']))
{
	show_like($_REQUEST['view_like']);	
}

else if(isset($_REQUEST['view_unlike']))
{
	show_unlike($_REQUEST['view_unlike']);	
}

else if(isset($_REQUEST['s']))
{
	comments();	
}

else if(isset($_REQUEST['view_test']))
{
	//echo $_REQUEST['view_test'];
	view($_REQUEST['view_test']);	
}




/*================================= Cmt_count ====================================*/
	function cmt_count()
	{

		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);

		$c_qry="select count(no) from cmt where id_up='".$_REQUEST['cmt_count']	."'";
		$c_result=mysql_query($c_qry,$con);
		$c_row=mysql_fetch_array($c_result);
		$cmt=$c_row[0];
							
		echo "Total Comments : (".$cmt.")";
	}
/*================================= End Cmt_count ====================================*/




/*================================= likes ====================================*/

	function likes()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		if($_REQUEST['like']=="like")
		{
			$q="select * from likers where u_id='".$_REQUEST['uid']."' and id_up ='".$_REQUEST['id']."'";
			$a=mysql_query($q,$con);
			$z=mysql_fetch_assoc($a);
			
			if($z['status']=='')
			{
				$qry="insert into likers values('','".$_REQUEST['uid']."','".$_REQUEST['id']."','1')";
				mysql_query($qry);
				show_like($_REQUEST['id']);
			}
			else if($z['status']=='2')
				{
					$qry="UPDATE  likers SET  status =  '1' WHERE u_id = '".$_REQUEST['uid']."' AND id_up ='".$_REQUEST['id']."'";
					mysql_query($qry);
	
					show_like($_REQUEST['id']);
			
				}
				else
				{
					show_like($_REQUEST['id']);
				}
			
		}
		
		else if($_REQUEST['like']=="unlike")
		{
			$q="select * from likers where u_id='".$_REQUEST['uid']."' and id_up ='".$_REQUEST['id']."'";
			$a=mysql_query($q,$con);
			$z=mysql_fetch_assoc($a);
			
			if($z['status']=='')
			{
				$qry="insert into likers values('','".$_REQUEST['uid']."','".$_REQUEST['id']."','2')";
				mysql_query($qry);
				show_unlike($_REQUEST['id']);
			}
			else if($z['status']=='1')
			{
				$qry="update likers set status='2' where u_id='".$_REQUEST['uid']."' and id_up='".$_REQUEST['id']."'";
				mysql_query($qry);
			
				show_unlike($_REQUEST['id']);
			}
			else
			{
				show_unlike($_REQUEST['id']);
			}
			
		}

	}



	function show_like($a)
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		$no_like_sql =  "SELECT count(status)  from likers where status='1' and id_up = '".$a."' ";
		$res = mysql_query($no_like_sql,$con);
			
		echo mysql_result($res,0);
	}

	function show_unlike($a)
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		$no_like_sql =  "SELECT count(status)  from likers where status='2' and id_up = '".$a."' ";
		$res = mysql_query($no_like_sql,$con);
			
		echo mysql_result($res,0);
	}

	
/*================================= End likes ====================================*/	
	


/*================================= Comments ====================================*/	
	function comments()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);	
		
		$d=date('d-M-Y');
			
		$c_qry="insert into cmt values('',
										  '".$_REQUEST['id']."',
										  '".$_REQUEST['cmt']."',
										  '".$_REQUEST['up']."',
										  '".$d."',
										  '1')";
		mysql_query($c_qry,$con);
		view($_REQUEST['up']);
	}


	function view( $id )
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$show="select * from cmt where id_up='".$id."' order by no desc ";
		$show_result=mysql_query($show,$con);
		
		while($show_row=mysql_fetch_assoc($show_result))
		{
			
			$s="select * from user_reg where u_id='".$show_row['u_id']."'";
			$s_r=mysql_query($s,$con);
			
			$s_row=mysql_fetch_assoc($s_r);
			echo "<div class='full-dis'>";
			echo "<div class='dis-div'>";			
			
			echo "<img src='".$s_row['pro_pic']."' class='cmt-pro-pic' />";
			echo "<div class='u-cmt-name'>".ucfirst($s_row['fname']).
					"&nbsp;&nbsp;".$s_row['lname']."</div>".
				  "<div class='date'>".$show_row['date']."</div>";
			
		
			echo "<div class='dis-cmt'>".$show_row['comment']."</div>";			
			echo "</div>";
			echo "</div>";
			
		}
	}

/*================================= End Comments ====================================*/
?>