
<script>
				$(document).ready(function(e) {
					var temp = "0";
                    $("#click").click(function(e) {
						if (temp=="0")
						{
                         	$('.service_menu').css('transform','translateX(-200px)');
						 	$('.service_show').css('transform','translateX(-200px)');
							$('.margin-set').css('transform','translateX(100px)');
							$(this).removeClass('fa-angle-double-left');
							$(this).addClass('fa-angle-double-right');
							temp = "1";
						}
						else
						{
							$('.service_menu').css('transform','translateX(0px)');
						 	$('.service_show').css('transform','translateX(0px)');
							$('.margin-set').css('transform','translateX(0px)');
							$(this).removeClass('fa-angle-double-right');
							$(this).addClass('fa-angle-double-left');
							temp = "0";
						}
						
                    });
                });

</script>
