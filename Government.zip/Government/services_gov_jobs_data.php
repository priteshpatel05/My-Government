<?php
session_start();


/*= = = = = = = = = = = = = = = = = Job apply form call = = = = = = = = = = = = = */
if(isset($_REQUEST['apply_job']))
{
/*	 echo $_REQUEST['fname']."<br>";
	 echo  $_REQUEST['age']."<br>";
	 echo $_REQUEST['gender']."<br>";
	 echo $_REQUEST['email']."<br>";
	 echo $_REQUEST['mobile']."<br>";
	 echo $_REQUEST['address']."<br>";
	 echo $_REQUEST['ex_year']."<br>";
	 echo $_REQUEST['skill']."<br>";
	*/
	job_apply_form();
}

/*= = = = = = = = = = = = = = = = = End Job apply form call = = = = = = = = = = = = = */



/*= = = = = = = = = = = = = = = = = Show Full vacancies detalis call = = = = = = = = = = = = = */
if(isset($_REQUEST['details']))
{
	vacancies_details();
}
/*= = = = = = = = = = = = = = = = = End Show full vacancies detalis call = = = = = = = = = = = = = */



/*= = = = = = = = = = = = = = = = = Show All vacancies call = = = = = = = = = = = = = */
if(isset($_REQUEST['display_vacancies_no']))
{
	display_vacancies();
}
/*= = = = = = = = = = = = = = = = = End Show vacancies call = = = = = = = = = = = = = */




/*= = = = = = = = = = = = = = = = = Show vacancies detalis = = = = = = = = = = = = = */
	
	function vacancies_details()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$qry="select * from job_vacancies_tbl where v_id='".$_REQUEST['details']."'";
		$result=mysql_query($qry,$con);
	?>
		
	<table class="show_table">
        <?php
		
		while($row=mysql_fetch_assoc($result))
		{
		?>
        <tr>
			<td class="width-same" >Subject : </td>
            <td><span class="color"> <?php echo ucfirst($row['sub']);?> </span></td>
        </tr>
        
        <tr>
            <td class="width-same">Job Title : </td>
            <td><span class="color"><?php echo ucfirst($row['job_title']);?></span></td>
		</tr>
        
        <tr>	
            <td class="width-same" >Description : </td>
            <td><span class="color"><?php echo ucfirst($row['desc']);?> </span></td>
        </tr>
           
        <tr>
            <td class="width-same" >Age : </td>
            <td><span class="color"><?php echo ucfirst($row['age']);?></span></td>  
        </tr>   
        
        <tr>    
            <td class="width-same" >Experions : </td>
            <td><span class="color"><?php echo ucfirst($row['exp'])."&nbsp;year";?></span></td>          
        </tr>
        
        <tr>    
            <td class="width-same">Last Date of Apply : </td>
            <td><span class="color"><?php echo ucfirst($row['last_date']);?></span></td>          
        </tr>
        
        <tr>    
            <td class="width-same">Address : </td>
            <td><span class="color"><?php echo ucfirst($row['address']);?></span></td>
        </tr>
        
		<?php	
		}
		?>
    
    </table>	
		
	<?php
	}
/*= = = = = = = = = = = = = = = = = End Show vacancies detalis = = = = = = = = = = = = = */



/*= = = = = = = = = = = = = = = = = Job Apply Form = = = = = = = = = = = = = */
	function job_apply_form()
	{
		
		if( $_REQUEST['fname']=='')
		{
				$_SESSION['error_msg']="error";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);

		}
		else if( $_REQUEST['age']=='')
		{
				$_SESSION['error_msg']="error";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);

		}
		else if($_REQUEST['gender']=='')
		{
				$_SESSION['error_msg']="error";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);

		}
		else if( $_REQUEST['email']=='')
		{
				$_SESSION['error_msg']="error";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);

		}
		else if( $_REQUEST['mobile']=='')
		{
				$_SESSION['error_msg']="error";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);

		}
		else if( $_REQUEST['address']=='')
		{
				$_SESSION['error_msg']="error";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);

		}
		else if($_REQUEST['ex_year']=='')
		{
				$_SESSION['error_msg']="error";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);
			
		}
		else if($_REQUEST['skill']=='' )
		{
				$_SESSION['error_msg']="error";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);
		}
		else
		{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
		
			$date=date('d-m-Y');
			$id=rand(3000,20);
		
			
			$qry="insert into job_apply_tbl values('',
											   '".$_REQUEST['fname']."',
											   '".$_REQUEST['age']."',
											   '".$_REQUEST['gender']."',
											   '".$_REQUEST['email']."',
											   '".$_REQUEST['mobile']."',
											   '".$_REQUEST['address']."',
											   '".$_REQUEST['ex_year']."',
											   '".$_REQUEST['skill']."',
											   '".$date."',
											   '".$id."',
											   '".$_REQUEST['apply_job']."',
											   '1')";
								
			mysql_query($qry,$con);	
			
			
			for($i=0;$i<count($_FILES['file']['name']);$i++)
			{
				$file_name=$_FILES['file']['name'][$i];	
				move_uploaded_file($_FILES['file']['tmp_name'][$i],"upload/$file_name");
				
				$d="insert into documents values('',
													   '".$id."',
													   '".$file_name."')";
				mysql_query($d,$con);										   
			}
				$_SESSION['msg']="a";
				header('Location:services_job_form.php?a='.$_REQUEST['apply_job']);
		}
	}
/*= = = = = = = = = = = = = = = = = End Job Apply Form = = = = = = = = = = = = = */


	

/*= = = = = = = = = = = = = = = = = All Vacancies Display = = = = = = = = = = = = = */	
	function display_vacancies()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$qry="select * from job_vacancies_tbl order by no desc";
		$result=mysql_query($qry,$con);
	?>
		
	<table>
    	        
        <?php
		$q=1;
		while($row=mysql_fetch_assoc($result))
		{
		?>
        <tr>
			<td class="show_subject_td">
                <span class="fa fa-circle"></span>
                <div class="vac-text">
					<?php 
					if($q<4)
					{
					?>
                    <span class="sub_vac_a_new" >
						<?php echo ucfirst($row['sub']);?>
                    </span>
                    <a href="services_job_form.php?a=<?php echo $row['v_id'];?>"  class="view_more_a" >
						View More...
                	</a>
                	<?php
					}
					else
					{
					?>
                    <span class="sub_vac_a_old">
						<?php echo ucfirst($row['sub']);?>
					</span>
                    <a href="services_job_form.php?a=<?php echo $row['v_id'];?>" class="view_more_a" >
						View More...
                	</a>
                    <?php
					}
					$q++;
					?>
                 </div>
            </td>        
            <td class="p_date">
            	<?php echo ucfirst($row['post_date']);?>
            </td>
        </tr>
        <?php	
		}
		?>
    
    </table>	
		
	<?php
	}
/*= = = = = = = = = = = = = = = = = End All Vacancies Display = = = = = = = = = = = = = */	


?>