<?php
session_start();

if(isset($_REQUEST['blog']))
{
//	echo $_REQUEST['page'];
	blog_display();
}

if(isset($_REQUEST['discuss']))
{
	discuss_display();
}


if(isset($_REQUEST['discuss_page']))
{
		discuss_display();
}

if(isset($_REQUEST['blog_page']))
{
	$page_name=$_REQUEST['blog_page'];
		blog_display();
}


if(isset($_REQUEST['blog_name']))
{
	if($_REQUEST['blog_name']=='blog')
	{
		echo "All Group";
	}
	else
	{
		echo ucfirst($_REQUEST['blog_name']);		
	}
}


if(isset($_REQUEST['discuss_name']))
{
	if($_REQUEST['discuss_name']=='discuss')
	{
		echo "All Group";
	}
	else
	{
		echo ucfirst($_REQUEST['discuss_name']);		
	}
}




	function blog_display()
	{
		
		$con=mysql_connect("localhost","root","");
		mysql_select_db("mygov",$con);	

		
		if(isset($_REQUEST['blog']))
		{	
			if($_REQUEST['blog']==='blog')
			{
				$qry="select * from upload order by no desc";
			}
		}
				
		if(isset($_REQUEST['g_name']))
		{
			if( $_REQUEST['g_name']=='all')
			{
				$qry="select * from upload order by no desc";
			}
			else
			{
				$qry="select * from upload where group_up ='".$_REQUEST['g_name']."' order by no desc";
			}
		}

		
		$result=mysql_query($qry);
		$n=mysql_num_rows($result);
		
		if($n==0)
		{
		?>
        	<div class="not_found">
            	<span class="not_found_msg">
					<?php echo "This Page Not avalible."; ?>
                </span>
            </div>
		<?php
        }
		?>
        <div class="my_footer">
        <?php
   		while($row=mysql_fetch_assoc($result))
        {		
    ?>		
          <div id="outer_div">      

	          	 <div class="border">
    	
                		<div class="blog-content">                   
                                <div class="blog_img_div">                    
                                        <img src=" <?php echo 'upload/'.$row['img']; ?> " class="blog_img" /> 
                                </div>
                        
                                <div class="inner_div">         
                                        <h2 class="h2" > <?php	echo $row['sub']."&nbsp;&nbsp;"; 	?> </h2>
                                
                                          <h6 class="h6" >
                                                <span class="fa fa-calendar"></span>
                                                <?php echo $row['date']."&nbsp;&nbsp;<br>"; ?>  
                                          </h6>
                                                                    
                                        <h4 class="h4"> <?php	echo $row['tex']."&nbsp;&nbsp;";	 ?></h4>
                                </div>
                   		 </div>  
                 
<!-- ****************************** check blog or discuss *********************************** !-->                 
                 <?php 
								$_SESSION['page']="blog";
				 ?>
                     <div class="read-more">
                     	 <a href="open_blog.php?task=<?php echo $row['id_up']; ?>" >Read More</a> 
                     </div>

<!-- ******************************  End check blog or discuss *********************************** !-->
                  
                  <div class="status">
                  <?php
				  		$status_q="select * from upload where id_up='".$row['id_up']."'";
						$status_result=mysql_query($status_q,$con);
						$status_row=mysql_fetch_assoc($status_result);
						if($status_row['status']=='1')
						{
					?>
                    		<div class="process">In Process</div>
                    <?php
						}
						else if ($status_row['status']=='0')
							 {
					?>
                    			<div class="process-close">Close</div>
                    <?php
							 }
				  ?>
                  	
                  </div>
                  
                  
    	          </div>
                               
           </div>

		<?php
            }
			?>
            
            </div>
            

			<?php

	}
	
	
	
	
	
	function discuss_display()
	{
		
		$con=mysql_connect("localhost","root","");
		mysql_select_db("mygov",$con);	

		
		if(isset($_REQUEST['discuss']))
		{	
			if($_REQUEST['discuss']==='discuss')
			{
				$qry="select * from upload order by no desc";
			}
		}
				
		if(isset($_REQUEST['g_name']))
		{
			if( $_REQUEST['g_name']=='all')
			{
				$qry="select * from upload order by no desc";
			}
			else
			{
				$qry="select * from upload where group_up ='".$_REQUEST['g_name']."' order by no desc";
			}
		}

		
		$result=mysql_query($qry);
		$n=mysql_num_rows($result);
		
		if($n==0)
		{
		?>
        	<div class="not_found">
            	<span class="not_found_msg">
					<?php echo "This Page Not avalible."; ?>
                </span>
            </div>
		<?php
        }
		
   		while($row=mysql_fetch_assoc($result))
        {		
    ?>		
          <div id="outer_div">      

	          	 <div class="border">
    	
                		<div class="blog-content">                   
                                <div class="blog_img_div">                    
                                        <img src=" <?php echo 'upload/'.$row['img']; ?> " class="blog_img" /> 
                                </div>
                        
                                <div class="inner_div">         
                                        <h2 class="h2" > <?php	echo $row['sub']."&nbsp;&nbsp;"; 	?> </h2>
                                
                                          <h6 class="h6" >
                                                <span class="fa fa-calendar"></span>
                                                <?php echo $row['date']."&nbsp;&nbsp;<br>"; ?>  
                                          </h6>
                                                                    
                                        <h4 class="h4"> <?php	echo $row['tex']."&nbsp;&nbsp;";	 ?></h4>
                                </div>
                   		 </div>  
                 
<!-- ****************************** check blog or discuss *********************************** !-->                 
                 <?php					 
						$_SESSION['page']="discuss";
					 ?>                                                         
						 <div class="discuss-read-more">
							 
							 <a href="open_blog.php?task=<?php echo $row['id_up']; ?>" > Discuss </a> 
						 </div>                 
					 <?php
					 
				 ?>         

<!-- ******************************  End check blog or discuss *********************************** !-->
                  
                  <div class="status">
                  <?php
				  		$status_q="select * from upload where id_up='".$row['id_up']."'";
						$status_result=mysql_query($status_q,$con);
						$status_row=mysql_fetch_assoc($status_result);
						if($status_row['status']=='1')
						{
					?>
                    		<div class="process">In Process</div>
                    <?php
						}
						else if ($status_row['status']=='0')
							 {
					?>
                    			<div class="process-close">Close</div>
                    <?php
							 }
				  ?>
                  	
                  </div>
                  
                  
    	          </div>
                               
           </div>

		<?php
            }

	}
?>