
<?php
	session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	
		
	if(isset($_SESSION['call']))
	{
			if($_SESSION['call']=='problem')
			{
				$id=$_SESSION['call'];
				$_SESSION['call']='';
			}
			else
			{
				$id="reg";
			}
	}
	else
	{
		$id="reg";
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/home_css.css" type="text/css" />
<link rel="stylesheet" href="css/reg_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<script src="jq/cycle.js"> </script>
	<script>
        $(document).ready(function(e) {
            $(".cycle").cycle ({
                fx:'fade'
            });
        });
    </script>

<!-- =========== script =========== !-->
<?php
	include('script-reg.php');
?>
<!-- =========== script =========== !-->


</head>

<body>
	
<div class="content">

                    <div id="complete"> 
                    </div>


<?php
	include('header.php');
?>

<div class="main">
    
	<div class="log-div">
    	<div class="log">
        	
            <form action="check_login_data.php?task=check&a=<?php echo $id;?>" method="post" >
            
                <p><h2 class="log-h2">Login</h2></p>
                
                <p>
                	<input type="text" placeholder=" Email ID " name="mail_id" class="log-input " required="required"/> 
                
                	<input type="password" placeholder=" Password " name="pwd" class="log-input" required="required"/> 
                </p>
                
                <p>
                	<input type="submit" value="Submit" name="submit" class="log-submit"/> 
                </p>
				
                <?php
				
				if(isset($_SESSION['login_msg']))
				{
					if($_SESSION['login_msg']=='error')
					{
						?>
						<p class="login_error">
						<?php
							echo "Invelid Email ID OR Password";
							$_SESSION['login_msg']='';
						?>
						</p>
						<?php
					}
					else if($_SESSION['login_msg']=='msg')
					{
						?>
                   		 <p class="login_error">
                   		 <?php	
							echo "Don't Left Black Field";
							$_SESSION['login_msg']='';
						?>
                    	</p>
                   		 <?php
					}
			
				}
				
				?>
                </p>
        	</form>
        </div>    
    </div>
    
    
    <div class="set">
    	<span class="fa fa-angle-left" ></span>
            <p class="set-format"> 
                OR
            </p>
        <span class="fa fa-angle-right" ></span>
    </div>
    
    
    <div class="reg-div">
    		
		<div class="reg"> 
                    <div id="error"> </div>

        
<form action="#" method="post" name="f1">                
            <table>
	            <tr><th>Registration </th></tr>
	            
                <tr><td class="td-spce"> </td></tr>
               
                <tr>
                	<td>
                    <input type="text" placeholder=" First Name" name="fname" class="reg-input fname" onblur="check_fname();" />
      				<div id="fname"></div>
                    </td>
                </tr>
                
                <tr>
                	<td>
                    <input type="text" placeholder=" Last Name" name="lname" class="reg-input lname" onblur="check_lname();" />
      				<div id="lname"></div>
                    </td>
                </tr>
                
                <tr>
                	<td>
                      	<p class="color">
                	Gender :
                	<!--<input type="radio" name="radio" value="male" class="reg-input-radio"/>Male 
                    <input type="radio" name="radio" value="female" class="reg-input-radio"/>Female 
                	!-->
                    
                    <select class="select_g" onchange="select_g();">
                    	<option value="">Select</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                    
                    <div id="select_g"></div>
                    </p>
              
                    </td>
                </tr>
                
                <tr>
                	<td>
                    <input type="text" placeholder=" Mobile Number " name="mob" class="reg-input mob" maxlength="10" onblur="check_mob();"/>
               		<div id="mobile" > </div> 
                    </td>
                </tr>
                
                <tr>
                	<td>
                    <input type="text" placeholder=" Email Id " name="email" class="reg-input reg_mail" onblur="check_mail();"/>
               		<div id="reg-mail" ></div> 
                    </td>
                </tr>
            
            
            	<tr>
                	<td>
                    <p class="color"> Create Password </p>
                    </td>
                </tr>
            
				<tr>
                	<td>
          <input type="password" placeholder=" Create Password " name="cpwd" class="reg-input cpwd" onblur="check_cpwd();"/>
          	<div id="cpwd" ></div>
                    </td>
                </tr>
                
                
                <tr>
                	<td>
          <input type="password" placeholder=" Confirm Password " name="pwd" class="reg-input reg_pwd" onblur="check_pwd();" />
           <div id="pwd"> </div>
                    </td>
                </tr> 
                
                
                <tr>
                	<td>
          <input type="button" value="Submit" name="submit" class="reg-submit" onclick="submit_reg()"/> 
		<!--	<input type="submit" value="Submit" name="submit" class="reg-submit" /> !-->                    
        			</td>
                </tr> 
</table>                

</form>
                
    
    <?php
		if(isset($_SESSION['error']))
		{
			if($_SESSION['error']!='')
			{
			?>	
            	<script>
				submit_reg();
				</script>
			<?php	
				$_SESSION['error']='';
			
			}
		}
	?>      
            
        	
    	</div>
    </div>    
    
    
    
    
    <div class="login-reg-notes" >
    		Thank you for being a part of MyGov.In case you face any problem, please contact at admin@mygov.nic.in
    </div>
    
    
    
</div>

<?php
	include('footer.php');
?>
</div>



</body>
</html>