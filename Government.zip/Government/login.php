<!-- - - - - - - - - - - - - Login divion - - - - - - - - - - -!-->
<script>
		 $(document).ready(function(e) {
                    $(".click").click(function(e) {
                        $(".new_div").fadeIn(500);
                    });
                });
		
		 $(document).ready(function(e) {
                    $(".close").click(function(e) {
                        $(".new_div").hide();
                    });
                });

</script>
<!-- - - - - - - - - - - - - Login divion - - - - - - - - - - -!-->

    <span class="fa fa-times close"></span>

<div class="login_div">


	<div class="login_table">

     <form action="check_login_data.php?task=check&a=<?php echo $id;?>" method="post" >
    	
        <p class="login_table_head">
        	Login
        </p>
        
        <p class="p">
        	<input type="text" placeholder=" Email ID " class="login_email" name="mail_id" required/>
        </p>
        
        <p>
        	<input type="password" placeholder=" Password " class="login_pass" name="pwd" required/>
        </p>
        
        <p>
        	<input type="submit" value="Login" name="submit" class="login_btn"/>
        </p>
        
        <p class="create_new_acc_text">
        	<a href="reg.php">
            	Create New Account ?
            </a>
        </p>
        
	</form>
            
    </div>

</div>