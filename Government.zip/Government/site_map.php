<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	
	
	$qry="select * from upload order by no desc limit 4";
	$result=mysql_query($qry);

	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/footer_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>


</head>

<body>


<div class="content">
<?php
	include('header.php');
?>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -!-->
	<div class="site_map">

		<div class="site_map_data">
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -!-->
			<p class="site_map_heading">Site Map</p>
			<hr />
			
            <div class="header_menu">
            
            <h3 class="h3_header_menu">Primary Activities</h3>
            
             	<ul class="site_map_ul">
						<?php
                            $menu_qry="select * from menu";
                            $menu_result=mysql_query($menu_qry);
                
                            while($menu_row=mysql_fetch_assoc($menu_result))
                            {
                            
                        ?>
                            <span class="fa fa-square"></span> 	
                            <li>
                                <a href="<?php echo $menu_row['link_name'];?>">
                                        <?php  echo ucfirst($menu_row['m_name']); ?>
                                </a>
                            </li>
                                        
                        <?php		
                            }
                        ?>        	
                </ul>
                
            </div>


			<div class="footer_menu">
            
            <h3 class="h3_header_menu">Footer Links : </h3>
            
            	<ul class="site_map_ul">
						<?php
                        $f_qry="select * from footer_menu";
                        $f_result=mysql_query($f_qry,$con);
                        $z=1;
                    
                        
                        while($f_row=mysql_fetch_assoc($f_result))
                        {
                        ?>
                            <span class="fa fa-square"></span> 	
                            <li>
                                 <a href="<?php echo $f_row['f_link'];?>">  
                                    <?php echo ucfirst($f_row['f_menu']);?>
                                 </a>
                             </li>        
                          <?php 
                          }
                        ?>                   
                </ul>
                
            </div>



			<div class="service_menu">
            
            <h3 class="h3_service_menu">Service Links : </h3>
            
            	<ul class="site_map_ul">
						<?php
                        $f_qry="select * from service_menu";
                        $f_result=mysql_query($f_qry,$con);
                        $z=1;
                    
                        
                        while($f_row=mysql_fetch_assoc($f_result))
                        {
                        ?>
                            <span class="fa fa-square"></span> 	
                            <li>
                                 <a href="<?php echo $f_row['s_link'];?>">  
                                    <?php echo ucfirst($f_row['s_name']);?>
                                 </a>
                             </li>        
                          <?php 
                          }
                        ?>                   
                </ul>
                
            </div>



<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -!-->        
        </div>

	</div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -!-->
<?php
	include('footer.php');
?>
</div>

</body>
</html>
