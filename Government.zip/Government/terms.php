<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	
	
	$qry="select * from upload order by no desc limit 4";
	$result=mysql_query($qry);

	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/home_css.css" type="text/css" />
<link rel="stylesheet" href="css/footer_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />

<script src="jq/jquery.min.1.11.0.js"></script>

</head>

<body>

<div class="content">
<?php
	include('header.php');
?>





<!-- - - - - - - - - - - - - -terms page - - - - - - - - - - - - - - - !-->
	<div class="terms">
    	<div class="terms_data">
   
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->   
   		<h5 class="terms_heading">Terms & Conditions</h5>
        	
   		<hr />
        
        <div class="text_1">
      	  These terms of use describe your rights and responsibilities as a user of the mygov.in (MyGov). 
       	  To have a MyGov account, you must accept these terms of use.
        </div>
        
        <div class="text_2">
        
        MyGov, NIC, DeitY and Govt. of India reserve the right to make changes to MyGov and these terms of use at any time. If those changes affect your rights or responsibilities, you will be notified through MyGov. .
The following terms of use supersede and replace any terms and conditions you may have previously accepted governing your use of MyGov. The following Terms & Conditions come into effect as soon as you have accepted it and created your MyGov account.

        </div>
        
        <div class="text_3">

        As a user of MyGov you are granted a nonexclusive, nontransferable, revocable, limited license to access and use MyGov and content in accordance with these Terms of Use. Provider may terminate this license at any time for any reason.

        </div>

		<div class="text_4">
        MyGov designed & hosted by National Informatics Centre, Contents provided by the various Organizations, Departments and Ministries of Government of India.

        </div>



		<h2 class="head_of_text_5">LIMITATION ON USE:</h2>

		<p class="text_5">
        The Content on MyGov is for your personal use only and not for commercial exploitation. You may not decompile, reverse engineer, disassemble, rent, lease, loan, sell, sublicense, or create derivative works from MyGov. Nor may you use any network monitoring or discovery software to determine the site architecture, or extract information about usage, individual identities or users. You will not use any robot, spider, other automatic software or device, or manual process to monitor or copy MyGov without Provider’s prior written permission. You will not copy, modify, reproduce, republish, distribute, display, or transmit for commercial, non-profit or public purposes all or any portion of MyGov, except to the extent permitted by the copyright policy of this terms of use. Any unauthorized use of MyGov is prohibited. The use of any software (e.g. bots, scraper tools) or other automatic devices to access, monitor or copy the website pages is prohibited unless expressly authorized by the MyGov in writing.

        </p>

		<h2 class="head_of_text_6">
        	USER RESPONSIBILITY: 
        </h2>
        
        <h4 class="note_of_text_6">You must:</h4>
<br />
        <span class="fa  fa-square"></span>
        <p class="note_1">
        	Be a natural person to access or seek to access MyGov or a Member Service;
        </p>
        
        
        <span class="fa  fa-square"></span>
        <p class="note_1">
        	Not access or link to or seek to access or link to (either directly or indirectly) any other person's MyGov or Member Service account;
        </p>
        
        
        <span class="fa  fa-square"></span>
        <p class="note_1">
        	Not permit any other person to use your username and password; keep your MyGov account username, password, at all times and not disclose your password to anyone else;

        </p>
        
        
        
        <span class="fa  fa-square"></span>
        <p class="note_1">
        	Ensure your personal details (including your name and date of birth) are accurate and keep up to date with MyGov;

        </p>
        
        
        
        <span class="fa  fa-square"></span>
        <p class="note_1">
        	You are responsible for any use of your MyGov account using your username and password, whether or not such use has been authorized by you.


        </p>
        
        <span class="fa  fa-square"></span>
        <p class="note_1">
        	Details on MyGov may only be accessed through the MyGov website, and only using the username and authentication details which have been specifically allocated to you.


        </p>

        <span class="fa  fa-square"></span>
        <p class="note_1">
        	You must use MyGov and your MyGov account only for lawful purposes and in a manner that does not infringe the rights of or restrict or inhibit the use and enjoyment of MyGov by any third party. This includes conduct which is unlawful or which may harass or cause distress or inconvenience to any person, the transmission of obscene or offensive content or disruption to MyGov.


        </p>


 <span class="fa  fa-square"></span>
        <p class="note_1">
        	You must not post or transmit via MyGov any unlawful, defamatory, obscene, offensive or scandalous material, or any material that constitutes or encourages conduct that would contravene any law.
        </p>

        
        
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        
        </div>
   </div>
<!-- - - - - - - - - - - - - - end terms page - - - - - - - - - - - - - - - !-->






<?php
	include('footer.php');
?>
</div>

</body>
</html>
