
<script>
/*-------------------------------------------------------------------------------------*/

	function email_id()
	{
			var eml=$('.email').val();
		if(eml == "" || eml == " ")
		{
			document.getElementById("email").innerHTML="<p class='clr'> Email Cannot Leave Blank..!! </p>";
			$('.email').focus();
		}
		else
		{
			document.getElementById("email").innerHTML="<font></font>";
			
			if(/^[a-zA-z0-9.]+[@]+[a-zA-z]+[.][a-zA-z]{2,3}$/.test(eml))
			{
				
			}
			else
			{
				document.getElementById("email").innerHTML="<p class='clr'>Invalid Email ID..!!</p>";
				$('.email').focus();
			}
		}
	}



	function pass_check()
	{
		var old="<?php echo $user_row['pwd'];?>";
		if(old==$('.current_p').val())
		{
				document.getElementById("current_p").innerHTML="<p class='current_pass'>Correct password..!!</p>";
		}
		else
		{
				document.getElementById("current_p").innerHTML="<p class='clr'>Not Correct password..!!</p>";
				$('.current_p').focus();
		}
	}



	function new_password()
	{
		var n= f1.new_p.value.length;
		//alert(n);
		
		if(n<6)
		{
			document.getElementById("new_p").innerHTML="<p class='week_p'> Minimum six digit..!!</p>";
			f1.new_p.focus();
		}
		else
		{	  var a=f1.new_p.value;
			  
			if(/^[aA-zZ]*$/.test(a))
			{
				document.getElementById("new_p").innerHTML="<p class='week_p'>Week password..!!</p>";
					f1.new_p.focus();
			}
		
			else if(/^[a-zA-Z0-9]*$/.test(a))
				{
					document.getElementById("new_p").innerHTML="<p class='mid_p'>Middel password..!!</p>";
						f1.new_p.focus();
				}
		
				else if(/^[a-zA-Z0-9!@#$%^&*]*$/.test(a))
				{
					document.getElementById("new_p").innerHTML="<p class='current_pass'>Strong password..!!</p>";
				}
		}
	}
	
	
	
	function con_password()
	{
		var n= f1.cpass.value.length;
		//alert(n);
		
		if(n<6)
		{
			document.getElementById("confirm_p").innerHTML="<p class='current_pass'> Minimum six digit..!!</p>";
			f1.cpass.focus();
		}
		else
		{	  var a=f1.cpass.value;
			  
			if(/^[aA-zZ]*$/.test(a))
			{
				document.getElementById("confirm_p").innerHTML="<p class='current_pass'>Week password..!!</p>";
					f1.cpass.focus();
			}
		
			else if(/^[a-zA-Z0-9]*$/.test(a))
				{
					document.getElementById("confirm_p").innerHTML="<p class='current_pass'>Middel password..!!</p>";
						f1.cpass.focus();
				}
		
				else if(/^[a-zA-Z0-9!@#$%^&*]*$/.test(a))
				{
					if($('.confirm_p').val()==$('.new_p').val())
					{
					document.getElementById("confirm_p").innerHTML="<p class='current_pass'>Currect password..!!</p>";		
					}
					else
					{
					document.getElementById("confirm_p").innerHTML="<p class='current_pass'>Not correct password..!!</p>";			
					f1.cpass.focus();
					}
					
				}
		}
	}


/*-------------------------------------------------------------------------------------*/
	
</script>