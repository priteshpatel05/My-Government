<?php

if(isset($_REQUEST['feedback_btn']))
{
	add();
} 
	
	
	function add()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);	
	
		$d=date('d-M-Y');
		
			$qry="insert into feedback values ('',
												'".$_REQUEST['email']."',
												'".$_REQUEST['cmt']."',
												'".$d."',
												'1')";
		
		mysql_query($qry);		
		
		 echo "Successfully Sent Your Feedback."; 
	}
	

?>