
<!--------------------------------- old password msg --------------------------------------------!-->
		<?php
		if(isset($_SESSION['both_pwd_error']))
		{
			if($_SESSION['both_pwd_error']!='')
			{
	?>
   			<div class="error">
                
                <script>
					$(document).ready(function(e) {
                        $('.c').click(function(e){
							 $('.error').fadeOut('slow')
							 });
                    });
				</script>
                
                	
                	<div class="error_table">
                    	<p class="pwd_error_head">
                        	Error
                        <span class="fa fa-times c"></span>
                        </p>
                        <p class="padding">
                        	<?php
								if($_SESSION['both_pwd_error']=="both")
								{
							?>
                            		You must enter New password and Confirm password.
                            <?php
								}
								
								if($_SESSION['both_pwd_error']=="cpass")
								{
							?>
                            		You must enter Confirm password.
                            <?php
								}
							
								if($_SESSION['both_pwd_error']=="new")
								{
							?>
                            		You must enter new password.
                            <?php
								}
							?>
                 		</p>
                    </div>                
          </div>
                
    <?php			
				$_SESSION['both_pwd_error']='';
			}
		}
	?>  
<!------------------------------------ old password msg -----------------------------------------!-->



<!--------------------------------- old password msg --------------------------------------------!-->
		<?php
		if(isset($_SESSION['password_error']))
		{
			if($_SESSION['password_error']!='')
			{
	?>
   			<div class="error">
                
                <script>
					$(document).ready(function(e) {
                        $('.c').click(function(e){
							 $('.error').fadeOut('slow')
							 });
                    });
				</script>
                
                	
                	<div class="error_table">
                    	<p class="pwd_error_head">
                        	Error
                        <span class="fa fa-times c"></span>
                        </p>
                        <p class="padding">
                        	You must enter old password.
                 		</p>
                    </div>                
          </div>
                
    <?php			
				$_SESSION['password_error']='';
			}
		}
	?>  
<!------------------------------------ old password msg -----------------------------------------!-->





<!--------------------------------- user profile picture error msg --------------------------------------------!-->
		<?php
		if(isset($_SESSION['msg']))
		{
			if($_SESSION['msg']!='')
			{
	?>
   			<div class="error">
                
                <script>
					$(document).ready(function(e) {
                        $('.c').click(function(e){
							 $('.error').fadeOut('slow')
							 });
                    });
				</script>
                
                	
                	<div class="error_table">
                    	<p class="pwd_error_head">
                        	Error
                        <span class="fa fa-times c"></span>
                        </p>
                        <p class="padding">
                        	Please Select Profile Pictuer.
                 		</p>
                    </div>                
          </div>
                
    <?php			
				$_SESSION['msg']='';
			}
		}
	?>  
<!------------------------------------ user profile picture error msg -----------------------------------------!-->

