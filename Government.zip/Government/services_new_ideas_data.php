<?php
session_start();



/*= = = = = = = = = = = = = = = = = user New thinks = = = = = = = = = = = = = */
if(isset($_REQUEST['think_btn']))
{
	think_add();
}
else if(isset($_REQUEST['dis']))
	{
		display();
	}
/*= = = = = = = = = = = = = = = = = End user New thinks = = = = = = = = = = = = = */






/*= = = = = = = = = = = = = = = = = Comments of user New thinks open page = = = = = = = = = = = = = */	
if(isset($_REQUEST['cmt_btn']))
{
	cmt_add();
}
else if(isset($_REQUEST['cmt_dis']))
	{
		cmt_display($_REQUEST['cmt_dis']);
	}
	else if(isset($_REQUEST['count']))
		{
			cmt_count($_REQUEST['count']);	
		}
/*= = = = = = = = = = = = = = = = = End Comments of user New thinks open page = = = = = = = = = = = = = */








/*= = = = = = = = = = = = = = = = = user New think insert  and Display = = = = = = = = = = = = = */
	function think_add()
	{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
			
			$t_id=rand(10,420);
			$d=date('d-M-Y');
			
			$t_qry="insert into s_think_tbl values('',
													   '".$_REQUEST['user_id']."',
													   '".$_REQUEST['user_think']."',
													   '".$t_id."',
													   '".$d."',
													   '1')";
			mysql_query($t_qry,$con);
			display();
	}
	
	function display()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$t_qry="select * from s_think_tbl order by no desc";
		$t_result=mysql_query($t_qry,$con);
	
        while($t_row=mysql_fetch_assoc($t_result))
        {
	        $user_info_qry="select * from user_reg where u_id='".$t_row['u_id']."'";
            $user_info_result=mysql_query($user_info_qry,$con);
            $user_info_row=mysql_fetch_assoc($user_info_result);						
       ?>
       
         <div class="outer">
              <div class="set">
                            <img src="<?php echo $user_info_row['pro_pic']?>"  class="pro-user-img" />
                        
                            <div class="name-user">
                                <?php echo ucfirst($user_info_row['fname'])."&nbsp;".$user_info_row['lname'];?>
                            </div>
                            
                            <div class="date-user">
                            	<?php   echo $t_row['date']; ?>
                            </div>
							
                            <div class="txt-user" >
                         		<?php   echo $t_row['thinks']; ?>
                        	</div>
                            
                    <div class="cmt-count-div">
                    <?php
									
					$c_qry="select count(no) from s_think_cmt_tbl where think_id='".$t_row['think_id']."'";
					$c_result=mysql_query($c_qry,$con);	
					$c_row=mysql_fetch_array($c_result);
					$a=$c_row[0];
					?>
                    	<div class="cmt-count-show">
						<a href="services_idea_cmt.php?no=<?php echo $t_row['think_id'];?>" class="cmt-a">
								<?php echo $a;?>&nbsp;
                                <span class="fa fa-comments"></span>&nbsp;Comments
                            </a>
                    	</div>
                    </div>
            </div>
         </div>
<?php
        }         
	}
/*= = = = = = = = = = = = = = = = = End user problem insert = = = = = = = = = = = = = */










/*= = = = = = = = = = = = = = = = = Comments of new think open page = = = = = = = = = = = = = */
	function cmt_count( $i )
	{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
		
			$c_qry="select count(no) from s_think_cmt_tbl where think_id='".$i."'";
			$c_result=mysql_query($c_qry,$con);	
			$c_row=mysql_fetch_array($c_result);
			$a=$c_row[0];
			echo $a;
	}
	
	function cmt_add()
	{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
			
			$d=date('d-M-y');		
			$c_qry="insert into s_think_cmt_tbl values('',
													   '".$_REQUEST['user_id']."',
													   '".$_REQUEST['cmt']."',
													   '".$_REQUEST['think_id']."',
													   '".$d."')";
			$c_result=mysql_query($c_qry,$con);
			cmt_display($_REQUEST['think_id']);			
	}
	
	function cmt_display( $id )
	{
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);
			$t_qry="select * from s_think_cmt_tbl where think_id='".$id."' order by no desc";
			$t_result=mysql_query($t_qry,$con);		
			
			while($t_row=mysql_fetch_assoc($t_result))
            {
                 if($t_row['think_id']==$id)
                 {
					$user_info_qry="select * from user_reg where u_id='".$t_row['u_id']."'";
                    $user_info_result=mysql_query($user_info_qry,$con);
                    $user_info_row=mysql_fetch_assoc($user_info_result);	
        ?>
                  <div class="comments">
                  	
                        <img src="<?php echo $user_info_row['pro_pic'];?>" class="cmt-u-img" />
                        
                        <div class="cmt-name">      
                            <?php echo ucfirst($user_info_row['fname'])."&nbsp;".$user_info_row['lname'];?>
                        </div>
                                
                        <div class="cmt-date">
                            <?php echo $t_row['date'];?>
                        </div>
                                
                        <div class="cmt-text">
                            <?php echo $t_row['cmt'];?>
                        </div>
                  
                  </div>
        <?php
                  }
             }
	}
/*= = = = = = = = = = = = = = = = = Comments open page = = = = = = = = = = = = = */
?>


