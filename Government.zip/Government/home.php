<?php
	session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	
	
	$qry="select * from upload order by no desc limit 4";
	$result=mysql_query($qry);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/home_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>

<script src="jq/cycle.js"> </script>
	<script>
        $(document).ready(function(e) {
            $(".cycle").cycle ({
                fx:'fade',
				timeout:1000
            });
        });
    </script>

</head>

<body>


<div class="content">
<?php
	include('header.php');
?>


	
	<div class="cycle"  > 

			<img  src="img/home cycle img/Narendra-Modi-Best-Indian-Leader-Wallpapers.jpg" id="i"/>
            <img  src="img/home cycle img/i-am-a-small-man-who-wants.jpg" id="i"/>
            <img  src="img/home cycle img/428030_341255949246963_1983749753_n.jpg" id="i"/>
            <img  src="img/home cycle img/India-Textiles-1600x543.jpg" id="i"/>
            <img  src="img/home cycle img/PIB banner1600x543.jpg" id="i"/>
            <img  src="img/home cycle img/Sportspersons-banner.jpg" id="i"/>
            <img  src="img/home cycle img/pm-mobile-app-(1600x543).jpg" id="i"/>
            <img  src="img/home cycle img/DAVP-1600X543.jpg" id="i"/>
            <img  src="img/home cycle img/incredible-india-facebook-cover_6571.jpg" id="i"/>
            <img  src="img/home cycle img/india-tours-packages1.jpg" id="i"/>            
            
	</div>
    
     <div class="dd">
    
    	<div class="d1">
        
            <div class="circle">
            
          <div class="circle_div_head"> 
          	<h2 class="circle_h2">Discuss</h2>
          </div>
            
            <div class="div_text" >We would like your expert advice, thoughts and ideas on various topics that concern India.	 Join the discussions to share, debate and add value.</div>
           
    		</div>
            
    	</div>
        
        <div class="d2">
    
    
    
            <div class="circle">
    
     <div class="circle_div_head"> 
                        <h2 class="circle_h2">Do</h2>
                      </div>
    
                        <div class="div_text" >There is work to be done and a nation to be built. Find little tasks that interest you and do your bit for India.</div>
           
          
    		</div>
            
        
        </div>
    
    </div>




<div class="blog_view">

	<div class="blog_header">
    	<span class="fa  fa-renren symbol" ></span><br />
         <span class="focus">IN FOCUS</span>
   </div>

   	  <div class="show">
    
    <?php
   		while($row=mysql_fetch_assoc($result))
        {		
    ?>		
          <div id="outer_div">      

	          	 <div class="border">
    	
                		<div class="blog-content">                   
                                <div class="blog_img_div">                    
                                        <img src=" <?php echo 'upload/'.$row['img']; ?> " class="blog_img" /> 
                                </div>
                        
                                <div class="inner_div">         
                                        <h2 class="h2" > <?php	echo $row['sub']."&nbsp;&nbsp;"; 	?> </h2>
                                
                                          <h6 class="h6" >
                                                <span class="fa fa-calendar"></span>
                                                <?php echo $row['date']."&nbsp;&nbsp;<br>"; ?>  
                                          </h6>
                                                                    
                                        <h4 class="h4"> <?php	echo $row['tex']."&nbsp;&nbsp;";	 ?></h4>
                                </div>
                   		 </div>  
                              
                 <?php 
								 
						$_SESSION['page']="blog";
				 ?>
                     <div class="read-more">
                     	 <a href="open_blog.php?task=<?php echo $row['id_up']; ?>" >Read More</a> 
                     </div>
                 <?php
				 
				 ?>     
                  
    	          </div>
                               
           </div>

		<?php
            }
        ?>
    
    </div>

</div>





<?php
	include('footer.php');
?>
</div>

</body>
</html>
