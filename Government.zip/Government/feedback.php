<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/footer_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />

<script src="jq/jquery.min.1.11.0.js"></script>
<script src="jq/jquery.videoController.js"></script>


<?php
	include('feedback_script.php');
?>
</head>

<body>

<div class="content">
<?php
	include('header.php');
?>


<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->
    <div class="feedback">
		<div class="feedback_data">
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        
  			<p class="feedback_heading">Feedback</p>
			<hr />
        	
           
            
                
                	<div class="text_aera1">
                    	Thank You for visiting MyGov and becoming a stakeholder in the governance procedure of the country. We would like to hear from you about your experience and get your valued feedback on how we can make your participation in the governance process better.
                    </div>
                    
                    <div class="text_aera2">
                    In case you are facing any problem regarding the registration or login process, please do get in touch with us through this form. We would be more than happy to get back to you and help in solving issues you may be faced while browsing and/or participating through MyGov, as we value your participation in MyGov.
                    </div>
                
            	
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        
		<div class="feedback_table">
            
            			<div id="complete">
                        </div>
            
            <p>
            	<input type="text" placeholder=" Enter Your Email ID " class="feedback_email" onblur="feedback_email();"/>
            	<div id="email_error">
                </div>
            </p>
            
            <p>
            	<textarea class="feedback_textarea" placeholder=" Comments " onblur="feedback_textarea();"></textarea>
                <div id="textarea_error">
                </div>
            </p>
            
            <p>
            	<input type="button" name="submit" value="Submit" class="feedback_btn" onclick="feedback_btn();"/>
            	<div id="error">
                </div>
            </p>
            
        </div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        



        
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        
        </div>    
    </div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->
	

<?php
	include('footer.php');
?>
</div>

</body>
</html>
