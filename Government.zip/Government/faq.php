  <section class="wrapper innerbody-wrapper">
      <div class="container">
        <div class="linktous-container clearfix">
          <div class="linkto-us-content">
            <h2>FAQ</h2>
           
            <h3>What is my MyGov</h3>
            <p><strong>MyGov</strong> is an innovative platform to build a partnership between Citizens and Government with the help of technology for growth and development of India. Through this platform, the Government aims to encourage Citizen Participation towards Good Governance by seeking their ideas, suggestions and grass roots level contribution. Citizens can participate in this unique initiative of nation building and for the very first time in the history of this country, citizens from across India will come together to share their expert thoughts, ideas and suggestions with the Government in areas related to various policies, programs, schemes etc. MyGov will empower citizens to work hand in hand with the Government.</p>
            
            <h3>How can I join My Gov</h3>
            <p>Register on mygov.nic.in to participate. You will be asked for personal details such as name, email id etc. We also ask you to indicate the kind of skills you have & the issues on which you may like to provide inputs.</p>
            
            <p>On successful registration an email will be sent to your email id with a link to activate your registration. After activation log in and start participating in the various groups and discussions.</p>
            
            <p>Please note that we do not share any personally identifiable information volunteered on this site with any third party (public/private). Any information provided to this website will be protected from loss, misuse, unauthorized access or disclosure, alteration, or destruction.</p>
            
            <p>Please refer the video for more information:</p>
            
            <div class="video-img" align="center">
      <script type="text/javascript">
        var embedCode1 = '<iframe width="548" height="350" src="http://www.youtube.com/embed/WjUx5z9QRtI?feature=player_detailpage&amp;autoplay=1&amp;rel=0" frameborder="0" allowfullscreen></iframe>'
    </script>
      <div id="videocontainer1"> <img style="cursor:pointer;" width="548" height="350" src="http://cdn.mygov.nic.in/bundles/frontendgeneral/images/video-faq-e.jpg?v=26112014" alt="Please refer the video for more information" onClick="document.getElementById('videocontainer1').innerHTML = embedCode1;" /> </div>
    </div>
<br>

            <h3>What are the modes of participation?</h3>
            <p>The platform consists of various focus Groups where citizens can undertake tasks (both online and on ground) as well as share their insights through various discussions related to the particular Group.</p>
            
            <p><strong>Discussion</strong> - Citizens can join Discussions within Groups to share or express their views, ideas, and thoughts with the help of pictures, videos, documents, etc. on policies as well as on matters of national interest and collaborate on key areas of development and governance. Some of the best ideas and suggestions will straight away reach the Hon'ble Prime Minister of India. </p>
            
            <p><strong>Do (Tasks)</strong> - Citizens can volunteer for a task within a Group in the 'Do' section as per their skills and interest areas. As of now there is a limit of 4 groups that a citizen can join. This is to ensure there is meaningful & effective contribution from every citizen in the areas of interest that they have indicated while registering.</p>
            
            <p>Successful completion of a task will enable citizens to earn credit points and a chance to share their ideas with the Hon'ble Prime Minister of India.</p>
            
            <h3>Why should I participate?</h3>
            <p>MyGov makes you an agent of change and gives a golden opportunity to contribute in the journey towards nation building and towards attaining 'Surajya.' </p>
            

            <h3>What are the benefits of participating?</h3>
            <p>Get credit points by posting views on Discussions, completing Tasks that you volunteer for, and sharing ideas and view points of others on social media. Incentives based on credit points will be announced in the future. Periodically, select volunteers/achievers can get to meet and present their views directly to the Hon'ble PM of India. </p>
            
            <p>Moreover, MyGov platform gives you an opportunity to help in nation building.</p>
            
            <h3>How to type in Hindi</h3>
            <p>If you want to key-in in Hindi. You can choose the Language 'Hindi' in the language tool available in the left bottom of the log in page.</p>

            <p><strong>You can select:</strong><br>

				Hindi >> Phonetics<br>
				Hindi >> Typewriter<br>
				Hindi >> Remington
            </p>

            <p>You can also select the 'Keyboard' option for assistance.</p> 

          </div>
        </div>
      </div>
   </section>
