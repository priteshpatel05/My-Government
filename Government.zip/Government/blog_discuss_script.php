<script>

				$(document).ready(function(e) {
                    $(".select-group").click(function(e) {
                        $(".g-name").slideToggle("slow");
                    });
                });
				

	
	function grp_name(name)
	{
		//var blog_var="all";
		
		$.post('blog_discuss_data.php',{ blog_name:name
										},function (e){ $('.name').html(e); });
	}
	
	blog_view();
	function blog_view()
	{
		var blog_var="blog";
			var page="blog";
		$.post('blog_discuss_data.php',{ blog:blog_var,
											page:page
										},function (e){ $('.show').html(e); });
		grp_name(blog_var);
	}
	
	function select_grp_name(name)
	{
		
		//alert(name);
	//	var blog_var="blog";
		var page="blog";
		$.post('blog_discuss_data.php',{ 
										g_name:name,
										blog_page:page
										},function (e){ $('.show').html(e); });
		grp_name(name);
	}

</script>