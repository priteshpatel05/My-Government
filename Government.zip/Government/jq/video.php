<?php
include("include/header.php");
include("include/leftpanel.php");
?>



<div class="panel" style="width: 90%;  margin: 20px 0px 0px 60px;">
        <div class="panel-heading">
            <span class="panel-title">
                <span class="glyphicon glyphicon-film"></span>Video</span>
            
            <div class="panel-header-menu pull-right mr10 text-muted fs12"> 21 March 2015 At 12:03</div>
        </div>
        <div class="panel-body">
            
            <div class="media">
                <a class="pull-left" href="#"> <img class="media-object thumbnail mw50" src="assets/img/avatars/4.jpg" alt="..."> </a>
                <div class="media-body">
                    <h5 class="media-heading mb20"><a href="profile.php?userid=18">test test</a></h5>
                    <video id="my-video" controls="controls" preload="none" width="400" height="300" poster="assets\img\play.png">
                        <source src="http://localhost:80/milagro/student/media/7_1427046823.mp4" type="video/mp4">
                    </video>

                </div>
            </div>
            
            <div style="float: right;margin-right: 90px;margin-top: -278px;">
               
                <div>
                
                <video id="my-video" controls="controls" preload="none" width="200" height="150" poster="assets\img\play.png">
                        <source src="http://localhost:80/milagro/student/media/7_1427046823.mp4" type="video/mp4">
                    </video>
                    
                    </div>
                
                
                <div>
                
                <video id="my-video" controls="controls" preload="none" width="200" height="150" poster="assets\img\play.png">
                        <source src="http://localhost:80/milagro/student/media/7_1427046823.mp4" type="video/mp4">
                    </video>
                    
                    </div>
                
                
                <div>
                
                <video id="my-video" controls="controls" preload="none" width="200" height="150" poster="assets\img\play.png">
                        <source src="http://localhost:80/milagro/student/media/7_1427046823.mp4" type="video/mp4">
                    </video>
                    
                    </div>

                <div>
                
                <video id="my-video" controls="controls" preload="none" width="200" height="150" poster="assets\img\play.png">
                        <source src="http://localhost:80/milagro/student/media/7_1427046823.mp4" type="video/mp4">
                    </video>
                    
                    </div>
                
            </div>
            
            
        </div>
    

    
           </div>               
                
<?php
include("include/footer.php");
?>