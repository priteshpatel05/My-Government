﻿/*********************************
	DISPLAY IMAGE BEFORE UPLOAD
 *********************************/
 
 
<!-- = = = = = = = = = = = = = this is use for upload blog in admin side = = = = = = = = = = = = = = = !--> 
$(function() {
    $("#file").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support
        
        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file
            
            reader.onloadend = function(){ // set image data as background of div
				$(".up_display").css("background-image", "url("+this.result+")");
            }
        }
    });
});
<!-- = = = = = = = = = = = = = this is use for upload blog in admin side = = = = = = = = = = = = = = = !--> 





<!-- = = = = = = = = = = = = = this is use for update profile in user side = = = = = = = = = = = = = = = !--> 
$(function() {
    $(".file").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support
        
        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file
            
            reader.onloadend = function(){ // set image data as background of div
				$(".user_pro_pic").css("background-image", "url("+this.result+")");
            }
        }
    });
});
<!-- = = = = = = = = = = = = = this is use for update profile in user side = = = = = = = = = = = = = = = !--> 






/*------------------------------- admin profile ---------------------------------------*/
$(function() {
    $(".admin_file").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support
        
        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file
            
            reader.onloadend = function(){ // set image data as background of div
				$(".show_ad_profile").css("background-image", "url("+this.result+")");
            }
        }
    });
});
/*------------------------------- admin profile ---------------------------------------*/








/*------------------------------- Award Image ---------------------------------------*/

$(function() {
    $(".a_file").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support
        
        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file
            
            reader.onloadend = function(){ // set image data as background of div
				$(".show_image").css("background-image", "url("+this.result+")");
            }
        }
    });
});
/*------------------------------- Award Image ---------------------------------------*/


