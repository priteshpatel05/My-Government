<?php
session_start();	

if(isset($_REQUEST['no']))
{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$pbm_qry="select * from s_problem_tbl where pbm_id='".$_REQUEST['no']."'";
		$pbm_result=mysql_query($pbm_qry,$con);
		$pbm_row=mysql_fetch_assoc($pbm_result);
		$n=mysql_num_rows($pbm_result);		
		
		$user_info_qry="select * from user_reg where u_id='".$pbm_row['u_id']."'";
        $user_info_result=mysql_query($user_info_qry,$con);
        $user_info_row=mysql_fetch_assoc($user_info_result);
		
		if($n==1)
		{	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_problem_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
</head>

<body>
	

<div class="content">



<!-- ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,Login divion,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,!-->
<div class="new_div">
	<?php
		$id="problem_cmt";
		$_SESSION['no']=$_REQUEST['no'];
		include('login.php');
	?>
</div>
<!-- ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,end Login divion ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,!-->




<?php
	include('header.php');
?>

<script>
	
	
	cmt_display();
	function cmt_display()
	{
		var n=<?php echo $_REQUEST['no'];?>;
		$.post('services_problem_add_data.php',{ cmt_dis:n}
							,function(t){$('.cmt-display').html(t)	}) ;
		cmt_count_call();
	}
	
	function cmt_count_call()
	{
		var n=<?php echo $_REQUEST['no'];?>;
		$.post('services_problem_add_data.php',{ count:n}
							,function(t){$('.count').html(t)	}) ;
	}

	function cmt_btn(pbm_id,id)
	{
		if( ($('.user_cmt').val()=='') || ($('.user_cmt').val()==' ') )
		{
			document.getElementById("btn_click_event").innerHTML="<font id='clr'> Cannot Leave Blank ..!! </font>";
			$('.user_cmt').val('');
			$('.user_cmt').focus();
		}
		else
		{
			document.getElementById("btn_click_event").innerHTML="<font id='clr'> </font>";
			$.post('services_problem_add_data.php',{ cmt_btn:$('.cmt_btn').val(),
												cmt:$('.user_cmt').val(),
												pbm_id:pbm_id,
												user_id:id}
							,function(t){$('.cmt-display').html(t)	}) ;
		cmt_display();
		cmt_count_call();		
		$('.user_cmt').val('');
		}
		
	}


</script>

<?php
include('service_script.php');
?>


<div class="help-note" >
    	Helping You And Find Government Information & Servies.
    </div>

<div class="service_main_div">

	<div class="service_menu">
    	
        <div class="li_menu">
        <?php
			include('service_menu_li.php');
		?>
        </div>
    
    </div>
    
    <div class="service_show">
    	<span class="fa fa-angle-double-left" id="click"></span>
        
          <div class="margin-set">   
				
                
                
    <div class="service">
		<div class="service_data">    
               
                
 				<div class="name">
                	Take Problem's of Pepole And Give The Solution about problem 
                </div>                
                
<!--  - - - - - - - - - - - - problem table - - - - - - - - - - - - - - !-->
				  <div class="open-outer">
                        <div class="open-set">
                            <img src="<?php echo $user_info_row['pro_pic']?>"  class="pro-user-img" />
                        
                            <div class="name-user">
                                <?php echo ucfirst($user_info_row['fname'])."&nbsp;".$user_info_row['lname'];?>
                            </div>
                            
                            <div class="date-user">
                            	<?php   echo $pbm_row['date']; ?>
                            </div>
							
                            <div class="txt-user" >
                         		<?php   echo $pbm_row['problem_text']; ?>
                        	</div>
                            
<!--  - - - - - - - - - - - - Comment count table - - - - - - - - - - - - - - !-->                            
                   
                            <div class="open-cmt-count-show">
                                    <div class="count"></div>&nbsp;
                                    <span class="fa fa-comments"></span>&nbsp;Comments
                            </div>

<!--  - - - - - - - - - - - - End Comment count table - - - - - - - - - - - - - - !-->

                     </div>
                  </div>
<!--  - - - - - - - - - - - - End problem table - - - - - - - - - - - - - - !-->
                
  
  
  
                
<!--  - - - - - - - - - - - - Display Division - - - - - - - - - - - - - - !-->                
              <div class="display-div">
                        <?php
                            if(!isset($name))
                            {
						?>


                	<div class="login-notes-div">
                        If you want to give your Suggetion than First <a href="#" class="l-n-a click"> Login or Registration</a>
                            <span class="tooltip"> Click </span>
                        
            		</div>

                        
                        <?php		
							}
							else
							{
                        ?>
                            <div class="user_cmt_div">
                                <input type="text" class="user_cmt" placeholder="Comments" />
                                <input type="button" value="Submit" class="cmt_btn" 
                                onclick="cmt_btn('<?php echo $pbm_row['pbm_id'];?>','<?php echo $name;?>')"/>
                                <div id="btn_click_event">
                                	
                                </div>
                            </div>
                        <?php
                            }
                        ?>
                            <div class="cmt-display">
                            </div>
              </div>
<!--  - - - - - - - - - - - - End Display Division - - - - - - - - - - - - - - !-->          
          
                    
			</div>
            </div>                    
<!--   -----------------------------------------------------   !-->                
                    
            
         
    </div>

</div>


<?php
	include('footer.php');
?>
</div>

</body>
</html>


<?php

	}
	else
	{
		header('Location: services_problem.php');
	}


}
else
{
	header('Location: services_problem.php');
}
?>


