<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);		
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_problem_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<?php
include('service_script.php');
?>
<script>

/*===================================== user Problem =====================================*/

	function check(name)
	{
		var n= f1.problem.value.length;

		if( ( n == 0 ) )
		{
		document.getElementById("problem").innerHTML="<p class='clr'> Can not left Black Field ..!! </p>";
			$('.pbm-add-textarea').focus();
		}
		else
		{
		$.post('services_problem_add_data.php',{ problem_btn: $('.pbm-submit-btn').val(),
												user_id:name,
												user_problem: $('.pbm-add-textarea').val()}
							
							,function(t){$('.user-problem').html(t)	}) ;
		
			$('.pbm-add-textarea').val('');
		
		}
	}


	display();
	function display()
	{
		var n=1;
		
		//alert('call');
		$.post('services_problem_add_data.php',{ dis:n}
							,function(t){$('.user-problem').html(t)	}) ;
	}

/*===================================== user Problem =====================================*/	

</script>

</head>

<body>
	

<div class="content">


<!-- ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,Login divion,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,!-->
<div class="new_div">
	<?php
		$id="problem";
		include('login.php');
	?>
</div>
<!-- ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,end Login divion ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,!-->



<?php
	include('header.php');
?>

<div class="help-note" >
    	Helping You And Find Government Information & Servies.
    </div>

<div class="service_main_div">

	<div class="service_menu">
    	
        <div class="li_menu">
        	<?php
			include('service_menu_li.php');
			?>
        </div>
    
    </div>
    
    <div class="service_show">
    	<span class="fa fa-angle-double-left" id="click"></span>
 
<!-- = = = = = = = = = = = = = = = =  Margin-set = = = = = = = = = = = = = = = = = !-->       
          <div class="margin-set">   
       		
            
   <div class="service">
		<div class="service_data">    
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->    		
        

                <div class="name">
                	Any People share Problem's  And Give The Solution about problem 
                </div>


<!-- - - - - - - - - - - - - - - User login or not  - - - - - - - - - - - - - - - - !-->     
                <?php
					if(isset($name))
					{
				?>
          
                    <div class="pbm-add-table">
              <form action="#" method="post" name="f1">      
                         <textarea type="text" name="problem" placeholder="Write Your Problem" class="pbm-add-textarea" /></textarea>
                    <div id="problem">
                    </div>
                         
                         <?php
                            $_SESSION['u_id']=$name;
                         ?>
                         <p>
                         <input type="button" value="Submit" name="submit" class="pbm-submit-btn" 
                         onclick="check('<?php echo $name;?>')"/>
                         </p>
               </form>    
                    </div>            
                    
                <?php
					}
					else
					{
				?>
                	<div class="login-notes-div">
                        If you want to add your Problem's than First <a href="#" class="l-n-a click"> Login or Registration</a>
                            <span class="tooltip"> Click </span>
                        
            		</div>
                <?php		
					}
				?>
<!-- - - - - - - - - - - - - - - End User login or not  - - - - - - - - - - - - - - - - !-->     




            
<!-- = = = = = = = = = = = = = = = =  show problem = = = = = = = = = = = = = = = = = !-->                   
            	<div class="show-problem-table">
                	
                    <p class="show-problem-name">&nbsp;&nbsp;
                	User's Problems :
                	</p>
                	
                    <div class="user-problem">
						
                	</div>
                </div>
<!-- = = = = = = = = = = = = = = = =  End show problem = = = = = = = = = = = = = = = = = !-->       
            





          
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->     
        </div>
	</div>
            
            
            
          </div>
<!-- = = = = = = = = = = = = = = = =  End Margin-set = = = = = = = = = = = = = = = = = !-->       

    </div>

</div>


<?php
	include('footer.php');
?>
</div>

</body>
</html>
