<script>
				$(document).ready(function(e) {
                    $(".select-group").click(function(e) {
                        $(".g-name").slideToggle("slow");
                    });
                });

	
	function grp_name(name)
	{
		//var blog_var="all";
		
		$.post('blog_discuss_data.php',{ discuss_name:name
										},function (e){ $('.name').html(e); });
	}
	
	discuss_view();
	function discuss_view()
	{
		var discuss_var="discuss";
		var page="discuss";
		$.post('blog_discuss_data.php',{ discuss:discuss_var,
										dis_page:page
										},function (e){ $('.show').html(e); });
		grp_name(discuss_var);
	}
	
	function select_grp_name(name)
	{
		
		//alert(name);
	//	var blog_var="blog";
		var page="discuss";
		$.post('blog_discuss_data.php',{ 
										g_name:name,
										discuss_page:page
										},function (e){ $('.show').html(e); });
		grp_name(name);
	}

</script>