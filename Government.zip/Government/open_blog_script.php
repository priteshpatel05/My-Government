<script>

cmt_count();
function cmt_count()
{
	var a=<?php echo $open_row['id_up']; ?>;
	//alert(a);
		$.post('likes-comments-script.php',{cmt_count:a},function(t){
			$('.cmt_count').html(t)
	});
}

view_like();

function view_like()
{
		var v='<?php echo $open_row['id_up']; ?>';
		//alert(v);
		$.post('likes-comments-script.php',{view_like:v},function(t){
				$('#count_like').html(t);
		});
}

view_unlike();

function view_unlike()
{
		var v='<?php echo $open_row['id_up']; ?>';
		//alert(v);
		$.post('likes-comments-script.php',{view_unlike:v},function(t){
				$('#count_unlike').html(t);
		});
}



function likes(pic_id,uid,a)
{
		if(a == "like")
		{
			//alert(uid);
			$.post('likes-comments-script.php',{ id : pic_id ,
												uid:uid, 
											 like: a },
										    function(test){
											view_unlike()
											$('#count_like').html(test);
											});	
			$('#count_like').addClass('status');
		}
		else if( a == "unlike" )
		{
			//alert("unlike");
			$.post('likes-comments-script.php',{ id : pic_id ,
												uid:uid, 
											 like: a },
										    function(test){
											view_like()
											$('#count_unlike').html(test);
											});	
											
		$('#count_unlike').addClass('unlike_status');
		}
}
	


	view();
	function view()
	{
		var v='<?php echo $open_row['id_up']; ?>';
		//alert(v);
		$.post('likes-comments-script.php',{view_test:v},function(t){
				$('#cmt-show').html(t);
		});
	}	
	
function comment(id,up)
{
	if( ($('.cmt-input').val() == '') || ($('.cmt-input').val() == ' ') )
	{
		document.getElementById("complete").innerHTML=" Cannot Leave Blank Please Enter your opinion ";
		$('.cmt-input').focus();
	
	}
	else
	{
	$.post('likes-comments-script.php',{ s:$('.submit_cmt').val(),
										 id : id ,
										 up : up,
										cmt: $('.cmt-input').val() },
										function(test){
												$('#cmt-show').html(test);
												$('.cmt-input').val("");
											$('#complete').empty("");	
										});
											
										
	}
}
			
</script>