<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);		
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_new_ideas_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<?php
include('service_script.php');
?>

</head>

<body>
	

<div class="content">


<!-- ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,Login divion,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,!-->
<div class="new_div">
	<?php
		$id="idea";
		include('login.php');
	?>
</div>
<!-- ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,end Login divion ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,!-->






<?php
	include('header.php');
?>

<script>

/*===================================== user think script =====================================*/

	function check(name)
	{
		var n=f1.text.value.length;
 	
		if( (n == 0 ) )
		{
			document.getElementById("text_error").innerHTML="<p class='clr'> Cannot Leave Blank ..!! </p>";
			$('.think-add-textarea').focus();
		}
		else
		{
			if(n != 0)
			{
			document.getElementById("text_error").innerHTML="";
			
		$.post('services_new_ideas_data.php',{ think_btn: $('.think-submit-btn').val(),
												user_id:name,
												user_think: $('.think-add-textarea').val()}
							
							,function(t){$('.user-think').html(t)	}) ;
			$('.think-add-textarea').val('');
		
			}
			else
			{
			document.getElementById("text_error").innerHTML="<p class='clr'> Invalid ..!! </p>";
			$('.think-add-textarea').focus();				
			}
		}
	
	}


	display();
	function display()
	{
		var n=1;
		
		//alert('call');
		$.post('services_new_ideas_data.php',{ dis:n}
							,function(t){$('.user-think').html(t)	}) ;
		$('.think-add-textarea').val('');
	}

/*===================================== user think script =====================================*/	

</script>



<div class="help-note" >
    	Helping You And Find Government Information & Servies.
    </div>

<div class="service_main_div">

	<div class="service_menu">
    	
        <div class="li_menu">
        	<?php
			include('service_menu_li.php');
			?>
        </div>
    
    </div>
    
    <div class="service_show">
    	<span class="fa fa-angle-double-left" id="click"></span>
<!-- = = = = = = = = = = = = = = = =  Service show = = = = = = = = = = = = = = = = = !-->       
 


          <div class="margin-set">   
<!-- = = = = = = = = = = = = = = = =  Margin-set = = = = = = = = = = = = = = = = = !-->       



   <div class="service">
		<div class="service_data">    
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->    		
        



       		<div class="name">
               	People share New idea's For Make the Good Governance 
            </div>

            <?php
			if(isset($name))
			{
			?>
                <div class="think-add-table">
            <form action="#" name="f1" method="post" >      
                   <textarea type="text" name="text" class="think-add-textarea" placeholder=" Write New thinks"></textarea>
                    <div id="text_error">
                    </div>     
                 <?php
                     $_SESSION['u_id']=$name;
                 ?>
                    <p>
                      <input type="button" value="Submit" name="submit" class="think-submit-btn" 
                         onclick="check('<?php echo $name;?>')"/>
                    </p>
              </form>      
                 </div>            
             
			 <?php
			 }
			 else
			 {
			 ?>
                <div class="login-notes-div">
                        
                      If you want to Give your New Idea For Good Governance than First 
                        <a href="#" class="l-n-a click"> Login or Registration</a>
                            <span class="tooltip"> Click </span>
                    
            	</div>
             <?php		
			 }
			 ?>
            
            
<!-- = = = = = = = = = = = = = = = =  show New thinks = = = = = = = = = = = = = = = = = !-->                   
            	<div class="show-new-thinks-table">
                
                <p class="show-thinks-name">&nbsp;&nbsp;
                	People's share New Idea's :
                </p>
                
                	<div class="user-think">
					</div>
                </div>
<!-- = = = = = = = = = = = = = = = =  End show New thinks = = = = = = = = = = = = = = = = = !-->       
            
            
            
            
<!---------------------------------------------------------------!-->            
			</div>
          </div>
           
                       
<!-- = = = = = = = = = = = = = = = =  End Margin-set = = = = = = = = = = = = = = = = = !-->                   
          </div>





<!-- = = = = = = = = = = = = = = = =  End Service show = = = = = = = = = = = = = = = = = !-->       
    </div>

</div>


<?php
	include('footer.php');
?>
</div>

</body>
</html>
