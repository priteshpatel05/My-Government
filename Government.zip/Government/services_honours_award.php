<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);		
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_css.css" type="text/css" />
<link rel="stylesheet" href="css/service_honours_awards_css.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<script>

	display_awards();
	function display_awards()
	{
		var no=1;
		$.post('services_honours_award_data.php',{ display_award_no:no
											},function(t){$('.show-awards').html(t)});
	}


</script>

</head>

<body>
	

<div class="content">
<?php
	include('header.php');
?>
<?php
include('service_script.php');
?>


<div class="help-note" >
    	Helping You And Find Government Information & Servies.
    </div>

<div class="service_main_div">

	<div class="service_menu">
    	
        <div class="li_menu">
        	<?php
			include('service_menu_li.php');
			?>
        </div>
    
    </div>
    
    <div class="service_show">
    	<span class="fa fa-angle-double-left" id="click"></span>
 
<!-- = = = = = = = = = = = = = = = =  Margin-set = = = = = = = = = = = = = = = = = !-->       
          <div class="margin-set">   
       			


    <div class="service">
		<div class="service_data">    
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->    		

                
                <div class="name">
                	Indian Governments Awards
                </div>
          
          
          		<div class="awards">
                
                	<div class="show-awards">
                    </div>
                
                </div>
          
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->     
        </div>
	</div>
             
             
		</div>
<!-- = = = = = = = = = = = = = = = =  End Margin-set = = = = = = = = = = = = = = = = = !-->       

    </div>

</div>


<?php
	include('footer.php');
?>
</div>

</body>
</html>
