<script>
			
//------------ group all -------------
				
				$(document).ready(function(e) {
                    $(".s-all").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
												
						$(".all").show("slow");
                    });
                });
				
//------------ group 1 -------------
				$(document).ready(function(e) {
                    $(".s-g1").click(function(e) {
                        $(".all").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						$(".g1").show("slow");	 });
                });

//------------ group 2 -------------
				$(document).ready(function(e) {
                    $(".s-g2").click(function(e) {
                        $(".g1").hide("slow"),
						$(".all").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g2").show("slow");
                    });
                });
				
				
//------------ group 3 -------------
				$(document).ready(function(e) {
                    $(".s-g3").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".all").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g3").show("slow");
                    });
                });
				

//------------ group 4 -------------
				$(document).ready(function(e) {
                    $(".s-g4").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".all").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g4").show("slow");
                    });
                });
				
				
//------------ group 5 -------------
				$(document).ready(function(e) {
                    $(".s-g5").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".all").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g5").show("slow");
                    });
                });
				

//------------ group 6 -------------
				$(document).ready(function(e) {
                    $(".s-g6").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".all").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g6").show("slow");
                    });
                });



//------------ group 7 -------------
				$(document).ready(function(e) {
                    $(".s-g7").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".all").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g7").show("slow");
                    });
                });
				
				
				
//------------ group 8 -------------
				$(document).ready(function(e) {
                    $(".s-g8").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".all").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g8").show("slow");
                    });
                });				


//------------ group 9 -------------
				$(document).ready(function(e) {
                    $(".s-g9").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".all").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g9").show("slow");
                    });
                });



//------------ group 10 -------------
				$(document).ready(function(e) {
                    $(".s-g10").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".all").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g10").show("slow");
                    });
                });


//------------ group 11 -------------
				$(document).ready(function(e) {
                    $(".s-g11").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".all").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g11").show("slow");
                    });
                });


//------------ group 12 -------------
				$(document).ready(function(e) {
                    $(".s-g12").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".all").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g12").show("slow");
                    });
                });



//------------ group 13 -------------
				$(document).ready(function(e) {
                    $(".s-g13").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".all").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g13").show("slow");
                    });
                });


//------------ group 14 -------------
				$(document).ready(function(e) {
                    $(".s-g14").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".all").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g14").show("slow");
                    });
                });


//------------ group 15 -------------
				$(document).ready(function(e) {
                    $(".s-g15").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".all").hide("slow"),
						$(".g16").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g15").show("slow");
                    });
                });


//------------ group 16 -------------
				$(document).ready(function(e) {
                    $(".s-g16").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".all").hide("slow"),
						$(".g17").hide("slow"),
						
						$(".g16").show("slow");
                    });
                });



//------------ group 17 -------------
				$(document).ready(function(e) {
                    $(".s-g17").click(function(e) {
                        $(".g1").hide("slow"),
						$(".g2").hide("slow"),
						$(".g3").hide("slow"),
						$(".g4").hide("slow"),
						$(".g5").hide("slow"),
						$(".g6").hide("slow"),
						$(".g7").hide("slow"),
						$(".g8").hide("slow"),
						$(".g9").hide("slow"),
						$(".g10").hide("slow"),
						$(".g11").hide("slow"),
						$(".g12").hide("slow"),
						$(".g13").hide("slow"),
						$(".g14").hide("slow"),
						$(".g15").hide("slow"),
						$(".g16").hide("slow"),
						$(".all").hide("slow"),
						
						$(".g17").show("slow");
                    });
                });


				
</script>

