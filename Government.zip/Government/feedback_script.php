<script>


	function feedback_email()
	{
		var eml=$('.feedback_email').val();
		if(eml == "" || eml == " ")
		{
			document.getElementById("email_error").innerHTML="<p class='clr'> Enter Email ID ..!! </p>";
			$('.feedback_email').focus();
		}
		else
		{
			document.getElementById("email_error").innerHTML="<font></font>";
			
			if(/^[a-zA-z0-9\w|-|.]+[\@]+[a-zA-z]+[\.][a-zA-z]{2,3}$/.test(eml))
			{
				
			}
			else
			{
				document.getElementById("email_error").innerHTML="<p class='clr'>Invalid Email ID..!!</p>";
				$('.feedback_email').focus();
			}
		}
	}


	function feedback_textarea()
	{
		var n=$('.feedback_textarea').val();
		
		if(n == "" || n == " ")
		{ 
			document.getElementById("textarea_error").innerHTML="<p class='clr'> Enter Comments ..!! </p>";
			$('.feedback_textarea').focus();
		}
		else
		{
			document.getElementById("textarea_error").innerHTML="<font></font>";
			if(/^[aA-zZ0-9!@$%&'",.-+= ]*$/.test(n))
			{}
			else
			{		
				document.getElementById("textarea_error").innerHTML="<p class='clr'> Character Only ..!! </p>";
				$('.feedback_textarea').focus();
			}
		}
	}






	function feedback_btn()
	{
			
		if( $('.feedback_email').val() == "")
		{
			document.getElementById("email_error").innerHTML="<p class='clr'> Email ID Cannot Leave Blank..!! </p>";
			$('.feedback_email').focus();
		}
		
		if( $('.feedback_textarea').val() == "")
		{
			document.getElementById("textarea_error").innerHTML="<p class='clr'> Comments Cannot Leave Blank ..!! </p>";
			$('.feedback_textarea').focus();
		}
		
		
		if( $('.feedback_email').val() == "" ||
			$('.feedback_textarea').val() == "" )
		{
				document.getElementById("error").innerHTML="<p class='clr'> Please Fill up the all field ..!! </p>";	
		}
		else
		{	
			$.post('feedback_data.php',{ feedback_btn: $('.feedback_btn').val(),
								email: $('.feedback_email').val(),
								cmt: $('.feedback_textarea').val()}
								,function(t){$('#complete').html(t)	}) ;
					
			$('.feedback_email').val("");
			$('.feedback_textarea').val("");

		}
	}

</script>