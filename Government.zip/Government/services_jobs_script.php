<script>



function apply_btn()
{
		alert($('.full_name_input').val());
		alert($('.age_input').val());
		alert($('.select_g').val());
		alert($('.email_input').val());
		alert($('.mobile_input').val());
		alert($('.address_input').val());
		alert($('.year-select').val());
		alert($('.skill_input').val());
		alert($('.eq_input').val());

/*		
	if( $('.full_name_input').val() == "" ||  
		$('.age_input').val() == "" ||
		$('.select_g').val() == "" || 
		$('.email_input').val() == "" || 	
		$('.mobile_input').val() == "" || 
		$('.address_input').val() == "" ||
		$('.year-select').val() == "" ||
		$('.skill_input').val() == "" ||
		$('.eq_input').val() == "" )
	{
			document.getElementById("complete").innerHTML=
			"<font id='clr'> Cannot Leave Blank ..!! <br> Please fill up All the line </font>";		
	}
	else
	{
		var no=<php echo $_REQUEST['a'];?>;
		$.post('services_gov_jobs_data.php',{ apply_btn: $('.submit-btn').val(),
												v_id:no,
												fname:$('.full_name_input').val(),
												age: $('.age_input').val(),
												gender:$('.select_g').val(),
												email:$('.email_input').val(),
												mobile: $('.mobile_input').val(),
												address: $('.address_input').val(),
												ex_year:$('.year-select').val(),
												skill:$('.skill_input').val(),
												e_q: $('.eq_input').val()}
							
							,function(t){$('#complete').html(t)	}) ;
	
		$('.full_name_input').val("");
		$('.age_input').val("");
		$('.select_g').val("");
		$('.email_input').val("");
		$('.mobile_input').val("");
		$('.address_input').val("");
		$('.year-select').val("");
		$('.skill_input').val("");
		$('.eq_input').val("");
	}
	*/
}


function check_fname()
{	
	var l=$('.full_name_input').val().length;
	var n=$('.full_name_input').val();
	
	if(l <= 0 || n=='')
	{ 
		document.getElementById("fname_error").innerHTML="<p class='msg_css'> Cannot Leave Blank ..!! </p>";
		$('.full_name_input').focus();
	}
	else
	{
		document.getElementById("fname_error").innerHTML="";
		if(/^[aA-zZ ]*$/.test(n))
		{}
		else
		{		
			document.getElementById("fname_error").innerHTML="<p class='msg_css'>Character Only ..!! </p>";
			$('.full_name_input').focus();
		}
	}
}


function check_skill()
{	
	var l=$('.skill_input').val().length;
	var n=$('.skill_input').val();
	if(l <= 0)
	{ 
		document.getElementById("skill_error").innerHTML="<p class='msg_css'> Cannot Leave Blank ..!! </p>";
		$('.skill_input').focus();
	}
	else
	{
		document.getElementById("skill_error").innerHTML="";
		if(/^[a-zA-Z, ]*$/.test(n))
		{
		}
		else
		{		
			document.getElementById("skill_error").innerHTML="<p class='msg_css'>Invalid ..!! </p>";
			$('.skill_input').focus();
		}
	}
}



function check_add()
{
	var l=$('.address_input').val().length;
	var n=$('.address_input').val();

	if(l <= 0)
	{ 

		document.getElementById("address_error").innerHTML="<p class='msg_css'> Cannot Leave Blank ..!! </p>";
		$('.address_input').focus();
	}
	else
	{
		document.getElementById("address_error").innerHTML="";
		if(/^[a-zA-Z0-9, &'-:]*$/.test(n))
		{
		}
		else
		{
		document.getElementById("address_error").innerHTML="<p class='msg_css'> Invalid ..!! </p>";			
		}

	}
}

function check_age()
{
	
	var n=$('.age_input').val();

	if( n == "" || n == " ")
	{ 
		
		document.getElementById("age_error").innerHTML="<p class='msg_css'> Cannot Leave Blank ..!! </p>";
		$('.age_input').focus();
	}
	else
	{
		document.getElementById("age_error").innerHTML="";
		if(/^[0-9]*$/.test(n))
		{
			if(n<=58)
			{
				
			
			}
			else
			{
				document.getElementById("age_error").innerHTML="<p class='msg_css'> Maximum age 58 !! </p>";
				$('.age_input').focus();
			}
		}
		else
		{		
			document.getElementById("age_error").innerHTML="<p class='msg_css'> Number Only !! </p>";
			$('.age_input').focus();
			
		}
	}
}



function check_mob()
{
	
	var n=$('.mobile_input').val();

	if( n == "" || n == " ")
	{ 
		
		document.getElementById("mobile_error").innerHTML="<p class='msg_css'> Cannot Leave Blank ..!! </p>";
		$('.mobile_input').focus();
	}
	else
	{
		document.getElementById("mobile_error").innerHTML="<font></font>";
		if(/^[0-9]{10}$/.test(n))
		{}
		else
		{		
			document.getElementById("mobile_error").innerHTML="<p class='msg_css'> Number Only & with 10 digit..!! </p>";
			$('.mobile_input').focus();
		}
	}
}



function check_email()
{
	var eml=$('.email_input').val();
	if(eml == "" || eml == " ")
	{
		document.getElementById("email_error").innerHTML="<p class='msg_css'> Cannot Leave Blank..!! </p>";
		$('.email_input').focus();
	}
	else
	{
		document.getElementById("email_error").innerHTML="<font></font>";
		
		if(/^[a-zA-z0-9\w|-|.]+[\@]+[a-zA-z]+[\.][a-zA-z]{2,3}$/.test(eml))
		{
			
		}
		else
		{
			document.getElementById("email_error").innerHTML="<p class='msg_css'>Invalid Email ID..!!</p>";
			$('.email_input').focus();
		}
	}
}


function check_cpwd()
{
	var n=$('.cpwd').val();

	if( n == "" || n == " ")
	{ 
		document.getElementById("cpwd").innerHTML="<font id='clr'> Cannot Leave Blank ..!! </font>";
		$('.cpwd').focus();
	}
	else
	{
		document.getElementById("cpwd").innerHTML="<font></font>";
		if(/^[aA-zZ]*$/.test(n))
		{
			document.getElementById("cpwd").innerHTML="<span id='clr1'> Week Password ..!! </font>";
			$('.cpwd').focus();

		}
		else if(/^[a-zA-Z0-9]*$/.test(n))
			{
				document.getElementById("cpwd").innerHTML="<span id='clr2'> Mid Password ..!! </font>";
				$('.cpwd').focus();
			}
			else if(/^[a-zA-Z0-9!@#$%^&*]*$/.test(n))
			{
				document.getElementById("cpwd").innerHTML="<span id='clr3'> Strong Password ..!! </font>";
			}
			else
			{		
				
			}
	}
}



function check_pwd() 
{
	var n=$('.reg_pwd').val();
	
	if( n == "" || n == " ")
	{ 	
		document.getElementById("pwd").innerHTML="<font id='clr'> Cannot Leave Blank ..!! </font>";
		$('.reg_pwd').focus();
	}
	else
	{
		document.getElementById("pwd").innerHTML="<font></font>";
		if(/^[aA-zZ]*$/.test(n))
		{
			document.getElementById("pwd").innerHTML="<span id='clr1'> Week Password ..!! </font>";
			$('.reg_pwd').focus();
		}
		else if(/^[a-zA-Z0-9]*$/.test(n))
			{
				document.getElementById("pwd").innerHTML="<span id='clr2'> Mid Password ..!! </font>";
				$('.reg_pwd').focus();
			}
			else if(/^[a-zA-Z0-9!@#$%^&*]*$/.test(n))
			{
				document.getElementById("pwd").innerHTML="<span id='clr3'> Strong Password ..!! </font>";

						if( n == $('.cpwd').val() )
						{
							document.getElementById("pwd").innerHTML="<font>password correct..</font>";
						}
						else
						{		
							document.getElementById("pwd").innerHTML=
							"<font id='clr'> Password Not match..!! </font>";
							$('.reg_pwd').focus();
						}
			}
			else
			{		
				document.getElementById("pwd").innerHTML="<font id='clr'>Using the characters,Numbers and Special character for makeing strong password </font>";
				$('.reg_pwd').focus();
			}
	}
}

	function call()
	{
		if($('.year-select').val()=='')
		{
			alert();	
			$('.year-select').focus();
		}
	}


</script>