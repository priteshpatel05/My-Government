<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />

<link rel="stylesheet" href="css/about_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>

</head>

<body>
	

<div class="content">
<?php
	include('header.php');
?>

<!-- - - - - - - - - - - - - - - - About page - - - - - - - - - - - - - - - - - !-->
    <div class="about">
		<div class="about_data">    
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        

			<p class="about_heading"> About Us</p>
			<hr />
 				
                
             <img src="img/servivce img/images-aboutusimg-250x250.jpg" class="about-img"/>
                           
            <div class="text1">
            
            <!--On 26th July, 2014, the Hon’ble Prime Minister of India launched MyGov – a platform for Citizen Engagement for good governance, which presents a wonderful opportunity for citizens, experts and government authorities to collectively achieve the goal of Surajya.
            !-->
            <h2>What is My Indian Government ?</h2>
            
            
            <p>
My Indian Government is an innovative platform to build a partnership between Citizens and Government with the help of technology for growth and development of India. Through this platform, the Government aims to encourage Citizen Participation towards Good Governance by seeking their ideas, suggestions and grass roots level contribution. Citizens can participate in this unique initiative of nation building. For the very first time in the history of this country, citizens from across India will come together to share their expert thoughts, ideas and suggestions with the Government in areas related to various policies, programs, schemes etc. My Indian Government aims to empower citizens to work hand in hand with the Government.
           </p>
           </div>
           
           <div class="text2">
            
            			MY INDIAN GOVERNMENT is a citizen engagement platform. This is promote for the active participlation of indian citizen in their country's governance and developnent. It is also aimed at creating a common platform for indian citizens to "crowdsource governance ideas from citizen".
            </div>
            
            
            <div class="text2">
            	
                The user's shall br allowed to discuss and to contribute on various government project and plans. It also allows users to upload documents in various formats.
            	
            </div>
            
            <div class="text2">
            	<h2 >
                	Groups : 
                </h2>
            		
                   There are various pre-defined group to which users can selectively subscribe to the objective of each group is to bring positive changes to the relevent area with peoples parcticipation. Users are provide two domains 'DO' and 'Discuss'. The 'DO' section include work to be bulit and the 'DO' section may be used for find a little tasks that intrest you and do your bit for India. The 'Discuss' section may br used for discussing different relevant issues afecting the nation.
                 
            
            </div>
            
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->        
        </div>
    </div>
<!-- - - - - - - - - - - - - - - - End About page - - - - - - - - - - - - - - - - - !-->

<?php
	include('footer.php');
?>
</div>

</body>
</html>
