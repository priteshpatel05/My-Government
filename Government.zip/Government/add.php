<?php
	if(isset($_REQUEST['s']))
	{
		add();
	} 
	
	
	function add()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);	
		$default_pic="upload/pro_pic.png";
		$u = $_REQUEST['fname'].rand(1,999);
		$d=date('d-M-Y');
		
			$qry="insert into user_reg values ('',
												'".$_REQUEST['fname']."',
												'".$_REQUEST['lname']."',
												'".$_REQUEST['gender']."',
												'".$_REQUEST['mob']."',
												'".$_REQUEST['reg_mail']."',
												'".$_REQUEST['pwd']."',
												'".$d."',
												'".$u."',
												'".$default_pic."',
												'1')";
		
		mysql_query($qry);		
		
		$acc_qry="insert into user_acc values('','".$u."','','','','')";
		mysql_query($acc_qry);
		
		
		?>
		 
         <div class="complete_msg">
             	<div class="com_table">
                   	<p class="complete_msg_head">
                        	Message
                    </p>
         
                    <p class="padding">
                       	<?php 
							echo "Successfully Complete Your Registration. <br>";
							echo "Now you are able to Login.";
						?>
              		</p>
          
                    <p>
                        	<a href="reg.php">
                        		<span class="ok_btn" title="login">ok</span>
                            </a>
                    </p>
                </div>                
          </div>

        
   <?php
	}
	

?>