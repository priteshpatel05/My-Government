
<script>

/*===================================== user Comments =====================================*/	
	
	cmt_display()
	function cmt_display()
	{
		var n=<?php echo $_REQUEST['cmt'];?>;
		//alert(n);
		$.post('services_problem_add_data.php',{ cmt_dis:n}
							,function(t){$('.cmt-display').html(t)	}) ;
	}
	
	
	
	function cmt_btn(pbm_id,id)
	{
		//alert($('.user_cmt').val());
		//alert(id);
		//alert(pbm_id);
		
		$.post('services_problem_add_data.php',{ cmt_btn:$('.cmt_btn').val(),
												cmt:$('.user_cmt').val(),
												pbm_id:pbm_id,
												user_id:id}
							,function(t){$('.cmt-display').html(t)	}) ;
	}
/*===================================== End user comments =====================================*/
</