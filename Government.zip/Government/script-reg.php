<script>

function submit_reg()
{
//	alert();
		/*alert($('.fname').val());
		alert($('.lname').val());
		alert($('.mob').val());		
		alert($('.reg_mail').val());
		alert($('.cpwd').val());
		alert($('.reg_pwd').val());
		*/
	// Display name with => alert alert( $('.fname').val());
		//alert($('.reg-input-radio').val());
		
	if( $('.fname').val() == "")
	{
		document.getElementById("fname").innerHTML="<p class='clr'> First Name Enter ..!! </p>";
	}
	
	if($('.lname').val() == "")
	{
		document.getElementById("lname").innerHTML="<p class='clr'> last Name Enter ..!! </p>";			
	}
	
	if($('.select_g').val() == "")
	{
		document.getElementById("select_g").innerHTML="<p class='clr'> Please Select Gender..!! </p>";			
	}
	
	if(	$('.mob').val() == "")
	{
		document.getElementById("mobile").innerHTML="<p class='clr'> Mobile Enter ..!! </p>";		
	}
	
	if(	$('.reg_mail').val() == "" )
	{
		document.getElementById("reg-mail").innerHTML="<p class='clr'> Email ID Enter..!! </p>";	
	}
	
	if($('.reg_pwd').val() == "" )
	{	
		document.getElementById("pwd").innerHTML="<p class='clr'> Confirm Password Enter ..!! </p>";
	}
	
	if($('.cpwd').val() == "" )
	{
		document.getElementById("cpwd").innerHTML="<p class='clr'> Create Password Enter ..!! </p>";
	}
	
	
	if( $('.fname').val() == "" ||
		$('.lname').val() == "" || 
		$('.mob').val() == "" || 	
		$('.reg_mail').val() == "" || 
		$('.reg_pwd').val() == ""  )
	{
			document.getElementById("error").innerHTML=
			"";
			
	}

	if( $('.fname').val() != "" &&
		$('.lname').val() != "" && 
		$('.select_g').val() != "" &&
		$('.mob').val() != "" &&	
		$('.reg_mail').val() != "" && 
		$('.reg_pwd').val() != ""  )
	{	
		$.post('add.php',{ s: $('.reg-submit').val(),
							fname: $('.fname').val(),
							lname: $('.lname').val(),
							gender: $('.select_g').val(),
							mob: $('.mob').val(),
							reg_mail: $('.reg_mail').val(),
							pwd: $('.reg_pwd').val()}
							
							,function(t){$('#complete').html(t)	}) ;
	


		document.getElementById("select_g").innerHTML="";			
		document.getElementById("cpwd").innerHTML="";
		document.getElementById("pwd").innerHTML="";
		
		$('.fname').val("");
		$('.lname').val("");
		$('.select_g').val("");
		$('.mob').val("");		
		$('.reg_mail').val("");
		$('.cpwd').val("");
		$('.reg_pwd').val("");
		
	}
}


function check_fname()
{
	var n=$('.fname').val();
	
	if(n == "" || n == " ")
	{ 
		document.getElementById("fname").innerHTML="<p class='clr'> First Name Cannot Leave Blank ..!! </p>";
		$('.fname').focus();
	}
	else
	{
		document.getElementById("fname").innerHTML="<font></font>";
		if(/^[aA-zZ]*$/.test(n))
		{}
		else
		{		
			document.getElementById("fname").innerHTML="<p class='clr'> Character Only ..!! </p>";
			$('.fname').focus();
		}
	}
}


function check_lname()
{
	var n=$('.lname').val();
	
	if(n == "" || n == " ")
	{ 
		document.getElementById("lname").innerHTML="<p class='clr'> last Name Cannot Leave Blank ..!! </p>";
		$('.lname').focus();
	}
	else
	{
		document.getElementById("lname").innerHTML="<font></font>";
		if(/^[aA-zZ]*$/.test(n))
		{}
		else
		{		
			document.getElementById("lname").innerHTML="<p class='clr'> Character Only ..!! </p>";
			$('.lname').focus();
		}
	}
}

function select_g()
{
//	alert($('.select_g').val());
	if($('.select_g').val()=='')
	{
		document.getElementById("select_g").innerHTML="<p class='clr'> Please select Gender ..!! </p>";
	}
	else
	{
		document.getElementById("select_g").innerHTML="<font></font>";
	}
		
		//$('.lname').focus();
		//
}



function check_add()
{
	var n=$('.address').val();
	
	if(n == "" || n == " ")
	{ 
		document.getElementById("address").innerHTML="<p class='clr'> Address Cannot Leave Blank ..!! </p>";
		$('.address').focus();
	}
	else
	{
		document.getElementById("address").innerHTML="<font id='clr'></font>";
	}
}


function check_mob()
{
	
	var n=$('.mob').val();

	if( n == "" || n == " ")
	{ 
		
		document.getElementById("mobile").innerHTML="<p class='clr'> Mobile Cannot Leave Blank ..!! </p>";
		$('.mob').focus();
	}
	else
	{
		document.getElementById("mobile").innerHTML="<font></font>";
		if(/^[0-9]{10}$/.test(n))
		{}
		else
		{		
			document.getElementById("mobile").innerHTML="<p class='clr'> Number Only with 10 digit..!! </p>";
			$('.mob').focus();
		}
	}
}



function check_mail()
{
	var eml=$('.reg_mail').val();
	if(eml == "" || eml == " ")
	{
		document.getElementById("reg-mail").innerHTML="<p class='clr'> Cannot Leave Blank..!! </p>";
		$('.reg_mail').focus();
	}
	else
	{
		document.getElementById("reg-mail").innerHTML="<font></font>";
		
		if(/^[a-zA-z0-9\w|-|.]+[\@]+[a-zA-z]+[\.][a-zA-z]{2,3}$/.test(eml))
		{
			
		}
		else
		{
			document.getElementById("reg-mail").innerHTML="<p class='clr'>Invalid Email ID..!!</p>";
			$('.reg_mail').focus();
		}
	}
}


	function check_cpwd()
	{

		var n= f1.cpwd.value.length;
		//alert(n);
		
		if(n<6)
		{
			document.getElementById("cpwd").innerHTML="<p class='clr_6_digit'> Minimum six digit..!!</p>";
			f1.cpwd.focus();
		}
		else
		{	 
			var a=f1.cpwd.value;
			  
			if(/^[aA-zZ]*$/.test(a))
			{
				document.getElementById("cpwd").innerHTML="<p class='clr_week'>Week password..!!</p>";
					f1.cpwd.focus();
			}
		
			else if(/^[a-zA-Z0-9]*$/.test(a))
				{
					document.getElementById("cpwd").innerHTML="<p class='clr_middel'>Middel password..!!</p>";
						f1.cpwd.focus();
				}
		
				else if(/^[a-zA-Z0-9!@#$%^&*]*$/.test(a))
				{
					document.getElementById("cpwd").innerHTML="<p class='current_pass'>Strong password..!!</p>";
				}
		}
	}


	function check_pwd()
	{
		var n= f1.pwd.value.length;
		//alert(n);
		
		if(n<6)
		{
			document.getElementById("pwd").innerHTML="<p class='clr_6_digit'> Minimum six digit..!!</p>";
			f1.pwd.focus();
		}
		else
		{	  var a=f1.pwd.value;
			  
			if(/^[aA-zZ]*$/.test(a))
			{
				document.getElementById("pwd").innerHTML="<p class='clr_week'>Week password..!!</p>";
				f1.pwd.focus();
			}
		
			else if(/^[a-zA-Z0-9]*$/.test(a))
				{
					document.getElementById("pwd").innerHTML="<p class='clr_middel'>Middel password..!!</p>";
						f1.pwd.focus();
				}
		
				else if(/^[a-zA-Z0-9!@#$%^&*]*$/.test(a))
				{
					if($('.reg_pwd').val()==$('.cpwd').val())
					{
					document.getElementById("pwd").innerHTML="<p class='current_pass'>Currect password..!!</p>";		
					}
					else
					{
					document.getElementById("pwd").innerHTML="<p class='clr_middel'>Not correct password..!!</p>";			
					f1.pwd.focus();
					}
					
				}
		}
	}



</script>