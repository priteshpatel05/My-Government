<?php
session_start();


/*-----------------------------------------  inbox ------------------------------------------------*/


if(isset($_REQUEST['mail_replay']))
{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$d=date('d-M-y');
		$s_qry="insert into mails values('',
										 '".$_REQUEST['id']."',
										 'mygov',
										 '".$_REQUEST['mail_replay']."',
										 '".$d."',
										 '0',
										 '1')";
										 
		mysql_query($s_qry,$con);
		echo "Message Sent";		
}

if(isset($_REQUEST['inbox_view']))
{
	mail_display();
}

if(isset($_REQUEST['inbox_delete_no']))
{
	mail_delete();
}

/*-----------------------------------------  inbox ------------------------------------------------*/





/*-----------------------------------------  inbox ------------------------------------------------*/



	function mail_delete()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$qry="DELETE from mails where no='".$_REQUEST['inbox_delete_no']."'";
		mysql_query($qry,$con);
		
		mail_display();
	}


	function mail_display()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$qry="select * from mails where reciver='".$_REQUEST['id']."' order by no desc";
		$result=mysql_query($qry,$con);
		
		while($row=mysql_fetch_assoc($result))
		{
			?>
        	<p class="inbox_data">
            
			
            
            <div class="mail_sender">
                <a href="user_inbox_open.php?no=<?php echo $row['no'];?>" title="Click" class="inbox_data_a">
                	MyGovernment
                </a> 
			</div>
                         
            <div class="mail_msg">
             	<?php echo $row['msg']; ?>
            </div>
            
             <div class="mail_date">
             	<?php echo $row['date']; ?>
            </div>
             
            <div class="mail_del">
            <span class="fa fa-trash-o" title="Delete" onClick="inbox_del(<?php echo $row['no'];?>);"></span>
            </div>
            
            </p>
        
        <?php
		}
	}



/*-----------------------------------------  inbox ------------------------------------------------*/
?>