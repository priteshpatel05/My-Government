<?php
session_start();	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("mygov",$con);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>welcome to my government</title>
<link rel="stylesheet" href="css/style_css.css" type="text/css" />
<link rel="stylesheet" href="css/user_profile_css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="font-awesome-4.1.0/css/font-awesome.min.css" />


<script src="jq/jquery.min.1.11.0.js"></script>
<script src="jq/diaplay-image.js" ></script>





</head>

<body>
	

<div class="content">

<?php
	include('user_error_msg.php');
	
	include('header.php');
	
	$user_qry="select * from user_reg where u_id='".$r['u_id']."'";
	$user_result=mysql_query($user_qry,$con);
	$user_row=mysql_fetch_assoc($user_result);
	
	include('user_profile_script.php');	
	include('user_account_script.php');
?>

<!-- - - - - - - - - - - - - - - - work page - - - - - - - - - - - - - - - - - !-->

	 <div class="user_profile">
		<div class="user_profile_data">  
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->
          

<!-- - - - - - - - - - - - - - - column - - - - - - - - - - - - - - - - - - !-->            
<?php
	include('column.php');
?>            
<!-- - - - - - - - - - - - - - - end column - - - - - - - - - - - - - - - - - - !-->            
            
<!-- - - - - - - - - - - - - - - row - - - - - - - - - - - - - - - - - - !-->            
<?php
	include('row.php');
?>            
<!-- - - - - - - - - - - - - - - end row- - - - - - - - - - - - - - - - - - !-->            
            
         
         
         
         
<!-- - - - - - - - - - - - - - - show - - - - - - - - - - - - - - - - - - !-->

	<div class="show" >
    
    
    
<!--------------------------------- user account table -----------------------------------!-->    
    <div class="account" >
    
    	<table class="user_acc_table">
        
        <form action="user_profile_data.php?acc=email" method="post" name="">
        <?php $_SESSION['u_id']=$name; ?>
        	<tr><td class="td_space"></td></tr>
        	<tr><th colspan="2"> Change Email </th></tr>
            <tr><td class="td_space"></td></tr>
            
        	<tr>
            	<td class="acc_td1"> Email</td>
            	<td class="acc_td2">: &nbsp;&nbsp;<input type="text" value="<?php echo $user_row['email_id'] ;?>" name="email" onblur="email_id();" class="email"/>
                
                </td>
            </tr>
            <tr><td colspan="2"><div id="email"></div></td></tr>
                        
            <tr>
            	<td colspan="2"><input type="submit" name="submit"  value="Save" class="acc_btn"/></td>
            </tr>
       </form>
       
       <form action="user_profile_data.php?acc=pass" method="post" name="f1"> 
       <?php $_SESSION['u_id']=$name; ?>    
            <tr><td class="td_space"></td></tr>
            <tr><td class="td_space"></td></tr>
            <tr><td class="td_space"></td></tr>
            <tr><th colspan="2"> Change PassWord </th></tr>
            <tr><td class="td_space"></td></tr>
            
            
            
            <tr>
            	<td class="acc_td1"> Current Password </td>
            	<td class="acc_td2">: &nbsp;&nbsp;
                <input type="password" name="password" class="pass_input current_p" onblur="pass_check();"/>
                </td>
            </tr>
            
            <tr>
            	<td colspan="2">
                	<div id="current_p"></div>
                </td>
            </tr>
            
            <tr>
            	<td class="acc_td1"> New  Password </td>
            	<td class="acc_td2">: &nbsp;&nbsp;
                <input type="password" name="new_p" class="pass_input new_p" onblur="new_password();"/>
                </td>
            </tr>

            <tr>
            	<td colspan="2">
                	<div id="new_p"></div>
                </td>
            </tr>


            
            <tr>
            	<td class="acc_td1">Comfirm Password   </td>
            	<td class="acc_td2"> : &nbsp;&nbsp;
                <input type="password" name="cpass" class="pass_input confirm_p" onblur="con_password();"/>
              	</td>
            </tr>
			
             <tr>
            	<td colspan="2">
                <div id="confirm_p">
                </div>

 
                </td>
            </tr>
 
            <tr>
            	<td colspan="2"><input type="submit" name="submit"  value="Save" class="acc_btn"/></td>
            </tr>
        </form>    
            
        </table>
	    
        
        
        
<!---------------------------------- change user image ------------------------------------------!-->                    
        <div class="upload_div">
        	<div class="profile-head">
            	Change Profile
            </div>
			<form method="post" action="user_profile_data.php?profile=image" enctype="multipart/form-data"/>
                <div class="user_pro_pic" style="background-image:url(<?php echo $user_row['pro_pic'];?>)">
                </div>
                <input type="file" class="file" name="file" title="Choose File" />
                <?php $_SESSION['id']=$user_row['u_id']; ?>
                <input type="submit" class="pro_submit" name="submit" value="Upload" title="Upload"/>            
            </form> 
		</div>
<!---------------------------------- change user image ------------------------------------------!-->            


        
        

		<div>
<!------------------------------------- user account table ---------------------------------------!-->    
    
    </div>
         
<!-- - - - - - - - - - - - - - - End show - - - - - - - - - - - - - - - - - - !-->         
         
         
            
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - !-->            
        </div>
        </div>
        
        
      
</div></div>    
<!-- - - - - - - - - - - - - - - - End work page - - - - - - - - - - - - - - - - - !-->

<?php
	include('footer.php');
?>


</div>

</body>
</html>
