<?php
session_start();

if(isset($_REQUEST['submit']))
{
	if($_REQUEST['task']=="add")
	{
		
		/*if( ($_REQUEST['fname']!='')  and ($_REQUEST['lname']!='') and ($_REQUEST['gender']!='') 
			and  ($_REQUEST['mob']!='') and ($_REQUEST['mail_id']!='')  
			and ($_REQUEST['pwd']!='') )
		{				
			$con=mysql_connect("Localhost","root","");
			mysql_select_db("mygov",$con);	
			$default_pic="upload/pro_pic.png";
			$u = $_REQUEST['fname'].rand(1,999);
			$d=date('d-M-Y');
			
			$qry="insert into user_reg values ('',
												'".$_REQUEST['fname']."',
												'".$_REQUEST['lname']."',
												'".$_REQUEST['radio']."',
												'".$_REQUEST['mob']."',
												'".$_REQUEST['email']."',
												'".$_REQUEST['pwd']."',
												'".$d."',
												'".$u."',
												'".$default_pic."',
												'1')";
		
					mysql_query($qry,$con)or die(mysql_error());
						
		$acc_qry="insert into user_acc values('','".$u."','','','','')";
		mysql_query($acc_qry);
					
					$_SESSION['msg']=$_REQUEST['fname'].$_REQUEST['lname'];
					header('Location: reg.php');	
				}
				else
				{
					$_SESSION['error']="error";
					header('Location: reg.php');
				}
				
				*/
	}

		if($_REQUEST['task']=="check")
		{
			if( ($_REQUEST['mail_id']!='') or ($_REQUEST['pwd']!='')  ) 
			{
					$con=mysql_connect("Localhost","root","");
					mysql_select_db("mygov",$con);	
						
					$qry="select * from user_reg where email_id='".$_REQUEST['mail_id']."' and 
																	pwd='".$_REQUEST['pwd']."'";
								
					$result=mysql_query($qry,$con);			
					$r=mysql_fetch_assoc($result);
						
				$n=mysql_num_rows($result);	
				
				if($n==1)						
				{		
						if($_REQUEST['a']=="reg")
						{
							$_SESSION['u_id']=$r['u_id'];
							header('Location: home.php'); 
						}
						
						else if($_REQUEST['a']=="discuss")
						{
							$_SESSION['u_id']=$r['u_id'];
							$_SESSION['page']="discuss";
							header('Location: open_blog.php?task='.$_SESSION['id_up']); 
						}
						
						else if($_REQUEST['a']=="problem")
						{
							$_SESSION['u_id']=$r['u_id'];
							header('Location: services_problem.php'); 
						}
						
						else if($_REQUEST['a']=="problem_cmt")
						{
							$_SESSION['u_id']=$r['u_id'];
							header('Location: service_problem_open_cmt.php?no='.$_SESSION['no']); 
						}			
						
						else if($_REQUEST['a']=="idea")
						{
							$_SESSION['u_id']=$r['u_id'];
							header('Location: services_new_ideas.php'); 
						}
						
						else if($_REQUEST['a']=="idea_cmt")
						{
							$_SESSION['u_id']=$r['u_id'];
							header('Location: services_idea_cmt.php?no='.$_SESSION['no']); 
						}			
				}
				else
				{
						$_SESSION['login_msg']="error";
						header('Location: reg.php');	
				}
					
					
			}
			else
			{	
				$_SESSION['login_msg']="msg";
				header('Location: reg.php');	
			}
		}


}
else
{
				header('location: reg.php');	
}


?>