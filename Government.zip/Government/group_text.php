<div class="group-div">
		
        
        <div class="group_name_show">
        	Select : <span class="name"></span>
        </div>
        
   				 <div class="select-group">      	
                          <span class="fa  fa-angle-down"></span>&nbsp;&nbsp; Select Group 
                 </div>
                            
                  <div class="g-name">
                         
                         
                         <div class="group">   
                         <?php
                         
                         //$num=mysql_num_rows($g_result);
                                 $a=1;                   
                         while($g_row=mysql_fetch_assoc($g_result))
                         {
                              if($a==1)
							  {
								  ?>
                                  <div class="d-1">
                                  <?php
								  if($a==1)
                                    {
										?>
                                        <div class="select-grp" onclick="select_grp_name('<?php echo "all";?>');" >
                                        <span class="select_text"> All Group</span>
                                        </div>
                                        <?php
                                    }    
							  }
							  else if($a==9)
								  {
									  ?>
									  <div class="d-1">
									  <?php
								  }
								  else if($a==18)
									  {
										  ?>
										  <div class="d-1">
										  <?php
									  }
	  								  else if($a==27)
									  {
										  ?>
										  <div class="d-1">
										  <?php
									  }

								  
							  
							 ?>
                         <div class="select-grp" value="" onclick="select_grp_name('<?php  echo $g_row['name']; ?>');" >
                         <span class="select_text">
	                         <?php echo ucfirst($g_row['name']);?>
                         </span>
                         
                         </div>
                             <?php 
							  
							  
							   
							  if($a==8)
							  {
								 ?>
								  </div>
                                 <?php
							  }
							  else if($a==17)
								  {
									 ?>
									  </div>
									 <?php
								  }
								  else if($a==26)
								  {
									 ?>
									  </div>
									 <?php
								  }
								  else if($a==28)
									  {
										 ?>
										  </div>
										 <?php
									  }
							  
							  $a++;
                         }
                         ?>
                  			</div>
                    </div>
</div>
