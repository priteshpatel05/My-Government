<?php
session_start();


/*-----------------------------------------  inbox ------------------------------------------------*/

if(isset($_REQUEST['mail_count']))
{
	mail_count();
}

	function mail_count()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);

		$m_qry="select count(no) from mails where reciver='".$_REQUEST['id']."' and a_status=1";
		$m_result=mysql_query($m_qry,$con);
		$m_row=mysql_fetch_array($m_result);
		echo $mail=$m_row[0];
	}

/*-----------------------------------------  inbox ------------------------------------------------*/




/*--------------------------------------- user Account & profile -------------------------------------------*/

if(isset($_REQUEST['check']))
{
	if($_REQUEST['check']=="acc")
	{
		user_account();
	}
	else if($_REQUEST['check']=="profile")
		{
			user_profile();
		}
}
/*--------------------------------------- user Account & profile -------------------------------------------*/





/*--------------------------------------- user account & profile update -------------------------------------------*/


if(isset($_REQUEST['acc']))
{
	change_data();	
}

if(isset($_REQUEST['profile']))
{
	change_profile_pic();	
}
/*--------------------------------------- user account & profile update -------------------------------------------*/





/*--------------------------------------- comment -------------------------------------------*/

if(isset($_REQUEST['cmt_count']))
{
	cmt_count();
}

if(isset($_REQUEST['cmt_no']))
{
	cmt_delete();
}

if(isset($_REQUEST['cmt_view']))
{
	cmt_display($_REQUEST['id']);
}

/*--------------------------------------- comment -------------------------------------------*/



/*--------------------------------------- problem -------------------------------------------*/

if(isset($_REQUEST['problem_count']))
{
	problem_count();
}

if(isset($_REQUEST['problem_no']))
{
	problem_delete();
}

if(isset($_REQUEST['problem_view']))
{
	problem_display($_REQUEST['id']);
}

/*--------------------------------------- problem -------------------------------------------*/



/*--------------------------------------- idea -------------------------------------------*/

if(isset($_REQUEST['idea_count']))
{
	idea_count();
}

if(isset($_REQUEST['idea_no']))
{
	idea_delete();
}

if(isset($_REQUEST['idea_view']))
{
	idea_display($_REQUEST['id']);
}

/*--------------------------------------- idea -------------------------------------------*/




/*--------------------------------------- idea -------------------------------------------*/

	function idea_count()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);

		$i_qry="select count(no) from s_think_tbl where u_id='".$_REQUEST['id']."'";
		$i_result=mysql_query($i_qry,$con);
		$i_row=mysql_fetch_array($i_result);
		echo $idea=$i_row[0];
	}
	


	function idea_delete()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$cmt_qry="DELETE from s_think_tbl where no='".$_REQUEST['idea_no']."'";
		mysql_query($cmt_qry,$con);
		
		idea_display($_REQUEST['id']);
	}


	
	function idea_display( $id )
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$i_qry="select * from s_think_tbl where u_id='".$id."' order by no desc";
		$i_result=mysql_query($i_qry,$con);
		
		while($i_row=mysql_fetch_assoc($i_result))
		{
			?>
        	<p class="cmt_data">
            
			
            <div class="view_btn">
                <a href="services_idea_cmt.php?cmt=<?php echo $i_row['think_id'];?>" title="Open" class="cmt_data_a">
                	View
            	</a> 
            </div>
            
            <div class="user_idea_show"> 
            &nbsp; <?php echo $i_row['thinks']; ?>
            </div> 
            
            <div class="date">
            	<?php echo $i_row['date'];?>
            </div>
            
            <span class="fa fa-trash-o" title="Delete" onClick="idea_del(<?php echo $i_row['no'];?>);"></span>
            
            </p>
        
        <?php
		}
	}




/*--------------------------------------- idea -------------------------------------------*/











/*--------------------------------------- problem -------------------------------------------*/

	function problem_count()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);

		$p_qry="select count(no) from s_problem_tbl where u_id='".$_REQUEST['id']."'";
		$p_result=mysql_query($p_qry,$con);
		$p_row=mysql_fetch_array($p_result);
		echo $problem=$p_row[0];
	}


	function problem_delete()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$cmt_qry="DELETE from s_problem_tbl where no='".$_REQUEST['problem_no']."'";
		mysql_query($cmt_qry,$con);
		
		problem_display($_REQUEST['id']);
	}

	function problem_display( $id )
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$p_qry="select * from s_problem_tbl where u_id='".$id."' order by no desc";
		$p_result=mysql_query($p_qry,$con);
		
		while($p_row=mysql_fetch_assoc($p_result))
		{
			?>
        	<p class="cmt_data">
            
			
            <div class="view_btn">            
            <a href="service_problem_open_cmt.php?problem=<?php echo $p_row['pbm_id'];?>" title="Open" class="cmt_data_a">
            View
            </a>
            </div>
             
            <div class="user_idea_show"> 
            &nbsp; <?php echo $p_row['problem_text']; ?>
            </div>
    
    		<div class="date">
            	<?php echo $p_row['date']?>
            </div>         
            <span class="fa fa-trash-o" title="Delete" onClick="problem_del(<?php echo $p_row['no'];?>);"></span>
            </p>
        
        <?php
		}
	}

/*--------------------------------------- problem -------------------------------------------*/







/*--------------------------------------- comment -------------------------------------------*/
	function cmt_count()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);

		$c_qry="select count(no) from cmt where u_id='".$_REQUEST['id']."'";
		$c_result=mysql_query($c_qry,$con);
		$c_row=mysql_fetch_array($c_result);
		echo $cmt=$c_row[0];
	}


	
	function cmt_delete()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$cmt_qry="DELETE from cmt where no='".$_REQUEST['cmt_no']."'";
		mysql_query($cmt_qry,$con);
		
		cmt_display($_REQUEST['id']);
	}

	function cmt_display( $id )
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$cmt_qry="select * from cmt where u_id='".$id."' order by no desc";
		$cmt_result=mysql_query($cmt_qry,$con);
		
		while($cmt_row=mysql_fetch_assoc($cmt_result))
		{
			$b_qry="select * from upload where id_up='".$cmt_row['id_up']."'";
			$b_re=mysql_query($b_qry,$con);
			$b_row=mysql_fetch_assoc($b_re);
		?>
        	<p class="cmt_data">
            
            <div class="view_btn">
            <?php $_SESSION['page']="discuss";?>
            <a class="cmt_data_a" title="Click" href="open_blog.php?task=<?php echo $cmt_row['id_up'];?>" title="Open" class="cmt_data_a">
           	 View
            </a> 
            </div>
            
            <div class="user_idea_show"> 
            
            comments in <?php echo $b_row['sub']; ?>&nbsp; group is &nbsp; <?php echo $b_row['group_up']; ?> 
            </div>
            
            <div class="date">
            	<?php echo $cmt_row['date']; ?> 
            </div>
            
            <span class="fa fa-trash-o" title="Delete" onClick="cmt_del(<?php echo $cmt_row['no'];?>);"></span>
            </p>
        
        <?php
		}
	}
/*--------------------------------------- comment -------------------------------------------*/









/*-------------------------------- change profile picture -----------------------------------------*/

	function change_profile_pic()
	{
		if(isset($_REQUEST['submit']))
		{
			$con=mysql_connect('Localhost','root','');
			mysql_select_db('mygov',$con);
			
			$name=$_FILES['file']['name'];
			$path=$_FILES['file']['tmp_name'];
			$type=$_FILES['file']['type'];
			
			
			if($name=="")
			{
				$_SESSION['msg']='msg';
				header('Location: user_account.php');
			}
			else
			{
				$a="upload/".$name;
				
				move_uploaded_file($path,$a);
				
				//$qry="DELETE FROM `user_reg` WHERE 1"	
				$qry="UPDATE user_reg SET pro_pic='".$a."' WHERE u_id='".$_SESSION['id']."'";
				mysql_query($qry,$con)or die(mysql_error());
				header('Location: user_account.php');
			}
			
		}   

	}
/*-------------------------------- change profile picture -----------------------------------------*/



/*----------------------------------------- change data  ---------------------------------------------*/

	function change_data()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		
		if($_REQUEST['acc']=="email")
		{
			$acc="UPDATE user_reg SET email_id='".$_REQUEST['email']."'  where u_id ='".$_SESSION['u_id']."'";
			mysql_query($acc,$con);
			header('Location: user_account.php');
		}
		else if($_REQUEST['acc']=="pass")
			{
				if($_REQUEST['password']!='')
				{
					
					if($_REQUEST['new_p']!='')
					{
						if($_REQUEST['cpass']!='')
						{
								if($_REQUEST['cpass']==$_REQUEST['new_p'])
								{
									$acc="UPDATE user_reg SET pwd='".$_REQUEST['cpass']."' where u_id ='".$_SESSION['u_id']."'";
									mysql_query($acc,$con);
									header('Location: user_account.php');
								}
								else
								{
									$_SESSION['both_pwd_error']="both";
									header('Location: user_account.php');
								}
						}
						else
						{
							$_SESSION['both_pwd_error']="cpass";
							header('Location: user_account.php');
						}

					}
					else
					{
						$_SESSION['both_pwd_error']="new";
						header('Location: user_account.php');
					}

					
					
					}
				else
				{
					$_SESSION['password_error']="msg";
					header('Location: user_account.php');
				}
			}
		
		

	}
	
	
/*----------------------------------------- change data  ---------------------------------------------*/



/*----------------------------------------- user Profile  ---------------------------------------------*/
	function user_profile()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$acc="UPDATE user_reg SET fname='".$_REQUEST['fname']."', 
								  lname='".$_REQUEST['lname']."', 
								  gender='".$_REQUEST['gender']."',
								  phone_no='".$_REQUEST['mobile']."'  where u_id ='".$_SESSION['u_id']."'";
		mysql_query($acc,$con);
		header('Location: user_edit_profile.php');
	}

/*----------------------------------------- user Profile  ---------------------------------------------*/





/*----------------------------------------- user Account  ---------------------------------------------*/
	function user_account()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$acc="UPDATE user_acc SET country='".$_REQUEST['country']."', 
								  state='".$_REQUEST['state']."', 
								  distric='".$_REQUEST['dis']."',
								  address='".$_REQUEST['address']."'  where u_id ='".$_SESSION['u_id']."'";
		mysql_query($acc,$con);
		
		header('Location: user_edit_profile.php');
	}
/*----------------------------------------- user Account  ---------------------------------------------*/




?>