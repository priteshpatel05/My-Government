<div class="space">
</div>

<div class="footer">

        <div class="link">
        	<ul class="f_ul">
            <?php
            $f_qry="select * from footer_menu";
			$f_result=mysql_query($f_qry,$con);
			$z=1;
		
			
			while($f_row=mysql_fetch_assoc($f_result))
            {
  			?>
            	<li class="f_set">
                     <a href="<?php echo $f_row['f_link'];?>" class="f_a">  
					 	<?php echo ucfirst($f_row['f_menu']);?>
                     </a>
                 </li>        
              <?php 
	          }
            ?>
            </ul>

            <!--<div class="link-div1">
                <p><a href="home.php"  > Home </a></p>
                <p><a href="overview.php"  > Overview </a></p>
                <p><a href="site_map.php"  > Site Map </a></p>
                <p><a href="faq.php"  > FAQ </a ></p>
            </div>
            
            <div class="link-div2">
                <p><a href="terms.php"  > Terms & Condition </a></p>
                <p><a href="feedback.php"  > Feedback </a ></p>
                <p><a href="help.php"  > Help </a ></p>     
            </div>!-->
             
        </div>

        <div class="middle">
            <span class="fa  fa-empire" ></span>
        </div>
        
        <div class="contact">
        
        	<div class="contact-head">
            	Contact as
            </div>
<?php
	$con_qry="select * from contact";
	$con_result=mysql_query($con_qry,$con);
	$con_result1=mysql_query($con_qry,$con);
?>        
        	<div class="call">
				
                
               
                <?php
					while($con_row=mysql_fetch_assoc($con_result))
					{
							if($con_row['phone_no']!='')
							{
				?>		
                				<br />							
							 <span class="fa fa-phone" >&nbsp;&nbsp;
								<?php echo $con_row['phone_no']; ?>
                             </span>
                <?php            
                            }			
					}
				?>
                
                
                 
                  
                <?php
				while($con_row1=mysql_fetch_assoc($con_result1))
				{
						if($con_row1['email']!='')
						{
				?>		
                				<br />							
							<span class="fa fa-envelope">&nbsp;&nbsp;
								<?php echo $con_row1['email']; ?>
                             </span>
                <?php            
                            }			
					}
				?>

              
               
                
                 
                
        	</div>
            
            <div class="other_contact">
            
            	<span class="fa  fa-youtube"></span>
                <span class="fa  fa-google"></span>
                <span class="fa  fa-facebook-square"></span>
                <span class="fa   fa-twitter"></span>
                <span class="fa  fa-yahoo"></span>
                 
                 
            
            </div>
            
        </div>

		<div class="copyright">
    		Copyrights &copy; 2014-15 All Rights Reserved | MyGovernment.Com
	    </div>


</div>






    