<?php
session_start();

/*= = = = = = = = = = = = = = = = = Show All Awards call = = = = = = = = = = = = = */
if(isset($_REQUEST['display_sc_no']))
{
	display_sc();
}
/*= = = = = = = = = = = = = = = = = End Show Awards call = = = = = = = = = = = = = */



/*= = = = = = = = = = = = = = = = = All Awards Display = = = = = = = = = = = = = */	
	function display_sc()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$qry="select * from scholarship";
		$result=mysql_query($qry,$con);
	?>
		
    	        
        <?php
		$q=1;
		while($row=mysql_fetch_assoc($result))
		{
		?>         
 			<div class="show_main_div">
                   
               <span class="fa fa-circle"></span>

                <div class="sc_name">
						<?php echo ucfirst($row['owner_name']);?>
                </div>
                
                <div class="sc_details">
                	<?php echo ucfirst($row['details']);?>
                </div>
                
            </div>
        <?php	
		}
		?>
    
		
	<?php
	}
/*= = = = = = = = = = = = = = = = = End All Vacancies Display = = = = = = = = = = = = = */	


?>