-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 06, 2015 at 02:24 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mygov`
--
CREATE DATABASE IF NOT EXISTS `mygov` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mygov`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_reg`
--

CREATE TABLE IF NOT EXISTS `admin_reg` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mail_id` varchar(200) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `a_id` varchar(100) NOT NULL,
  `a_pro` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `admin_reg`
--

INSERT INTO `admin_reg` (`no`, `fname`, `lname`, `gender`, `mail_id`, `pwd`, `a_id`, `a_pro`) VALUES
(3, 'Piter', 'Patel', 'Male', 'piter@facebook.com', 'pritesh@1', 'piter58', '../upload/4640_profile_nilssonpolias.jpg'),
(11, 'ankita', 'nandaniya', 'female', 'ankita@gmail.com', 'anku123@', 'ankita687', '../upload/beautiful-pink-flower-nokia-n86-8mp-mobile-wallpaper.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cmt`
--

CREATE TABLE IF NOT EXISTS `cmt` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `id_up` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `cmt`
--

INSERT INTO `cmt` (`no`, `u_id`, `comment`, `id_up`, `date`, `status`) VALUES
(15, 'ankita308', 'Industries that are throwing untreated waste water in any river must be heavily penalized and their license must be cancelled. Waster from residential households must be treated and used in agriculture.', '406', '23-Apr-2015', '0'),
(16, 'jinal784', 'A plan should be made for stopping of all drainage of city and industries in revers. All drainage should be collected at separate place for use of irregration.', '406', '23-Apr-2015', '0'),
(17, 'jinal784', 'A plan should be made for stopping of all drainage of city and industries in revers. All drainage should be collected at separate place for use of irregration.', '406', '23-Apr-2015', '0'),
(18, 'jinal784', 'I think the government should allow exhibition from various states, cultural programmes from other states, poets meet. Apart from all these above government should open sports coaching in stadium by retired professional sportsman so that they can shape next talent of nation. and government should allow coaching for private students which do not get selected by government officials.', '583', '23-Apr-2015', '0'),
(19, 'jinal784', 'As per the Rio Declaration on Environment and Development,â€œhuman beings are at the center of concerns for sustainable development,and that they are entitled to a healthy and productive life.â€The goals of sustainable transformation can only be achieved in the absence of a high prevalence of debilitating diseases.Accordingly,there is an urgent need to address the causes of ill health,including environmental causes,with more emphasis on women and children,as well as vulnerable groups of society.', '228', '23-Apr-2015', '0'),
(20, 'jinal784', 'NOW IN THIS ADVANCED ERA ALSO WOMENS FACES MANY A PROBLEMS .......SO IT IS NECESSARY TO CONSIDER THEM AND GIVING THEM AN EQUAL OPPURTUNITY.....AND THE CASTE BASED RESERVATION SHOULD BE ABOLISHED AND WOMEN SHOULD GET A CHANCE TO EXPLORE THEIR SKILLS.', '68', '23-Apr-2015', '0'),
(21, 'jinal784', 'Govt has rightly made provision of linking aadhar with RTE. Parents of low income group send their child to work in metros. It is my request to Electronic Media to highlight the misuse of girl child, they are engaged in construction industries.Contractor should be taken in to task. NGOs may be engaged to educate poor parents so that they will think twice while asking child to work', '672', '23-Apr-2015', '0'),
(22, 'ankita308', 'Empowerment of girls :- Address the issue of security in their travel to school especially in rural areas. Clean,usable toilets a must in schools. Free food to girls during menstrual cycle. A regular campaign generating awareness among parents regarding importance of a girl education. Incentives to parents sending their girl to school and to the district recording highest child sex ratio', '672', '23-Apr-2015', '1'),
(23, 'ankita308', 'Kaun kahta hai ki parai hoti hai betiya, Kabhi ma banke god khelati, Kabhi bahan raksha sutra bandhti, Kabhi sangani banke kadmo ki, Parchhai hoti hai betiya, Dip jalao, khushiya manao, Jab ghar aye nanhi gudiya, Jholi bharegi khushio se, Har ghar ki shahanai hoti hai betiya, Har yug me avtar leti, Kabhi Kalpna, kabhi Teresa, Kabhi Rani lakshmi bai hoti hai betiya, (BETI BACHAO, BETI PADHAO, IS DUNIYA KO AAGE BADHAO),,,,,', '672', '23-Apr-2015', '1'),
(24, 'ankita308', 'A small request to Honorable PM, please get some law in place where a girl child is equally expected to be financially supportive to their parents in their old age. Let the every girl grow up educated, so that she will not be treated as a burden for her parents, Such law will indirectly affect many areas like Dowry, Girl Child Infancy, and Girl child education. PLEASE request from a daughter and a mother of a daughter', '68', '23-Apr-2015', '1'),
(25, 'ankita308', 'sarkar ko jarurt khadh padarth kaa mulya khud nirdharan karna chahiye. khali bil wagera lane se kuchh nahi hota hai , bajar me rate to coprate gharane hi tay karte hai . kahne ko population badhi hai magar pahle ki tulna me kheti bhi to badhi aur logon ki khurak ghati bhi hai . pahle se desh me anaj jyada ho raha hai magar jaata kahan hai aaj tak pata nahi chala . yadi puri fasal ko sab logon ke hisab se divide karenge to koi bhi bhukha nahi rahega fir bhi kuchh log bhukhe sote ha', '827', '23-Apr-2015', '1'),
(26, 'ankita308', 'PDS can be improved by many ways. First thing to do is to clean up the PDS system to define and enforce the eligiblity criteria for it. State Governemnts have done it 5 yrs before and it is not the same today. Convert / Modernize the PDS shops and ensure Govt does a direct marketing system with launch of each PDS as super store, so PDS is open to all general public and subsidy is granted only to eligible people based on AADHAR or any other National identity.', '827', '23-Apr-2015', '1'),
(29, 'pritesh888', 'hnsjaf', '498', '05-May-2015', '1');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `phone_no` varchar(50) NOT NULL,
  `email` varchar(500) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`no`, `phone_no`, `email`) VALUES
(24, '1234-234-4567', ''),
(26, '', 'myindiangov@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE IF NOT EXISTS `documents` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `apply_id` varchar(100) NOT NULL,
  `doc` varchar(50000) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=144 ;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`no`, `apply_id`, `doc`) VALUES
(80, '1464', '20150425_065658.jpg'),
(81, '1464', '20150425_065726.jpg'),
(82, '1464', '20150425_065827.jpg'),
(83, '1464', '20150425_065850.jpg'),
(84, '1464', '20150425_065923.jpg'),
(85, '1464', '20150425_070000.jpg'),
(94, '1755', '428030_341255949246963_1983749753_n.jpg'),
(95, '1755', '10842028_1580759245480765_1070034987562358220_o.jpg'),
(96, '1755', 'DAVP-1600X543.jpg'),
(97, '1755', 'entrepreneurship-education-1600x543-2.jpg'),
(98, '1755', 'fci-banner1600x543.jpg'),
(99, '1755', 'i-am-a-small-man-who-wants.jpg'),
(100, '1755', 'ideas_for_career_centre_new_0.jpg'),
(101, '1755', 'incredible.jpg'),
(102, '1755', 'incredible-india-facebook-cover_6509.jpg'),
(103, '1755', 'incredible-india-facebook-cover_6557.jpg'),
(104, '1755', 'incredible-india-facebook-cover_6571.jpg'),
(105, '1755', 'India-Textiles-1600x543.jpg'),
(106, '1755', 'india-tours-packages1.jpg'),
(107, '1755', 'Mann ki Baat-1600-534.jpg'),
(108, '1755', 'narendra modi Yes We Can Win Wallpaper.jpg'),
(109, '1755', 'Narendra-Modi-Best-Indian-Leader-Wallpapers.jpg'),
(110, '1755', 'NitiAyog-banner-1600-543.jpg'),
(111, '1755', 'PIB banner1600x543.jpg'),
(112, '1755', 'pm-mobile-app-(1600x543).jpg'),
(113, '1755', 'Sportspersons-banner.jpg'),
(114, '2397', '20150425_065608.jpg'),
(115, '2397', '20150425_065658.jpg'),
(116, '2397', '20150425_065726.jpg'),
(117, '2397', '20150425_065827.jpg'),
(118, '2397', '20150425_065850.jpg'),
(119, '2397', '20150425_065923.jpg'),
(125, '1890', '20150423_170109.jpg'),
(126, '1890', '20150424_075937.jpg'),
(127, '1890', '20150424_080014.jpg'),
(128, '1890', '20150424_080025.jpg'),
(129, '1890', '20150424_080043.jpg'),
(130, '1890', '20150424_080050.jpg'),
(131, '1890', '20150424_080116.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `mail` varchar(500) NOT NULL,
  `cmt` varchar(5000) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`no`, `mail`, `cmt`, `date`, `status`) VALUES
(5, 'charmi@gmail.com', 'nice website... all facilities are good...', '25-Apr-2015', '0'),
(6, 'bhumikamerai@gmail.com', 'We can directly apply for  government job..it is good Feature.', '25-Apr-2015', '1'),
(7, 'mayur@gmail.com', 'i like the facility for users to give their ideas and problems directly to government', '25-Apr-2015', '1');

-- --------------------------------------------------------

--
-- Table structure for table `footer_menu`
--

CREATE TABLE IF NOT EXISTS `footer_menu` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `f_menu` varchar(200) NOT NULL,
  `f_link` varchar(200) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `footer_menu`
--

INSERT INTO `footer_menu` (`no`, `f_menu`, `f_link`) VALUES
(1, 'home', 'home.php'),
(7, 'overview', 'overview.php'),
(8, 'Site map', 'site_map.php'),
(9, 'terms & conditions', 'terms.php'),
(10, 'feedback', 'feedback.php'),
(21, 'help', 'help.php');

-- --------------------------------------------------------

--
-- Table structure for table `grp_tbl`
--

CREATE TABLE IF NOT EXISTS `grp_tbl` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=81 ;

--
-- Dumping data for table `grp_tbl`
--

INSERT INTO `grp_tbl` (`no`, `name`) VALUES
(53, 'clean ganga'),
(54, 'food security'),
(55, 'green india'),
(56, 'indian railways'),
(57, 'caring for the specially abled'),
(58, 'skill development'),
(59, 'dadra nagar havely UT'),
(60, 'digital india'),
(61, 'girl child education'),
(62, 'healthy india'),
(63, 'job creation'),
(64, 'new education policy'),
(65, 'sporty india'),
(66, 'saansad adarsh gram yojana'),
(67, 'watershead management'),
(68, 'beti bachao beti padhao'),
(69, 'government advertisements'),
(70, 'incredible india'),
(71, 'man ki baat'),
(72, 'sakriya panchayat'),
(73, 'swachh bharat'),
(74, 'youth for nation building'),
(75, 'NRIs for india growth'),
(76, 'challenges in petroleum sector'),
(77, 'consumer protection and internal trade'),
(78, 'energy conservation'),
(79, 'chemicals and petrochemicals'),
(80, 'expenditure management commission');

-- --------------------------------------------------------

--
-- Table structure for table `honours_award_tbl`
--

CREATE TABLE IF NOT EXISTS `honours_award_tbl` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `award_name` varchar(500) NOT NULL,
  `details` varchar(5000) NOT NULL,
  `image` varchar(2000) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `honours_award_tbl`
--

INSERT INTO `honours_award_tbl` (`no`, `award_name`, `details`, `image`) VALUES
(9, 'Bharat Ratna', 'Bharat Ratna (translates to Jewel of India or Gem of India in English) is Indias highest civilian award, awarded for the highest degrees of national service. This service includes artistic, literary, and scientific achievements, as well as "recognition of public service of the highest order." Unlike knights, holders of the Bharat Ratna carry no special title nor any other honorifics, but they do have a place in the Indian order of precedence. The award was established by the first President of India, Rajendra Prasad, on January 2, 1954. Along with other major national honours, such as the Padma Vibhushan, Padma Bhushan and Padma Shri, the awarding of the Bharat Ratna was suspended from July 13, 1977 to January 26, 1980. The honour has been awarded to forty persons, a list which includes two non-Indians and a naturalized Indian citizen. Tamil Nadu and Uttar Pradesh are the states with the most number of awardees (7 each). Originally, the specifications for the award called for a circular gold medal carrying the state emblem and motto, among other things. It is uncertain if a design in accordance with the original specifications was ever made. The actual award is designed in the shape of a peepul leaf and carries with the words "Bharat Ratna", inscribed in Devanagari script. The reverse side of the medal carries the state emblem and motto. The award is attached to a two-inch long ribbon, and was designed to be worn around the recipient neck.', '../upload/bharat ratna.jpg'),
(10, ' Gandhi Peace Prize ', 'The International Gandhi Peace Prize, named after Mahatma Gandhi, is awarded annually by the government of India.\r\n\r\nAs a tribute to the ideals espoused by Gandhi, the Government of India launched the International Gandhi Peace Prize in 1995 on the occasion of the 125th birth anniversary of Mahatma Gandhi. This is an annual award given to individuals and institutions for their contributions towards social, economic and political transformation through non-violence and other Gandhian methods. The award carries Rs. 10 million in cash, convertible in any currency in the world, a plaque and a citation. It is open to all persons regardless of nationality, race, creed or sex.\r\n\r\nA jury consisting of the Prime Minister of India, the Leader of the Opposition in the Lok Sabha, Chief Justice of India and two other eminent persons decides the awardee each year.\r\n\r\nOrdinarily, only proposals coming from competent persons invited to nominate are considered. However, a proposal is not taken as invalid for consideration by the jury merely on the ground of not having emanated from competent persons. If, however, it is considered that none of the proposals merit recognition, the jury is free to withhold the award for that year. Only achievements within 10 years immediately preceding the nomination are considered for the award; an older work may, however, be considered if its significance has not become apparent until recently. A written work, in order to be eligible for consideration, should have been published.', '../upload/gandhi_peace_prize_2002.jpg'),
(11, 'Padma Vibhushan', 'The Padma Vibhushan is Indias second highest civilian honour. It consists of a medal and a citation and is awarded by the President of India.\r\n\r\nIt is awarded to recognize exceptional and distinguished service to the nation in any field, including government service.\r\nThe award was suspended between 1977 and 1980. No award was made between 1992 and 1998 as well.\r\n\r\nThe award was established by Presidential decree on 2 January 1954. It comes after the Bharat Ratna and before the Padma Bhushan. Padma Vibhushan was originally established as the Pahela Varg (First Class) of a three-class "Padma Vibhushan" awards. However the structure was changed in 1955 and there is no record of the award being presented to any of the recipients in the original structure.', '../upload/Padma-Vibhushan-Awards-2013.jpg'),
(12, 'Padma Bhushan', 'The Padma Bhushan award is an Indian civilian decoration established on January 2, 1954 by the President of India. It stands third in the hierarchy of civilian awards, after the Bharat Ratna and the Padma Vibhushan, but comes before the Padma Sri. It is awarded to recognize distinguished service of a high order to the nation, in any field.', '../upload/padma-bhushan.jpg'),
(13, 'Padma Shri', 'Padma Shri (also spelt Padma Shree, Padmashree, Padma Sree and Padma Sri) is an award given by the Government of India generally to Indian citizens to recognize their distinguished contribution in various spheres of activity including the Arts, Education, Industry, Literature, Science, Sports, Social Service and public life. (The word "Padma" (Sanskrit) means "Lotus".)\r\n\r\nIt stands fourth in the hierarchy of civilian awards after the Bharat Ratna, the Padma Vibhushan and the Padma Bhushan. On its obverse, the words "Padma" and "Shri", in Devanagari, appear above and below the lotus flower. The geometrical pattern on either side is in burnished bronze. All embossing is in white gold.\r\n\r\nIn 1960 Dr.M.G.Ramachandran refused to accept the award as the wordings of the award is in Hindi.\r\n\r\nAs of February 2008, 2095 people have received the award.', '../upload/Padma Shri medal.jpg'),
(14, 'Pravasi Bharatiya Samman', 'The Pravasi Bharatiya Samman is an award constituted by the Ministry of Overseas Indian Affairs in conjunction with the Pravasi Bharatiya Divas, to honor exceptional and meritorious contribution in their chosen field/profession. The award is given by the President of India.', '../upload/Pravasi-Bharathiya-Divas.jpg'),
(15, 'Dadasaheb Phalke Award', 'The Dadasaheb Phalke Award is an annual award given by the Indian government for lifetime contribution to Indian cinema. It was instituted in 1969, the birth centenary year of Dadasaheb Phalke, considered the father of Indian cinema.\r\n\r\nThe award for a particular year is given during the end of the following year along with the National Film Awards. The Bombay High Court had directed the Directorate of Film Festivals of India (DFFI) to consider uncensored films for the competition, a case which DFFI contested and won in the Supreme Court in late 2006.', '../upload/Dadasaheb Phalke Award.jpg'),
(16, 'Param Vir Chakra ', '\r\nThe Param Vir Chakra (PVC) is Indias highest military decoration awarded for the highest degree of valour or self-sacrifice in the presence of the enemy, similar to the British Victoria Cross, US Medal of Honor, or French Legion of Honor. It can be awarded posthumously with many of the awards having been awarded posthumously.\r\n\r\nParam Vir means "Bravest of the Brave" in Sanskrit. (Param = Highest; VÄ«r = Brave (warrior); Chakra = wheel/medal).\r\n\r\nThe PVC was established on 26 January 1950 (the date of India becoming a republic), by the President of India, with effect from 15 August 1947 (the date of Indian independence). It can be awarded to officers or enlisted personnel from all branches of the Indian military. It is the second highest award of the government of India after Bharat Ratna (amendment in the statute on 26 January 1980 resulted in this order of wearing). It replaced the former British colonial Victoria Cross (VC), (see List of Indian Victoria Cross recipients).\r\n\r\nProvision was made for the award of a bar for second (or subsequent) awards of the Param Vir Chakra. To date, there have been no such awards. Award of the decoration carries with it the right to use P.V.C. as a post-nominal abbreviation.\r\n\r\nThe award also carries a cash allowance for those under the rank of lieutenant (or the appropriate service equivalent) and, in some cases, a cash award. On the death of the recipient, the pension is transferred to the widow until her death or remarriage. The paltry amount of the pension has been a rather controversial issue throughout the life of the decoration. By March 1999, the stipend stood at Rs. 1500 per month. In addition, many states have established individual pension rewards that far exceeds the central governments stipend for the recipients of the decoration.\r\n\r\nSubedar Major Bana Singh of the Eighth Jammu and Kashmir Light Infantry was the only serving personnel of the Indian defence establishment with a Param Vir Chakra till the Kargil operations.\r\n', '../upload/Param Vir Chakra  medal.jpg'),
(17, 'Ashoka Chakra', 'The Ashoka Chakra is an Indian military decoration awarded for valor, courageous action or self-sacrifice away from the battlefield. It is the peace time equivalent of the Param Vir Chakra, and is awarded for the "most conspicuous bravery or some daring or pre-eminent valour or self-sacrifice" other than in the face of the enemy. The decoration may be awarded either to military or civilian personnel and may be awarded posthumously.\r\n\r\nSubsequent awards of the Ashoka Chakra are recognized by a bar to the medal ribbon (to date, none have been awarded). It is possible for a recipient to be awarded the Kirti Chakra or Shaurya Chakra in addition for separate acts of gallantry.\r\n\r\nThe medal was originally established on 4 January 1952 as the "Ashoka Chakra, Class I" as the first step of a three-class sequence of non-combatant bravery decorations. In 1967, these decorations were removed from the "class-based" system and renamed as the Ashoka Charkra, Kirti Chakra, and Shaurya Chakra. This is an important point in understanding the independent Indian view of decorations. It would also lead to changes in the Padma Vibhushan series, the distinguished service medal series, the life saving medal series, and the Defence Security Corps medal series.\r\n\r\nFrom 1 February 1999, the central government instituted a monthly stipend for Ashoka Chakra recipients of Rs. 1400. Jammu and Kashmir awarded a cash award of Rs. 1500 (ca. 1960) for recipients of this award.\r\n\r\nObverse: Circular gold gilt, 1-3/8 inches in diameter. In the center, the chakra (wheel) of Ashoka, surrounded by a lotus wreath and with an ornate edge. Suspended by a straight bar suspender. The medal is named on the edge.\r\nReverse: Blank in the center, with "Ashoka Chakra" in Hindi along the upper edge on the medal and the same name in English along the lower rim, "ASHOKA CHAKRA". On either side is a lotus design. The center is blank, perhaps with the intent that details of the award be engraved there. There is no indication of the class on the pre-1967 awards, and, in fact, there is no difference between these medals and the post-1967 awards.\r\nRibbon: 32 mm, dark green with a 2 mm central saffron stripe. Dark green 15 mm, saffron 2 mm, dark green 15 mm.', '../upload/Ashoka Chakra  medal.jpg'),
(18, 'Maha Vir Chakra', 'The Maha Vira Chakra (MVC) is the second highest military decoration in India and is awarded for acts of conspicuous gallantry in the presence of the enemy, whether on land, at sea or in the air. It may be awarded posthumously. Literally Maha Vira Chakra means Great Hero Wheel. In Sanskrit Maha = Great, Vira = Hero and Chakra = Wheel. The medal is made of standard silver and is circular in shape. Embossed on the obverse is a five pointed heraldic star with circular center-piece bearing the gilded state emblem of India in the center. The words "Mahavira Chakra" are embossed in Devanagari and English on the reverse with two lotus flowers in the middle. The decoration is worn on the left breast with a half-white and half-orange riband about 3.2 cm in width, the orange being near the left shoulder.\r\n\r\nMore than 155 acts of bravery and selfless courage have been recognized since the inception of the medal. The most MVCs awarded in a single conflict was in the Indo-Pakistani War of 1971, when eleven were given to the Indian Air Force.\r\n\r\nProvision was made for the award of a bar for a second award of the Maha Vira Chakra, the first two being awarded in 1965. To date, there are six known awards of a first bar: Wing Commander Jag Mohan Nath (1962 and 1 September 1965), Major General Rajindar Singh (19 March 1948 and 6 September 1965), General Arun Shridhar Vaidya (16 September 1965 and 5 December 1971), Wing Commander Padmanabha Gautam (6 September 1965 and 5 December 1971 [posthumous]), Colonel Chewang Rinchen (July 1948 and 8 December 1971), and Brigadier Sant Singh (2 November 1965 and January 1972),. No second bars have been awarded. Award of the decoration carried with it the right to use M.V.C. as a postnominal abbreviation.', '../upload/Maha Vir Chakra medal 1.jpg'),
(19, 'Vir Chakra', 'Vira Chakra is an Indian gallantry award presented for acts of bravery in the battlefield. Award of the decoration carried with it the right to use Vr.C. as a postnominal abbreviation (note the care to distinguish this abbreviation from that for the Victoria Cross (V.C.). It is third in precedence in the war time gallantry awards and comes after the Param Vir Chakra and Maha Vir Chakra.\r\n\r\nProvision was made for the award of a bar for a second award of the Vira Chakra, with the first three awards of such a bar coming in 1948.\r\n\r\nThe award carries with it a cash allowance and, in some cases, a lump sum cash award. This has been a rather controversial issue throughout the life of the decoration. From 1 February 1999, the central government set a monthly stipend of Rs. 850 for recipients of the award. In addition, many states have established individual pension rewards for the recipients of the decoration.\r\n\r\nEstablished: Established by the President of India on 26 January 1950 (with effect from 15 August 1947). The statutes were amended 12 January 1952 to readjust the order of wearing as new decorations were established.\r\n\r\nObverse: 1-3/8 inch circular silver medal. A five pointed star, with the chakra in the center, and, on this, the domed gilded state emblem. The decoration is named on the rim and suspended from a swiveling straight-bar suspender. The decoration is almost always named and dated on the edge.\r\nReverse: Around a plain center, two legends separated by lotus flowers; above Vir Chakra in Hindi and in English.\r\nRibbon: 32 mm, half dark blue and half orange-saffron. Dark blue 16 mm, saffron 16 mm.', '../upload/Vir Chakra medal.jpg'),
(20, 'Shaurya Chakra', '\r\nShaurya Chakra is an Indian military decoration awarded for valor, courageous action or self-sacrifice while not engaged in direct action with the enemy. It may be awarded to civilians as well as military personnel, sometimes posthumously. It is the peacetime equivalent of the Vir Chakra. It is generally awarded for Counter-Insurgency ops & actions against the enemy during peace-time. It is third in order of precedence of peacetime gallantry awards and comes after Ashoka Chakra and Kirti Chakra. It precedes the Sena Medal. Before 1967, the award was known as the Ashoka Chakra, Class III.\r\n\r\nSubsequent awards of the Shaurya Chakra are recognized by a bar to the medal ribbon (to date, none have been awarded). It is possible for a recipient to be awarded the Ashoka Chakra or Kirti Chakra in addition for separate acts of gallantry.\r\n\r\nFrom 1 February 1999, the central government set a monthly stipend of Rs. 750 for recipients of the award. Jammu and Kashmir awards a cash award of Rs. 700 (ca. 1960) for recipients of the Shaurya Chakra.\r\n\r\nEstablished: Established as the "Ashoka Chakra, Class III" by the President of India, 4 January 1952 (with effect from 15 August 1947). The statutes were revised and the decoration renamed on 27 January 1967.\r\n\r\nObverse: Circular bronze, 1-3/8 inches in diameter. In the center, the chakra (wheel) of Ashoka, surrounded by a lotus wreath and with an ornate edge. Suspended by a straight bar suspender. The medal is named on the edge.\r\nReverse: For pre-1967 awards, the medal is blank in the center, with "Ashoka Chakra" in Hindi along the upper edge on the medal and the same name in English along the lower rim, "ASHOKA CHAKRA". On either side is a lotus design. The center is blank, perhaps with the intent that details of the award be engraved there. There is no indication of the class on the pre-1967 awards. For the post-1967 awards, the, names are changed to "Shauryua Chakra" in Hindi above and "SHAURYA CHAKRA" below.\r\nRibbon: 30 mm, dark green with three 2 mm orange stripes. Dark green 6 mm, orange 2 mm, dark green 6 mm, orange 2 mm, dark green 6 mm, orange 2 mm, dark green 6 mm.\r\n', '../upload/Shaurya Chakra medal.jpg'),
(21, 'Kirti Chakra', '\r\nKirti Chakra is an Indian military decoration awarded for valor, courageous action or self-sacrifice away from the field of battle. It may be awarded to civilians as well as military personnel, including posthumous awards. It is the peacetime equivalent of the Maha Vir Chakra. It is second in order of precedence of peacetime gallantry awards; it comes after Ashoka Chakra and before Shaurya Chakra. Before 1967, the award was known as the Ashoka Chakra, Class II.\r\n\r\nSubsequent awards of the Kirti Chakra are recognized by a bar to the medal ribbon (to date, none have been awarded). It is possible for a recipient to be awarded the Ashoka Chakra or Shaurya Chakra in addition for separate acts of gallantry.\r\n\r\nFrom 1 February 1999, the central government set a monthly stipend of Rs. 1050 for recipients of the award. Jammu and Kashmir awards a cash award of Rs. 1000 (ca. 1960) for recipients of the Kirti Chakra.\r\n\r\nEstablished: Established as the "Ashoka Chakra, Class II" by the President of India, 4 January 1952 (with effect from 15 August 1947). The statutes were revised and the decoration renamed on 27 January 1967.\r\n\r\nObverse: Circular silver, 1-3/8 inches in diameter. In the center, the chakra (wheel) of Ashoka, surrounded by a lotus wreath and with an ornate edge. Suspended by a straight bar suspender. The medal is named on the edge.\r\nReverse: For pre-1967 awards, the medal is blank in the center, with "Ashoka Chakra" in Hindi along the upper edge on the medal and the same name in English along the lower rim, "ASHOKA CHAKRA". On either side is a lotus design. The center is blank, perhaps with the intent that details of the award be engraved there. There is no indication of the class on the pre-1967 awards. For the post-1967 awards, the, names are changed to "Kirti Chakra" in Hindi above and "KIRTI CHAKRA" below.\r\nRibbon: 30 mm, dark green with two 2 mm saffron stripes. Dark green 8.5 mm, saffron 2 mm, dark green 9 mm, saffron 2 mm, dark green 8.5 mm.\r\n', '../upload/Kirti Chakra medal.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `job_apply_tbl`
--

CREATE TABLE IF NOT EXISTS `job_apply_tbl` (
  `no` int(10) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(500) NOT NULL,
  `age` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `email` varchar(500) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `exp` varchar(10) NOT NULL,
  `skill` varchar(1000) NOT NULL,
  `date` varchar(100) NOT NULL,
  `apply_id` varchar(10) NOT NULL,
  `v_id` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `job_apply_tbl`
--

INSERT INTO `job_apply_tbl` (`no`, `full_name`, `age`, `gender`, `email`, `mobile`, `address`, `exp`, `skill`, `date`, `apply_id`, `v_id`, `status`) VALUES
(53, 'patel karishmaben girishbhai', '24', 'female', 'patelkarishma123@yahoo.com', '9586131564', 'at.po:-boarding,behind animal dispensary,navsari,gujarat 396433', '2', 'teacheing,reading,singing', '25-04-2015', '1464', '456', '0'),
(55, 'patel pritesh g', '55', 'male', 'pritesh746@gmail.com', '9586131564', 'at.po:-boarding,behind animal dispensary,navsari,gujarat 396433', '2', 'cricket', '25-04-2015', '1755', '335', '0'),
(56, 'patel karishma g', '34', 'female', 'patelkarishma123@yahoo.com', '9586131564', 'at.po:-boarding,behind animal dispensary,navsari,gujarat 396433', '5', 'teacheing,reading,singing', '25-04-2015', '2397', '216', '1'),
(58, 'patel bijal girishbhai', '22', 'female', 'patelbijal@gmail.com', '8239483974', 'at.po:-boarding,behind animal dispensary,navsari,gujarat 396433', '2', 'typing', '25-04-2015', '1890', '488', '1');

-- --------------------------------------------------------

--
-- Table structure for table `job_vacancies_tbl`
--

CREATE TABLE IF NOT EXISTS `job_vacancies_tbl` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `sub` varchar(1000) NOT NULL,
  `job_title` varchar(500) NOT NULL,
  `desc` varchar(5000) NOT NULL,
  `age` varchar(100) NOT NULL,
  `address` varchar(5000) NOT NULL,
  `exp` varchar(100) NOT NULL,
  `post_date` varchar(100) NOT NULL,
  `last_date` date NOT NULL,
  `v_id` varchar(100) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `job_vacancies_tbl`
--

INSERT INTO `job_vacancies_tbl` (`no`, `sub`, `job_title`, `desc`, `age`, `address`, `exp`, `post_date`, `last_date`, `v_id`) VALUES
(8, 'Ministry Of Defence Recruitment Various LDC, MTS & Guest Operator Post 2015', 'Guest Operator', 'guest opreator 1, total post 14, MTS Messenger 03,take your skill..', '18 to 25', 'post box no 34523.rajhans complex, mahavir road ahembada.', '2', '23-04-2015', '2015-04-30', '87'),
(9, 'Indian Overseas Bank List of Selected Candidates (Waiting List) for Clerk posts 2015', 'clerk', 'Indian Overseas Bank has released the List of Selected Candidates for the posts of Clerk under Recruitment Project CWE â€“ III (Second Round of Allotment).', '22 to 35', 'post box no 09888 nagar haveli bno 101 junathana navsari', '4', '23-04-2015', '2015-05-07', '8'),
(10, 'BOI Recruitment for Senior Vice President & other posts-2015', 'Senior Vice President', 'Graduation in any Group subjects/Should be serving /Retired Officer at the level of Assistant General manager from any scheduled Commercial Bank/25 years experience in Financial Sector.', '25 to 65', 'post box no 6237846, BOI company borivali mumbai', '10', '23-04-2015', '2015-04-28', '352'),
(11, 'National Cooperative Development Corporation Recruitment 2015', 'Programme Officer', ' Degree with not less than 50% marks (relaxable upto 45% in the case of SC/ST) + 02 Years Post Qualification Experience / Degree or Diploma in Engineering Discipline with 01 year post qualification experience.here programme officer post 15,PB-2: Rs.9300-34800/- + GP Rs.4600/-', '20 to 30', 'post box no 6786868 chandani chok National Cooperative Development, Dilhi', '2', '23-04-2015', '2015-05-13', '33'),
(12, 'Consultant-bench Sales (US Staffing)2015', 'Manager', 'We are looking for a profile with at least 3-5 years of experience in Bench Sales/Recruitment Sales/Bench Marketing\nShould be keen to work in night shift. Must have excellent written and oral communication skills as he need to support XDuce US office. \nShould have eagerness to learn new things with positive attitude. Should have computer proficiency and internet savvy. \nUS accent is an extra feather to have. \n', '20 to 45', 'post box no 78788778, veer mohholoo Consultant bench,baroda', '5', '23-04-2015', '2015-05-01', '30'),
(13, 'GSECL Recruitment For 10 Vidyut Sahayak (Junior Engineer)2015', 'Engineer', 'Gujarat State Electricity Corporation Limited (GSECL) invites applications for recruitment of Vidyut Sahayak (Junior Engineer) (Civil) at Gujarat State Electricity Corporation Limited (GSECL), Vadodara, Gujarat from the eligible candidates. Last date for application is 2nd May 2015', '25 to 50', 'Vadodara, Gujarat', '5', '23-04-2015', '2015-04-28', '450'),
(14, 'Junior Research Fellow jobs at Pandit Deendayal Petroleum University (PDPU) April 2015', 'Junior Research ', 'Pandit Deendayal Petroleum University (PDPU) invites applications for recruitment of Junior Research Fellow (JRF) at Pandit Deendayal Petroleum University (PDPU), Gandhinagar, Gujarat from the eligible candidates.', '25 to 55', 'Solar Research & Development Centre Pandit Deendayal Petroleum University E Block, PDPU Campus, Koba Gandhinagar Highway Raisan, Gandhinagar â€“ 382 007', '5', '23-04-2015', '2015-05-02', '404'),
(15, 'General Manager jobs at National Dairy Development Board (NDDB) April 2015', 'General Manager', 'National Dairy Development Board (NDDB) invites applications for recruitment of General Manager (HRD) at National Dairy Development Board (NDDB), Anand, Gujarat from the eligible candidates.Minimum 20 years of relevant post-qualification experience in the Human Resources function of a reputed organization. Candidates having experience of working in public sector undertakings will have an added advantage.', '27 to 60', 'National Dairy Development Board P.B. No. 40 Anand - 388 001 Gujarat INDIA', '15', '23-04-2015', '2015-05-26', '307'),
(16, 'Assistant jobs at Institute of Rural Management Anand (IRMA) April 2015', 'Assistant', 'Institute of Rural Management Anand (IRMA) invites applications for recruitment of Assistant (Academics) at Institute of Rural Management Anand (IRMA), Anand, Gujarat from the eligible candidates.INR 11000/- per monthCandidate should have passed Graduate in any discipline. One to two years of working experience as an Assistant in any Academic environment shall be preferred. The incumbent should also be well versed to work in a computerized environment. The incumbent should have knowledge of MS-Office-MS Excel, MS Word and MS Power point.', '25 to 40', 'Institute of Rural Management Post Box No. 60, Anand 388001. Gujarat. India.', '7', '23-04-2015', '2015-05-18', '488'),
(17, '109 Compounder jobs at Gujarat Secondary Service Selection Board (GSSSB) April 2015', ' Compounder Science and Research Jobs', 'Gujarat Secondary Service Selection Board (GSSSB) invites applications for recruitment of Compounder at Gujarat Secondary Service Selection Board (GSSSB), Ahmedabad, Gujarat from the eligible candidates.INR 13500/- Per Month,Candidate should have passed B.Pharm/D.Pharm.', '27 to 55', 'Gujarat Secondary Service Selection Board, Block no. - 4, first floor, Dr. Jivraj Mehta Bhavan , Gandhinagar 010 382.', '3', '23-04-2015', '2015-05-06', '90'),
(18, '443 Staff Nurse jobs at Gujarat Secondary Service Selection Board (GSSSB) April 2015', 'Staff Nurse', 'Gujarat Secondary Service Selection Board (GSSSB) invites applications for recruitment of Staff Nurse at Gujarat Secondary Service Selection Board (GSSSB), Ahmedabad, Gujarat from the eligible candidates.', '23 to 40', 'Gujarat Secondary Service Selection Board, Block no. - 4, first floor, Dr. Jivraj Mehta Bhavan , Gandhinagar 010 382.010382 Gandhinagar, Gujarat', '2', '23-04-2015', '2015-05-06', '161'),
(19, 'IIIT Vadodara Recruitment For System Administrator, Peon and Various Posts 2015', 'Library Assistant', 'Indian Institute of Information Technology Vadodara (IIIT Vadodara) invites applications for recruitment of Assistant Registrar, System Administrator, Technical Superintendent, Library Assistant, Administrative Assistant, Hostel Manager, Messenger cum Peon at Indian Institute of Information Technology Vadodara (IIIT Vadodara), Vadodara, Gujarat from the eligible candidates.', '22 to 30', 'INDIAN INSTITUTE OF INFORMATION TECHNOLOGY, VADODARA C/o, Block No.9 (IC Department), Government Engineering College, Sector-28, Gandhinagar, Gujarat - 382028', '2', '23-04-2015', '2015-05-05', '216'),
(20, 'Technical Assistant jobs at KELTRON in Ahmedabad, April 2015', 'Engineering Jobs', 'Kerala State Electronics Development Corporation Limited (KELTRON) invites applications for recruitment of Technical Assistant at Kerala State Electronics Development Corporation Limited (KELTRON), Ahmedabad, Gujarat from the eligible candidates.', '23 to 38', 'Kerala State Electronics Development Corporation Limited Keltron House, Vellayambalam Thiruvananthapuram 695 033 Vellayambalam', '1', '23-04-2015', '2015-05-07', '53'),
(21, 'LIC Housing Finance Recruitment For 293 Assistant, Assistant Manager', 'Management Jobs', 'LIC Housing Finance Limited (LIC HFL) invites applications for recruitment of Assistant, Assistant Manager at LIC Housing Finance Limited (LIC HFL), from the eligible candidates. ', '25 to 40', ' LIC Housing Finance Limited Regional Manager LIC HOUSING FINANCE LTD. Jeevan Prakash, 4th Floor, Sir P. M. Road, Fort, MUMBAI - 400 001.Mumbai, Maharashtra', '2', '23-04-2015', '2015-05-11', '476'),
(22, 'Indian Air Force Recruitment 2015 For 47 LDC, MTS, Telephone Operator and Various Posts', 'Technician', 'Indian Air Force (IAF) invites applications for recruitment of Various Posts at Indian Air Force (IAF), Anywhere in India from the eligible candidates.Pay INR 1800/-, INR 1900/-', '26 to 55', ' Publicity Cell, Air Headquarters â€˜DISHAâ€™ Motilal Nehru Marg New Delhi â€“ 110 106', '4', '23-04-2015', '2015-05-17', '335'),
(23, 'sarswati vidhyadevi english school,2015', 'teachers', 'degree B.A, M.A, B.ed, minimum experious 2 years post your all education certificates,Qualification Experience,post your skill,per month rs.8000/-', '22 to 45', 'post box number : 73284728 , sarswati vidhyadevi english school, eru-vijalpore,navsari,gujarat.', '2', '25-04-2015', '2015-04-30', '456');

-- --------------------------------------------------------

--
-- Table structure for table `likers`
--

CREATE TABLE IF NOT EXISTS `likers` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `id_up` varchar(100) NOT NULL,
  `status` varchar(5) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `likers`
--

INSERT INTO `likers` (`no`, `u_id`, `id_up`, `status`) VALUES
(6, 'pritesh888', '596', '2'),
(7, 'ankita308', '583', '1'),
(8, 'ankita308', '445', '1'),
(9, 'ankita308', '68', '1'),
(10, 'pritesh888', '445', '2'),
(11, 'ankita308', '406', '2');

-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE IF NOT EXISTS `mails` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(100) NOT NULL,
  `reciver` varchar(100) NOT NULL,
  `msg` varchar(3000) NOT NULL,
  `date` varchar(100) NOT NULL,
  `a_status` varchar(10) NOT NULL,
  `u_status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `mails`
--

INSERT INTO `mails` (`no`, `sender`, `reciver`, `msg`, `date`, `a_status`, `u_status`) VALUES
(76, 'mygov', 'pritesh746@gmail.com', 'bbfj', '05-May-15', '0', '0'),
(77, 'pritesh888', 'mygov', 'hsifdh', '05-May-15', '0', '0'),
(78, 'pritesh888', 'mygov', 'klv', '05-May-15', '0', '0'),
(79, 'mygov', 'pritesh746@gmail.com', 'hey', '05-May-15', '0', '0'),
(80, 'pritesh888', 'mygov', 'hsd', '05-May-15', '0', '1'),
(81, 'mygov', 'pritesh746@gmail.com', 'nksdj', '05-May-15', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `m_name` varchar(100) NOT NULL,
  `link_name` varchar(200) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`no`, `m_name`, `link_name`) VALUES
(33, 'home', 'home.php'),
(34, 'blog', 'blog.php'),
(35, 'discuss', 'discuss.php'),
(36, 'overview', 'overview.php'),
(38, 'services', 'services.php'),
(47, 'About us', 'about.php');

-- --------------------------------------------------------

--
-- Table structure for table `rules_tbl`
--

CREATE TABLE IF NOT EXISTS `rules_tbl` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `sub` varchar(1000) NOT NULL,
  `rules` varchar(5000) NOT NULL,
  `rules_id` varchar(100) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `rules_tbl`
--

INSERT INTO `rules_tbl` (`no`, `sub`, `rules`, `rules_id`) VALUES
(19, 'Prohibition of Cigarettes and other Tobacco Products Act 2003', 'You can get the Prohibition of Cigarettes and other Tobacco Products Act, 2003. Detailed information about the various provisions of the legislation is provided in this Act.', '100'),
(20, 'Airports Economic Regulatory Authority of India Act 2008', 'Information about the Airports Economic Regulatory Authority of India Act, 2008 is given. Users can get details related to the Act, its objectives, short title, application and commencement. Access to sections of the Act is also available.', '19'),
(21, 'Rajiv Gandhi National Aviation University Act 2013', 'Information about the Rajiv Gandhi National Aviation University Act, 2013 is given. Users can get details related to the Act, its short title, objectives, definitions, extent and commencement. Information about sections of the Act and Rajiv Gandhi National Aviation University is also available.', '561'),
(22, 'Child Labour (Prohibition and Regulation) Act 1986', 'Information related to the Child Labour (Prohibition and Regulation) Act 1986 is provided. Users can access details about the Act, its objectives and short title. Information on sections of the Act is also available.', '457'),
(23, 'Semiconductor Integrated Circuits Layout-Design Act 2000', 'Find information on the Semiconductor Integrated Circuits Layout-Design Act, 2000. Details related to the Act, its objectives, short title and commencement are given. Users can access information about sections of the Act.', '757'),
(24, 'Border Security Force (Amendment) Act 2000', 'Access to the Border Security Force (Amendment) Act, 2000 which includes amendments of the Border Security force Act 1968 is given. Information about the Act, its short title, objectives and commencement is given. Users can get details regarding sections and amendments of the Act.', '382'),
(25, 'All-India Institute of Medical Sciences (Amendment) Act 2000', 'Access to the All-India Institute of Medical Sciences (Amendment) Act, 2000 which consists an amendment in section 6 of the All-India Institute of Medical Sciences Act, 1956 is provided. Information about the Act, its objectives, short title and commencement is given. Users can get details regarding the amendments and sections of the Act.', '239'),
(26, 'Information on acts and rules of Department of Land Resources', 'Get information about land related acts and rules is provided by Department of Land Resources, Ministry of Rural Development. Detailed information on Land Acquisition Act 1894, Land Acquisition (Companies) Rules 1963, Registration Act 1908 and National Rehabilitation and Resettlement (R&R) Policy 2007 is available. Acts can be downloaded in both English and Hindi languages.', '372'),
(27, 'Uttar Pradesh Reorganisation Act 2000', 'Get details about the Uttar Pradesh Reorganisation Act, 2000. Users can access information about the Act, its objectives and commencement. Information about sections of the Act is also available.', '840'),
(28, 'Motor Vehicles (Amendment) Act 2000', 'Access to the Motor Vehicles (Amendment) Act, 2000 which consists an amendment in section 52, 58, 66 and 217A of the Motor Vehicles Act, 1988 is provided. Information about the Act, its objectives, short title and commencement is given. Users can get details regarding the amendments and sections of the Act.', '185'),
(29, 'Indian Companies (Foreign Interests) and the Companies (Temporary Restrictions on Dividends) Repeal Act 2000', 'Get details about the Indian Companies (Foreign Interests) and the Companies (Temporary Restrictions on Dividends) Repeal Act, 2000. Users can access information about the Act, its objectives and commencement. Information about sections of the Act is also available.', '923'),
(30, 'Iron and Steel Companies (Amalgamation and Takeover Laws) Repeal Act 2000', 'Get information on the Iron and Steel Companies (Amalgamation and Takeover Laws) Repeal Act, 2000. This act is enacted to repeal the Iron and Steel Companies Amalgamation Act, 1952 and the Indian Iron and Steel Company (Taking over of Management) Act, 1972. Users can access details related to the Act, its objectives, short title, definition and commencement. Information about sections of the Act is given.', '683'),
(31, 'Right to Information Act by General Administration Department of J&K', 'The Right to Information Act is provided by the General Administration Department of Jammu and Kashmir State Government. Users can get the RTI Act, circulars, forms, handbook, and PIOs contact details.', '551'),
(32, 'Gazette notification of Copyright Rules 2013', 'Find details of the Gazette notification of the Copyright Rules 2013 provided by the Ministry of Human Resource Development. The rule is in exercise of the powers conferred by Section 78 of the Copyright Act 1957 and in supersession of the Copyright rules 1958. Users can get the format of forms related to the rule.', '520'),
(33, 'Central Labour Acts by Ministry of Labour and Employment', 'Users can find various labour laws provided by the Ministry of Labour and Employment. Information about laws related to industrial relations, wages, working hours, conditions of service and employment, equality and empowerment of women etc. is given. The Trade Unions Act, Industrial Employment Act and Industrial Disputes Act are given.', '794'),
(34, 'Rajiv Gandhi National Institute of Youth Development Act 2012', 'Find details related to the Rajiv Gandhi National Institute of Youth Development Act, 2012. Information about the Act, its short title, objectives, commencement and definition is given. Users can get details regarding sections of the act and Rajiv Gandhi National Institute of Youth Development.', '357'),
(35, 'Criminal Law (Amendment) Act 2013', 'Get information about the Criminal Law (Amendment) Act, 2013. This Act constitutes amendments in Indian Penal Code (IPC), the Code of Criminal Procedure 1973, the Indian Evidence Act 1872 and Protection of Child from Sexual Offences Act , 2012. Details related to the Act, its objectives, short title and commencement are given.', '842'),
(36, 'Appropriation (Railways) Vote on Account Act 2014', 'Access to information about the Appropriation (Railways) Vote on Account Act, 2014 is provided. Users can get details about the Act, its objectives, short title and commencement. Information regarding sections and amendments of the Act is also available.', '494'),
(37, 'Delhi Appropriation Act 2014', 'Get details about the Delhi Appropriation Act, 2014. Users can access information about the Act, its objectives and commencement. Information about amendments and sections of the Act is also available.', '479'),
(38, 'Rani Lakshmi Bai Central Agricultural University Act 2014', 'Information about the Rani Lakshmi Bai Central Agricultural University Act 2014 is given. Users can get details regarding the Act, short title and objectives. Get detailed information about various sections of the Act.', '516'),
(39, 'National Institutes of Technology Science Education and Research (Amendment) Act 2014', 'Information on the National Institutes of Technology, Science Education and Research (Amendment) Act, 2014 which comprises of amendments in the National Institutes of Technology, Science Education and Research Act, 2007 is provided. Details related to the Act, its short title, commencement and objectives are given. Access to amendments and sections of the act is also available.', '147'),
(40, 'Street Vendors (Protection of Livelihood and Regulation of Street Vending) Act 2014', 'Find details about the Street Vendors (Protection of Livelihood and Regulation of Street Vending) Act, 2014. This Act extends to the whole of India except the State of Jammu and Kashmir. Users can get information on the Act, its objectives, short title and commencement. Information related to sections of the act is also given.', '533'),
(41, 'Acts and Rules of Department of Higher Education of Odisha', 'The Acts and Rules of the Higher Education Department of Odisha are provided. One can also find details on Acts and Rules notifications for private junior colleges and private colleges located in the state. Details regarding establishment, recognition and management of private and junior private colleges are also available.', '189'),
(42, 'Himachal Pradesh Building and Other Construction Workers (Regulation of Employment and Conditions of Service) Rules, 2008', 'The Himachal Pradesh Building and Other Construction Workers (Regulation of Employment and Conditions of Service) Rules, 2008 is provided. You can find detailed information related to the Rules and various other provisions.', '389'),
(43, 'Himachal Pradesh State Agricultural Marketing Board (Recruitment and Conditions of Service of Officers and Staff) Regulations, 2006', 'Himachal Pradesh State Agricultural Marketing Board (Recruitment and Conditions of Service of Officers and Staff) Regulations, 2006. You can find detailed information on the regulations and various other provisions.', '147'),
(44, 'Employment Exchange (Compulsory Notification of Vacancies) Rules, 1960', 'Employment Exchanges (Compulsory Notification of Vacancies) Rules, 1960 document is provided by the Director General of Employment and Training, Ministry of Labour and Employment. Detailed information related to the provisions of the Rules is available.', '821'),
(45, 'State Emblem of India (Prohibition of Improper Use) Act, 2005', 'The State Emblem of India (Prohibition of Improper Use) Act, 2005 is an Act to prohibit the improper use of State Emblem of India for professional and commercial purposes and for matters connected therewith or incidental thereto.', '631'),
(46, 'Information on cyber laws and security', 'Get information on cyber laws and security by Department of Electronics and Information Technology (DEITY), under Ministry of Communications and Information Technology. Users can access information on cyber security strategy and research and development (R&D). Documents related to cyber laws can be accessed. Links to Cyber Appellate Tribunal (CAT), Indian Computer Emergency Response Team (ICERT) and Controller of Certifying Authorities (CCA) are provided.', '954'),
(47, 'Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act 2013', 'Get information about the Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act 2013. Information about the act, its short title, objectives, definitions, extent and commencement is given. Details related to sections of the Act and Constitution of Local Complaints Committee is also available.', '538'),
(48, 'National Commission for Minority Educational Institutions (Amendment) Act 2010', 'Access details on National Commission for Minority Educational Institutions (Amendment) Act, 2010 which includes amendments in sections 2, 3, 10 and 12B of National Commission for Minority Educational Institutions Act, 2004 is provided. Information about the Act, its short title, objectives and commencement is given. Users can access details related to sections and amendments of the act.', '578'),
(49, 'Lokpal and Lokayuktas Act 2013', 'Get information about the Lokpal and Lokayuktas Act, 2013. Detailed information related to the various provisions of the legislation is provided. You can find some of the most important features of the Act such as establishment of the Lokpal Office, Government Offices coming under the Lokpal, appointment of the members, etc.', '535');

-- --------------------------------------------------------

--
-- Table structure for table `s_problem_cmt_tbl`
--

CREATE TABLE IF NOT EXISTS `s_problem_cmt_tbl` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `cmt` varchar(2000) NOT NULL,
  `pbm_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `s_problem_cmt_tbl`
--

INSERT INTO `s_problem_cmt_tbl` (`no`, `u_id`, `cmt`, `pbm_id`, `date`) VALUES
(11, 'mayur548', 'this is wonderful thing i must follow this openion', '150', '25-Apr-15');

-- --------------------------------------------------------

--
-- Table structure for table `s_problem_tbl`
--

CREATE TABLE IF NOT EXISTS `s_problem_tbl` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `problem_text` varchar(2000) NOT NULL,
  `pbm_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `s_problem_tbl`
--

INSERT INTO `s_problem_tbl` (`no`, `u_id`, `problem_text`, `pbm_id`, `date`, `status`) VALUES
(12, 'pritesh888', 'The cultural norms in India keep a check on the womanisation of sectors. One of the parameters that denote your family as BPL in Kerala is the presence of a woman run household. They are always regarded as the weaker species irrespective of the post they hold and the authority they command. India needs to focus on the other half of human being â€” the fairer sex.\n\nThere are several success stories about women. They are growing up. Lend them a hand or stay out of their way. Donâ€™t be a hindrance to the wombs that gave birth to you.', '259', '24-Apr-2015', '0'),
(15, 'jinal784', 'India is a major spot for medical tourism attracting people from around the world. But the status of medical technology is weak. We have been importing almost 90% of our technical equipments from round the world. Kits for very common diseases like malaria are imported from places abroad where the diseases are never heard of. Huge scanning equipments like MRI, CT Scan etc. are all brought from foreign dealers. China has a great lead compared to us due to its manufacturing units present. Unless and until we establish ourselves in manufacturing and distribution of medical equipments, the cost of treatment will rise and proper health care would be unaffordable by the already needy masses.', '14', '24-Apr-2015', '0'),
(17, 'mitul946', 'Talent is not lacking in a huge country like ours. Being the 7th largest country of the world with varied ethnicities, India has ripe and rich talent for every sport form. But proper harvest is what is missing. The recognition module for our sportspersons is very weak. With huge focus on big shot games like cricket, others take the sidelines. Probably a holistic development of every sport could get us more golds in the Olympics, and make India a country dreaded by sportspersons from aroung the world.\n\nOne of the initiatives in this aspect was the NBA held in India, where the government had tied up with the Mahindra Group for the game.', '150', '24-Apr-2015', '1');

-- --------------------------------------------------------

--
-- Table structure for table `s_think_cmt_tbl`
--

CREATE TABLE IF NOT EXISTS `s_think_cmt_tbl` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `cmt` varchar(2000) NOT NULL,
  `think_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `s_think_tbl`
--

CREATE TABLE IF NOT EXISTS `s_think_tbl` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `thinks` varchar(4000) NOT NULL,
  `think_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `s_think_tbl`
--

INSERT INTO `s_think_tbl` (`no`, `u_id`, `thinks`, `think_id`, `date`, `status`) VALUES
(15, 'mitul946', '\nChanging the education system is the need of the hour. Education system is one of the important pillars on which our society is developed. It should be an epitome of the past and at the same time it has to be contemporary.\n\nHow long are we just going to stick to the class room teaching? Teaching method calls for a change. Technology should be adopted; visual based teaching method with the help of broadband can be of great help for teachers in villages also .There is an urgent need to add more practicals in the subjects. Foreign languages, Co-Curriculum activities such as sports and music should be introduced in the syllabus. It should be coupled with technology and there has to be a structured education system in the country. Syllabus in villages and cities has to be uniformed. At the same time we have to see that our students learn our state language that is Gujarati. Our education system should recruit good teachers. And Gujarat state should have more number of Engineering, Pharma and Medical colleges.', '189', '24-Apr-2015', '0'),
(16, 'hiral889', '\nPoor people are practically not affording good quality healthcare facility and therefore they turn up to Quacks. A quality healthcare coverage in the form of Universal Health Insurance will help all people to get quality health care facilities. Government and Health Care department should promote Private Health care Facilities with certain quality standards in rural areas, in the from of tax relief, concessions in power, certain exemption in duty, etc. It will help rural population to have access to the highest quality healthcare.', '369', '24-Apr-2015', '0'),
(18, 'mitul946', 'Neat and clean city is what attracts every bodys attention. Every one of us would like to have a city that is clean neat and beautiful.If every citizen takes this issue a little more seriously it will help us to have clean and beautiful state. Simple steps like dumping the garbage in the waste bins will keep our roads and footpath clean. Municipal department should make sure that this waste is disposed properly. Every street in the city should have a waste bin. It should ensure that waste bins are kept near all the small stalls, pan shops and laaries. The owners should be fined if they dont have waste bins. Public places starting from a park to bus stop should be kept clean. Street cleaning should be on daily basis. Municipal department workers should be provided with equipments like hand blowers and sweeping machines which will save their time.', '36', '24-Apr-2015', '0'),
(19, 'mayur548', 'Agriculture and framing is the heart of the India. Its importance in economic social and political framework is endless. Its the most important source of income for the farmers. To improve and benefit the farmers of Gujarat we should start contract farming. Contract farming will make markets, credit, and technology available to the farmers. It will be beneficial to the farmers as government agencies are administrating the work. Farmers are owners in this sector but farming is done by agencies on contract basis. For corp investment is done by agencies. The facility provided by government is properly utilized. The corp produced is best in quality because of the modern technology used and provide good returns. Thus the concept of contract farming should be implemented and farmers should be educated on the benefits of contract farming.', '238', '24-Apr-2015', '0'),
(20, 'priya246', 'Youths are the spring of the welcome change, they come with the enthusiasm that is unstoppable, their hard work and commitment allows them to achieve the impossible. They have made their mark in all sectors, in all the work then why should Politics be an exception?\n\nWe should form a system by which youth can join politics. Chief Minister should visit the colleges and motivate young leaders to join the politics and serve the country. An online system should be developed, where youths can apply. This will help young people to join the BJP party. â€œThe Youth Powerâ€ has power to give the desired future to the country and should be given a chance to be an active member in politics.', '59', '24-Apr-2015', '0'),
(21, 'jagdish58', 'It is widely believed that skill gaps are constraining Indian manufacturing, and closing these gaps has become a national priority. This column argues that the public debate on Indiaâ€™s skill gaps rests on weak conceptual foundations. While some industries do suffer from real skill gaps, others are constrained by commercial difficulties that may be better addressed through policies other than skill development programmes.\n- See more at: http://www.ideasforindia.in/article.aspx?article_id=1437#sthash.vLoUQeSY.dpuf', '306', '24-Apr-2015', '0'),
(22, 'jagdish58', 'The recently announced Union budget 2015-16 has reduced the central government allocation for Swachh Bharat Mission â€“ the flagship sanitation programme of the government. In this article, Sangita Vyas, Managing Director for Sanitation at r.i.c.e., questions the commitment of the government to eliminating open defecation in India by 2019.\n\nSeveral weeks ago, we learned that the central government allocation to the Swachh Bharat Mission (SBM) in the coming financial year will be Rs. 3,500 crore (US$583.3 mn approx.), which is less than the current budgetary allocation of Rs. 4,260 crore (US$710 mn approx.) and much less than the originally promised Rs. 134,000 crore (US$22.3 bn approx.) over five years. With this amount of money, the government will hardly be able to build a toilet for every household lacking one in the next five years, as was initially promised. Donâ€™t get me wrong: I donâ€™t actually wish the financial outlay were any larger because research has shown that building latrines will do little to promote latrine use (Coffey et al. 2014). What this announcement represents, however, is one more reason to believe that the government is not serious about achieving its goal of eliminating open defecation by 2019. \n- See more at: http://www.ideasforindia.in/article.aspx?article_id=427#sthash.t68RTbgW.dpuf', '65', '24-Apr-2015', '1'),
(23, 'ankita308', 'India will overtake China to be the fastest growing economy this year. In this article, Chetan Ghate and Peter Robertson assess the validity of this claim. In their view, the challenge for India is to not only catch up with China, but to also catch up with itself. Strong democratic institutions and the right economic reforms can work in Indiaâ€™s favour.\n\nIn a recent media interview, Chief Economic Adviser to the Government of India, Arvind Subramanian, said: â€œWe are going to grow faster because we are poorer, so the fact that we are going to overtake China is good. But it is a reflection of how poorer we are than China in level terms. The flip puzzle for India is not that it is going to overtake China, but why it didnâ€™t do so earlierâ€. \n- See more at: http://www.ideasforindia.in/article.aspx?article_id=428#sthash.lUOWu3ng.dpuf', '155', '24-Apr-2015', '1'),
(24, 'ankita308', 'Only about a third of working-age women in India have jobs. This column analyses the determinants of womenâ€™s participation in the labour market in India and finds that factors such as family income, cultural norms and gender wage gap play an important role. It suggests that raising female labour force participation could boost economic growth by up to 2 percentage points.\n\nIndia is in many ways at a crossroads. The new government is in search of ignition to restart the growth engine and make it more inclusive. But if this is to happen, Indian women will have to be given the chance and the incentives to participate more in the labour market. Currently, female labour force participation is among the lowest in the emerging markets and declining. OECD (Organisation for Economic Co-operation and Development) calculations show that growth could be boosted by up to 2 percentage points with a package of pro-growth and pro-women policies. Understanding the nature and causes of female labour force participation in India is important to identify these policies. Recent OECD work (OECD 2014, Sorsa 2015, Daymard 2015) go into more depth than many previous ones to assess female labour market dynamics. - See more at: http://www.ideasforindia.in/article.aspx?article_id=431#sthash.9vq6NFO8.dpuf', '326', '24-Apr-2015', '1'),
(25, 'pooja886', 'Research has pointed towards the importance of foetal health in child development. Assessing the impact of rainfall variability on child health, this column finds that exposure to drought in the womb increases the childâ€™s likelihood of being underweight. It suggests that policies aimed at reducing child malnutrition need to start at the beginning of human life, that is, in the womb.\n- See more at: http://www.ideasforindia.in/article.aspx?article_id=405#sthash.RMNJkLPc.dpuf', '351', '24-Apr-2015', '1'),
(26, 'reshma979', 'Janani Suraksha Yojana - Indiaâ€™s safe motherhood programme â€“ provides poor women with a financial incentive for delivering births at health centres and seeking antenatal and postnatal care. This column finds that the programme has had limited success. While women with no formal education and those from rural areas have benefitted disproportionately, the programme has failed to reach the poorest women. - See more at: http://www.ideasforindia.in/article.aspx?article_id=390#sthash.mhm8wisQ.dpuf', '161', '24-Apr-2015', '1'),
(27, 'ankita308', 'Since the December 2012 rape incident in Delhi, numerous policies have been proposed to stop the â€œwar on womenâ€. In this article, Rohini Pande discusses economic research, including her own, on the social, legal and financial forces that cause individuals, families and the society to undervalue women and harm them. Such an understanding can help determine whether a policy may succeed, or create perverse incentives.\n\nIn December 2012, thousands of protesters flooded the streets of cities across India, demanding a safer environment for women. A 23-year-old female student had died from injuries sustained 13 days earlier, when six men raped and savagely beat her on a Delhi bus. The case gained international attention, and since then South Asian media have reported dozens more horrifying instances of violence against women, several involving tourists: a Danish woman was gang-raped in Delhi after asking for directions back to her hotel, and an American was raped while hitchhiking in the Himalayas.\n- See more at: http://www.ideasforindia.in/article.aspx?article_id=393#sthash.juEE01Tq.dpuf', '88', '24-Apr-2015', '1');

-- --------------------------------------------------------

--
-- Table structure for table `scholarship`
--

CREATE TABLE IF NOT EXISTS `scholarship` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `owner_name` varchar(500) NOT NULL,
  `details` varchar(2000) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `scholarship`
--

INSERT INTO `scholarship` (`no`, `owner_name`, `details`) VALUES
(22, 'CENTRAL SECTOR SCHEME OF RAJIV GANDHI NATIONAL FELLOWSHIP', 'PROVIDING SCHOLARSHIPS TO SCHEDULED CASTE STUDENTS TO PURSUE PROGRAMMES IN HIGHER EDUCATION SUCH AS M.Phil. AND Ph.D. (Effective from 01-04-2010)'),
(23, 'CENTRALLY SPONSORED SCHEME OF PRE MATRIC SCHOLARSHIP', 'Article 46 of Part IV (â€œDirective Principles of State Policyâ€) of theConstitution enjoins upon the State to promote with special care the educationaland economic interests of the weaker sections of the people, in particular, of theScheduled Castes and the Scheduled Tribes. Article 38(2) of the same Part alsoenjoins upon the State to minimize inequities in income and to endeavour toeliminate inequalities in status, facilities and opportunities, not only amongst individuals but also amongst groups of people residing in different areas orengaged in different vocations.'),
(24, 'Post Matric Scholarships for Scheduled Castes  Scheduled Tribes Students', 'The Post Matric Scholarships enables a considerable number of Scheduled Caste students to obtain post-matric and higher level of education resulting in their over all educational and economic development. The Scheme provides for 100 per cent Central Assistance to the State Governments and UT Administrations over and above the respective committed liability of the State/UT. The committed liability of the North Eastern States has, however, been dispensed with. The scheme presently covers over 30 lakh Scheduled Caste students.'),
(25, 'SCHEME OF POST MATRIC SCHOLARSHIPS FOR OTHER BACKWARD CLASSES STUDENTS FOR STUDYING IN INDIA', 'The objective of the scheme is to provide financial assistance to the OBC students studying at post-matriculation or post-secondary stage to enable them to complete their education.These scholarships shall be available for studies in India only and will be awarded by the Government of State/Union Territory to which the applicant actually belongs, i.e. permanently settled.');

-- --------------------------------------------------------

--
-- Table structure for table `service_menu`
--

CREATE TABLE IF NOT EXISTS `service_menu` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(200) NOT NULL,
  `s_link` varchar(200) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `service_menu`
--

INSERT INTO `service_menu` (`no`, `s_name`, `s_link`) VALUES
(13, 'problems', 'services_problem.php'),
(14, 'New Ideas', 'services_new_ideas.php'),
(15, 'Acts / Rules', 'services_new_rules.php'),
(16, 'Job Vacancies', 'services_gov_jobs.php'),
(17, 'Honours & Awards', 'services_honours_award.php'),
(18, 'Students Schollarship', 'services_scholarship.php');

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE IF NOT EXISTS `upload` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(10000) DEFAULT NULL,
  `sub` varchar(500) NOT NULL,
  `tex` mediumtext NOT NULL,
  `date` varchar(11) NOT NULL,
  `id_up` varchar(100) NOT NULL,
  `group_up` varchar(100) NOT NULL,
  `a_id` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=160 ;

--
-- Dumping data for table `upload`
--

INSERT INTO `upload` (`no`, `img`, `sub`, `tex`, `date`, `id_up`, `group_up`, `a_id`, `status`) VALUES
(109, '../upload/clean ganga 2.jpg', 'Proposed waterways to enhance tourism & clean Ganga', 'How can the proposed waterways and similar initiatives complement the various efforts to clean the Ganga and at the same time enhance tourism? Should such an initiative be replicated for other rivers as well?', '15-Apr-2015', '406', 'clean ganga', 'ankita687', '1'),
(110, '../upload/clean ganga 1.jpg', 'Integrating stakeholders to clean Ganga', 'Can cleaning of the Ganga only be done through Plan or there is a larger need to integrate other stakeholders more effectively?', '15-Apr-2015', '987', 'clean ganga', 'ankita687', '0'),
(111, '../upload/caring1.jpg', 'Equal Employment Opportunities for the Specially-abled', 'Deliberate on actionable points to provide equal employment opportunities to the specially-abled across various sectors.', '15-Apr-2015', '596', 'caring for the specially abled', 'ankita687', '1'),
(112, '../upload/foodsecurity.jpg', 'Improving the Targeted Public Distribution System (TPDS)', 'Inputs from the citizens are sought on the following critical issues related to the Targeted Public Distribution System:\r\n\r\nI Correct Identification of Beneficiaries\r\n\r\n(i) Exclusion/ inclusion criteria for identification of beneficiaries\r\n(ii) Preparation of provisional list of beneficiaries, finalization of list, its verification and adoption.\r\n(iii) Use of digitised beneficiary/ration card database and its verification\r\n(iv) Continuous review for deletion of bogus/ ineligible ration cards and for issuance of cards to eligible beneficiaries\r\n(v) Automatic electronic updation of database through ration card services', '15-Apr-2015', '827', 'food security', 'ankita687', '1'),
(113, '../upload/greeni india.jpg', 'How Sustainable Management of Natural Resources may achieve Food & Rural livelihood security in India?', 'As the Indian population continues to grow there will be an immense competition for natural resources while achieving food, nutritional, environmental and livelihood security in the country. In addition, the negative consequences of climate change become more evident in agriculture with exploitation of natural resources, decline in soil fertility, ground water levels to meet the ever increasing demands for food and nutritional requirements. To maintain sustainable balance between natural resources and the demand, immediate attention is needed in several areas viz., imbalanced use of fertilizers, declining soil organic carbon, lowering of water table, soil health, organic farming and climate change impact in agriculture sector.', '15-Apr-2015', '36', 'green india', 'ankita687', '1'),
(114, '../upload/greeni india 2.jpg', 'Balancing development & environment', 'Through sound and innovative policies, how can we achieve both development and a clean environment?', '15-Apr-2015', '526', 'green india', 'ankita687', '1'),
(115, '../upload/railway1.jpg', 'Deaths due to trespassing', 'If any person enters upon or into any part of a railway without lawful authority he shall be punishable with imprisonment for a term which may be extended to six months or with a fine which may extend to one thousand rupees or with both.\r\n\r\nProvided that in the absence of special and adequate reasons to the contrary to be mentioned in the judgment of the court, such punishment shall not be less than a fine of five hundred rupees.', '15-Apr-2015', '718', 'indian railways', 'piter58', '0'),
(116, '../upload/railway2.jpg', 'Accidents due to carrying of inflammable materials in passenger trains', ' No person shall take with him on a railway, or require a railway administration to carry such dangerous or offensive goods, as may be prescribed, except in accordance with the provisions of this section.\r\n No person shall entrust the goods referred to in sub-section (1) to a railway servant authorized in this behalf for carriage unless he distinctly marks on the outside of the package containing such goods their dangerous or offensive nature and gives a notice in writing of their dangerous or offensive nature to such railway servant.\r\n Notwithstanding anything contained in this section, any railway servant may refuse to accept any dangerous or offensive goods for carriage or stop, in transit, such goods or cause the same to be removed, as the case may be, if he has reason to believe that the provisions of this section for such carriage are not compiled with.', '15-Apr-2015', '755', 'indian railways', 'piter58', '1'),
(117, '../upload/railway3.jpg', 'Ticketing System on Indian Railways', 'Reserved tickets can be booked at Computerised Passenger Reservation System centres operated by Indian Railways and also online through website www.irctc.co.in. Unreserved tickets can be purchased from Computerised Unreserved Ticketing System counters and also Automatic Ticket Vending Machines which have been installed at major stations.', '15-Apr-2015', '469', 'indian railways', 'piter58', '1'),
(118, '../upload/Banner-510-340.jpg', 'PMâ€™s Mann Ki Baat with farmers on 22nd March, 2015', 'The Prime Minister is very keen to interact with his farmer sisters and brothers across India and would also like to hear their thoughts, ideas and insights on a wide range of issues relating to agriculture. He has requested farmers across India to write to him and send letters to â€˜Mann Ki Baat, Akashvani, Sansad Marg, Delhi â€“ 110001â€™. Some farmers can ask the Prime Minister their question directly during the episode.', '15-Apr-2015', '150', 'man ki baat', 'piter58', '0'),
(119, '../upload/man ki baat 2.jpg', 'Questions for special â€˜Mann Ki Baatâ€™ programme with PM Modi and President Obama', 'On 27th January 2015 the special â€˜Mann Ki Baatâ€™ programme will be aired, during which Prime Minister Narendra Modi and USA President Barack Obama will be sharing their thoughts on the radio. The programme is certainly going to be the cynosure of all eyes across India, USA and entire world.\r\nHere is a historic and one of a kind opportunity to be a part of this radio programme by sharing your questions. Ask a question on any topic that interests you and you wanted to ask PM Modi and President Obama.', '15-Apr-2015', '26', 'man ki baat', 'piter58', '0'),
(120, '../upload/nrl1.jpg', 'NRIs & Indian Culture abroad', 'What are the steps NRI can take in order to promote Indian culture abroad both locally and across the nation in which they live?', '15-Apr-2015', '677', 'NRIs for india growth', 'piter58', '1'),
(121, '../upload/nrl2.jpg', 'NRIs and enhancing tourism', 'Can NRIs play a more active role in increasing tourist arrivals to India? How can this effort become more institutionalized?', '15-Apr-2015', '112', 'NRIs for india growth', 'piter58', '1'),
(122, '../upload/nrl3.jpg', 'NRI help to sports in India', 'How can NRIs assist the sports in India in terms of adopting sportspersons, teams and contributing towards better facilities so that India improves the medal tally in international sporting events such as the Olympics?', '15-Apr-2015', '315', 'NRIs for india growth', 'piter58', '1'),
(123, '../upload/nrl4.jpg', 'NRI help to promote startups', 'How can members of the diaspora help in promoting startups in their respective countries?', '15-Apr-2015', '167', 'NRIs for india growth', 'piter58', '1'),
(124, '../upload/sakriya panchayat.jpg', 'Share your suggestions/ ideas/ inputs on the modalities of celebrating the village formation day', 'The Ministry is seeking suggestions/ ideas/ inputs on the modalities of  celebrating the village formation day, either on a particular date, or a day of choice based on some historical reasons or on April 24, the Panchayati Raj Day.', '15-Apr-2015', '51', 'sakriya panchayat', 'piter58', '1'),
(125, '../upload/swachh bharat.jpg', 'Cleanliness in school curriculum', 'How can schools innovatively include â€˜focusing on cleanlinessâ€™ as a part of their curriculum where students learn about the need and importance of cleanliness from a very young age? Post your views.', '15-Apr-2015', '496', 'swachh bharat', 'piter58', '1'),
(126, '../upload/swachh bharat 2.jpg', 'Cleanliness initiatives to mark Gandhi jiâ€™s 150th Birth Anniversary', 'What are your ideas on commemorating Mahatma Gandhiâ€™s 150th birth anniversary with a special focus on cleanliness? What innovative initiatives can be adopted to mark this event?', '15-Apr-2015', '1', 'swachh bharat', 'piter58', '1'),
(127, '../upload/youth 2.jpg', 'How do we instill the social values in the contemporary youth?', 'Give suggestions to instill social values in the contemporary youth.', '15-Apr-2015', '440', 'youth for nation building', 'piter58', '0'),
(128, '../upload/youth.jpg', 'How can we enhance the participation of youth in Politics and Governance?', 'Suggest ways to enhance youth participation in politics and governance.\r\n\r\nLast date for sending your suggestions is 31st December, 2014.', '15-Apr-2015', '208', 'youth for nation building', 'piter58', '0'),
(129, '../upload/haveli.jpg', 'How to Control Growth of Heavy Vehicular Traffic & Traffic Safety in UT of Dadra & Nagar Haveli?', 'Dadra & Nagar Haveli is well connected by road and Rail with rest of the country. The NH-8 provides the major road connectivity to the study area. With rapid Urbanization and industrial growth in Dadra & Nagar Haveli UT, the population and vehicles have increased rapidly in the recent past years. This resulted in traffic congestion in the urban areas. UT Administration has frequently initiated steps for betterment of heavy vehicular traffic plying in this UT and having appreciated the existing problems and constraints felt that there is a strong need for improvement of Infrastructure in Road Sector in a planned manner to meet the growing demand.\r\nThe Report provides information about the regulatory and economic context in which the Territoryâ€™s heavy vehicle industrial traffic operates. It addresses forecasts of future vehicle traffic and measures in place to manage heavy vehicle safety issues within the urban area of this UT of Dadra & Nagar Haveli. The Taskforce has used the information gathered to assess potential risks and identify opportunities to improve road safety outcomes for all road users in UT of Dadra & Nagar Haveli.', '15-Apr-2015', '683', 'dadra nagar havely UT', 'piter58', '1'),
(130, '../upload/digital india 4.jpg', 'What are the major public places in Delhi where a Wi-Fi hotspot is most required for access to internet?', 'A hotspot is a place that offers Internet access over a Wireless Local Area Network (WLAN) through an Internet service provider using Wi-Fi technology. Public Wi-Fi hotspot allows the citizens to get free access to internet on their smartphones, tablets, laptops, and other mobile devices.\r\n\r\nTo make Delhi a smart and connected city, suggestions are invited on the major public places in Delhi where a free public Wi-Fi hotspot is most required for internet access. A maximum of 5 public places in Delhi may be specified per entry. The inputs can be provided in text, .doc or .pdf format.', '16-Apr-2015', '532', 'digital india', 'piter58', '1'),
(131, '../upload/digital india 5.jpg', 'Give comments and suggestions on revised draft Internet of Things (IoT) Policy', 'The draft policy on Internet of Things (IoT) released on 16th October, 2014 has been revised recently.\r\n\r\nWe invite your comments and suggestions on the revised draft policy on Internet of Things (IoT).', '16-Apr-2015', '635', 'digital india', 'piter58', '1'),
(132, '../upload/digital india 6.jpg', 'Give your inputs on the Open Application Programming Interface (API) policy and suggest implementation approach across the government', 'In order to design an interoperable ecosystem of data, applications and processes, there is a need to formulate a policy for the Government Organizations to provide Open Application Programming Interfaces (APIs). The â€œPolicy on Open APIs for Government of Indiaâ€ has been drafted to encourage formal use of Open APIs in Government Organizations. This policy sets out the Governmentâ€™s approach on the use of â€œOpen APIsâ€ to promote software interoperability for all e-Governance applications & systems and provide access to data & services for promoting participation of citizens and other stakeholders.', '16-Apr-2015', '433', 'digital india', 'piter58', '1'),
(133, '../upload/energy.jpg', 'Enhance energy efficiency of all (government and private) office buildings', 'Share your views on how to enhance energy efficiency in government as well as private office buildings.', '16-Apr-2015', '159', 'energy conservation', 'piter58', '1'),
(134, '../upload/girl child education 2.jpg', 'Role of parents in furthering education for daughters', 'What is the role of parents in furthering education for daughters? Do you think a broader and more equal outlook among parents would help more daughters to go to school?', '16-Apr-2015', '164', 'girl child education', 'piter58', '1'),
(135, '../upload/girl child education.jpg', 'PPP model and girl child education', 'Suggest how PPP model and community participation can boost girl child education.', '16-Apr-2015', '358', 'girl child education', 'piter58', '1'),
(136, '../upload/healthy india 1.jpg', 'Health Education Campaign by Union Ministry of Health & Family Welfare on Doordarshan', 'A concept paper has been created for a Health Education Campaign by Doordarshan for the Ministry of Health & Family Welfare. The objective for the concept is to create an environment of health consciousness in the country and empower citizens to chose healthy life styles and prevent diseases. The campaign is envisaged to have a three-tier approach â€“ National, Regional & Sub-regional supplemented with inter-Personal communication.', '16-Apr-2015', '228', 'healthy india', 'piter58', '1'),
(141, '../upload/skill development.jpg', 'Making entrepreneurship aspirational through entrepreneurship education', 'What kind of policy is required to promote entrepreneurship education in India that infuses innovation and entrepreneurial culture in youth and build ecosystem for entrepreneurship as aspiring career?\r\n\r\nThe last date for submission of your comments is 13th April, 2015.', '16-Apr-2015', '624', 'skill development', 'piter58', '1'),
(142, '../upload/skill development 2.jpg', 'What type of regulating structure is required to encourage development of requisite skill traits in mining sector?', 'The country is well endowed with many metallic and non-metallic mineral resources.  India is a leading player in respect of many non fuel minerals including, iron ore, bauxite, dolomite, lime stone and mica.  Mining sector (non-fuel) currently accounts for approx 0.5% of GDP.  For accelerated economic growth on sustainable basis, this sector has to grow at a much faster pace to secure   a higher percentage in the GDP. \r\n \r\nScientific, sustainable and transparent mining practices require well trained manpower.  Skill development not only enhances productivity and safety at work place, but more importantly, it prepares the manpower to adapt to the new state of art technologies. Currently this sector employs around 0.2 Million workforce which is estimated to grow to 0.3 Million in next 10 years.', '16-Apr-2015', '751', 'skill development', 'piter58', '1'),
(143, '../upload/skill development 3.jpg', 'What type of incentive structure encourages development of requisite skill traits in mining sector?', 'The country is well endowed with many metallic and non-metallic mineral resources.  India is a leading player in respect of many non fuel minerals including, iron ore, bauxite, dolomite, lime stone and mica.  Mining sector (non-fuel) currently accounts for approx 0.5% of GDP. For accelerated economic growth on sustainable basis, this sector has to grow at a much faster pace to secure a higher percentage in the GDP. \r\n \r\nScientific, sustainable and transparent mining practices require well trained manpower.  Skill development not only enhances productivity and safety at work place, but more importantly, it prepares the manpower to adapt to the new state of art technologies. Currently this sector employs around 0.2 Million workforce which is estimated to grow to 0.3 Million in next 10 years.', '16-Apr-2015', '213', 'skill development', 'piter58', '1'),
(144, '../upload/bethi badhao.jpg', 'Communicating and changing the discriminatory social construct against the girl child', 'The girl child today faces inequality and gender based discriminations even before birth. The nation cannot move forward unless women are given opportunity to realize their full potential and contribute to nation building.\r\n\r\nGiven this context, please share your thoughts, ideas, suggestions and feedback on how we can change the discriminatory social construct in order to celebrate the girl child. What should be our communication strategy for improving the situation and reach out to people?', '16-Apr-2015', '68', 'beti bachao beti padhao', 'piter58', '1'),
(145, '../upload/bethi badhao 2.jpg', 'Share your inspiring story related to empowerment of girls', 'As part of the Beti Bachao Beti Padhao Initiative, we seek local role models. Please share with us an inspiring story of commitment, courage and fortitude related to empowerment of girls that you know of.', '16-Apr-2015', '672', 'beti bachao beti padhao', 'piter58', '1'),
(146, '../upload/chemical 1.jpg', 'Policy interventions required for growth of Chemicals & Petrochemicals sector', 'The objective of the Group is to brainstorm and invite considered views of all stakeholders in Chemicals & Petrochemical sector that include polymers, plastics, synthetic rubber basic Chemicals, pesticide, dyes etc. The sector is touching the lives of each and every member of the society. This sector has tremendous potential of growth vis a vis the contribution of this sector in the world economy, especially in the manufacturing sector in developed countries. The sector also offers employment opportunities for a large population.\r\n\r\nAs the sector is already liberalized, which has also resulted in a rapid increase in imports, there is a need to review this situation and to promote domestic manufacturing by attracting large investments and providing facilitative policy regime. At the same time, sustainability and environment friendliness of the industries in this sector also has to be ensured as an initiative as part of â€˜MAKE IN INDIAâ€™ campaign of the new government.', '16-Apr-2015', '576', 'chemicals and petrochemicals', 'piter58', '1'),
(147, '../upload/Expenditure.jpg', 'Any other relevant issue concerning Public Expenditure Management', 'Consider any other relevant issue concerning Public Expenditure Management in Central Government and make suitable recommendations.', '16-Apr-2015', '405', 'expenditure management commission', 'piter58', '1'),
(148, '../upload/incraditable india.jpg', 'Best Practices for Tourism by State Governments and Across the World', 'Discuss best practices by State Governments and across the world which have given a boost to tourism.', '16-Apr-2015', '184', 'incredible india', 'piter58', '1'),
(149, '../upload/incradiable india 2.jpg', 'Balance Growth in Tourism and Environment', 'How can we balance growth in tourism with preserving the balance in nature i.e. not harming the local environment?', '16-Apr-2015', '2', 'incredible india', 'piter58', '0'),
(150, '../upload/job creation.jpg', 'Role of SME & MSME sector to create jobs', 'Do you feel SMEs and MSMEs have the potential to play an important role in job creation? Can you suggest innovative ideas that facilitate a qualitative improvement in the SME and MSME sector and also create more jobs?', '16-Apr-2015', '659', 'job creation', 'piter58', '1'),
(151, '../upload/job creation 3.jpg', 'Internationalization of higher education', 'Globalization has resulted in greater cross border higher education. However, there is a need for a better policy that encourages collaborations, student faculty mobility etc. What are the changes necessary to bring promote internationalization of HE.', '16-Apr-2015', '17', 'job creation', 'piter58', '1'),
(152, '../upload/new education 3.jpg', 'Engagement with industry to link education to employability', 'Employability of our students is a matter of concern. At the other end of the spectrum is need for greater investment in research. Industry academia linkages are essential to meet both these ends. While we have various efforts in this direction, these have not fructified as expected. We need to find out how and what is needed for a more fruitful partnering.', '16-Apr-2015', '334', 'new education policy', 'piter58', '1'),
(153, '../upload/new education 7.jpg', 'Enabling Inclusive Education â€“ education of Girls, SCs, STs, Minorities and children with special needs', 'The issue of social access and equity are far too complex. While the gaps in average enrolments between disadvantaged groups like SC, ST, Muslims, girls and Children with special needs and the general population have decreased, there is still a considerably large gap in learning levels with historically disadvantaged and economically weaker children having significantly lower learning outcomes. Large and growing learning gaps threaten the equity gains achieved on the enrolment front because children with lower levels of learning are more likely to drop out. We need to examine current interventions in bridging the gender and social gaps and identify focused strategies for effective inclusion.', '16-Apr-2015', '176', 'new education policy', 'piter58', '1'),
(154, '../upload/new education 8.jpg', 'Promotion of Information and Communication Technology systems in school and adult education', 'ICT can potentially make significant difference in improving the quality of education. The National Policy of ICT in School Education envisions and provides for the development of a holistic framework of ICT support in the school system. While there have several ways in which ICT in schools are being implemented, we need to optimally use and leverage technology to achieve quality and efficiency in all of the interventions. Under this theme, we need to find solutions on how best technology can be leveraged for both school and adult education and share best practices, if any.', '16-Apr-2015', '498', 'new education policy', 'piter58', '1'),
(155, '../upload/new education 9.jpg', 'Accelerating rural literacy with special emphasis on Women, SCs, STs & Minorities through Adult Education and National Open Schooling Systems', 'Though there have been significant gains in literacy rates, large gender, social and regional disparities in literacy levels persist. The gains in literacy levels are due to success of the adult education programmes and improvements in primary schooling. However, there is a further need to enhance the literacy levels of the socially marginalized groups and those living in rural areas through interventions of adult education programmes and open schooling systems. This theme seeks to elicit views on how we achieve faster progress in reducing the existing disparities in literacy levels.', '16-Apr-2015', '860', 'new education policy', 'piter58', '1'),
(156, '../upload/sporty india.jpg', 'How to generate revenue for SAI Stadia in Delhi?', 'Sports Authority of India (SAI) has five Stadia in Delhi viz. Jawaharlal Nehru Stadium, Indira Gandhi Sports Complex, Major Dhyan Chand National Stadium, Dr. Syama Prasad Mookerjee Swimming Pool Complex and Dr. Karni Singh Shooting Ranges. The sprawling Stadia were built for 1982 Asian Games and were later renovated/ reconstructed for the Commonwealth Games-2010 and have potential to generate revenue by way of organising sports and non-sports events.', '16-Apr-2015', '583', 'sporty india', 'piter58', '1'),
(159, '../upload/Watershed.jpg', 'Comments invited on Concept Note on establishment of National e-Health Authority', 'Ministry of Health and Family Welfare proposes to set up a National e-Health Authority (NeHA) responsible for development of an Integrated Health Information System in India. It will also be responsible for enforcing the laws & regulations relating to the privacy and security of the patients health information & records. Ministry of Health and Family Welfare is seeking your comments/suggestions/views on this document. The last date for submission of entries is 20th April, 2015.', '16-Apr-2015', '445', 'watershead management', 'piter58', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user_acc`
--

CREATE TABLE IF NOT EXISTS `user_acc` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `distric` varchar(100) NOT NULL,
  `address` varchar(2000) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `user_acc`
--

INSERT INTO `user_acc` (`no`, `u_id`, `country`, `state`, `distric`, `address`) VALUES
(1, 'pritesh888', 'Indian', 'Hdsfi', 'Navsari', 'Boarding'),
(2, 'ankita308', 'Indian', 'Gujarat', 'rajkot', 'upleta'),
(3, 'pooja886', '', '', '', ''),
(4, 'misha202', '', '', '', ''),
(5, 'jinal784', '', '', '', ''),
(7, 'pratik158', '', '', '', ''),
(8, 'reshma979', '', '', '', ''),
(9, 'arsalna866', '', '', '', ''),
(10, 'devanshu935', '', '', '', ''),
(11, 'mayur548', '', '', '', ''),
(12, 'nirav107', '', '', '', ''),
(13, 'jagdish58', '', '', '', ''),
(14, 'priya246', '', '', '', ''),
(15, 'mitul946', '', '', '', ''),
(16, 'hiral889', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE IF NOT EXISTS `user_reg` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `phone_no` varchar(12) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `u_id` varchar(100) NOT NULL,
  `pro_pic` varchar(500) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`no`, `fname`, `lname`, `gender`, `phone_no`, `email_id`, `pwd`, `date`, `u_id`, `pro_pic`, `status`) VALUES
(23, 'Pritesh', 'Patel', 'Male', '7600748153', 'pritesh746@gmail.com', 'pppp123@', '14-Apr-2015', 'pritesh888', 'upload/Cool-And-Stylish-Profile-Pictures-For-Boys-2.jpg', '0'),
(24, 'Ankita', 'Chndravadiya', 'Female', '1234567819', 'ankita767@gmail.com', 'ankuparth767@', '23-Apr-2015', 'ankita308', 'upload/737808_10151229781924527_1983334508_o.jpg', '0'),
(25, 'pooja', 'garala', 'female', '1234567890', 'pooja@gmail.com', 'pooja767@', '23-Apr-2015', 'pooja886', 'upload/pro_pic.png', '0'),
(26, 'misha', 'bengoli', 'female', '0987654321', 'misha@gmail.com', 'misha767@', '23-Apr-2015', 'misha202', 'upload/pro_pic.png', '0'),
(27, 'jinal', 'bulsara', 'female', '8765390345', 'jinal@gmail.com', 'jinal767@', '23-Apr-2015', 'jinal784', 'upload/pro_pic.png', '0'),
(29, 'pratik', 'nandaniya', 'male', '7654321897', 'pratik@gmail.com', 'pratik767@', '23-Apr-2015', 'pratik158', 'upload/pro_pic.png', '0'),
(30, 'reshma', 'patel', 'female', '7890543278', 'reshma@gmail.com', 'reshma767@', '23-Apr-2015', 'reshma979', 'upload/pro_pic.png', '0'),
(31, 'arsalna', 'sharma', 'female', '8765432198', 'arsalna@gmail.com', 'arsalna767@', '23-Apr-2015', 'arsalna866', 'upload/pro_pic.png', '0'),
(32, 'devanshu', 'nandaniya', 'male', '7659324567', 'devanshu@gmail.com', 'devanshu767@', '23-Apr-2015', 'devanshu935', 'upload/pro_pic.png', '0'),
(33, 'mayur', 'Patel', 'male', '7865432189', 'mayur@gmail.com', 'mayur767@', '23-Apr-2015', 'mayur548', 'upload/1main-passport-size.jpg', '0'),
(34, 'nirav', 'tandel', 'male', '9876543212', 'nirav@gmail.com', 'nirav767@', '23-Apr-2015', 'nirav107', 'upload/pro_pic.png', '1'),
(35, 'jagdish', 'chodhari', 'male', '9824561556', 'jagdish@gmail.com', 'jagdish767@', '23-Apr-2015', 'jagdish58', 'upload/pro_pic.png', '1'),
(36, 'priya', 'Patel', 'female', '9824561441', 'priya@gmail.com', 'priya767@', '23-Apr-2015', 'priya246', 'upload/pro_pic.png', '1'),
(37, 'mitul', 'patel', 'female', '7405376329', 'mitul@gmail.com', 'mitul767@', '23-Apr-2015', 'mitul946', 'upload/pro_pic.png', '1'),
(38, 'hiral', 'ahir', 'female', '9876543278', 'hiral@gmail.com', 'hiral767@', '23-Apr-2015', 'hiral889', 'upload/pro_pic.png', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
