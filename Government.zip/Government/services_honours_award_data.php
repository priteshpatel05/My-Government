<?php
session_start();

/*= = = = = = = = = = = = = = = = = Show All Awards call = = = = = = = = = = = = = */
if(isset($_REQUEST['display_award_no']))
{
	display_awards();
}
/*= = = = = = = = = = = = = = = = = End Show Awards call = = = = = = = = = = = = = */



/*= = = = = = = = = = = = = = = = = All Awards Display = = = = = = = = = = = = = */	
	function display_awards()
	{
		$con=mysql_connect("Localhost","root","");
		mysql_select_db("mygov",$con);
		
		$qry="select * from honours_award_tbl";
		$result=mysql_query($qry,$con);
	?>
		
    	        
        <?php
		$q=1;
		while($row=mysql_fetch_assoc($result))
		{
		?>         
 			<div class="show_main_div">
                   
               <span class="fa fa-circle"></span>

            	<img src="<?php echo "upload/".$row['image'];?>" class="award_img" />

                <div class="award_name">
						<?php echo ucfirst($row['award_name']);?>
                </div>
                
                <div class="award_details">
                	<?php echo ucfirst($row['details']);?>
                </div>
                
            </div>
        <?php	
		}
		?>
    
		
	<?php
	}
/*= = = = = = = = = = = = = = = = = End All Vacancies Display = = = = = = = = = = = = = */	


?>