                    <div class="show-result">
                
                        <div class="show-like">
                        
                       <span id="count_like" class="fa fa-thumbs-up like" onclick="likes('<?php  echo $open_row['id_up']; ?>','<?php  echo $r['u_id']; ?>','like')"></span> 
                        </div>            
    				
                    
						<div  class="show-unlike">
                        
					<span id="count_unlike" class="fa fa-thumbs-down like" onclick="likes('<?php  echo $open_row['id_up']; ?>','<?php  echo $r['u_id']; ?>','unlike')"></span> 
					    </div>
                        
                         <div class="cmt_count">
                        </div>
    
                    </div>
                    
